# Home Page - OpenEHR Base package v0.1.0-snapshot

* **Home Page**

## Home Page

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://openehr.org/fhir/ImplementationGuide/openehr.base | *Version*:0.1.0-snapshot | |
| *IG Standards status:*[Informative](http://hl7.org/fhir/R5/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 3 | *Computable Name*:OpenEHRBasePackage |

### Introduction

 This publication contains information to support FHIR tools working with openEHR content. Specifically, it contains a FHIR representation of the openEHR reference model. In general, this IG is a technical internal artifact to the tools; it's not anticipated that the implementers who use either openEHR or FHIR will need to look at this. (hopefully) 

### Dependencies

 This IG depends on the following additional IGs: 

*There are no Global profiles defined*

