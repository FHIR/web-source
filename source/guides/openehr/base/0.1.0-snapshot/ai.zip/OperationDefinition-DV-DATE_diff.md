# OperationDefinition - OpenEHR Base package v0.1.0-snapshot

* [**Home Page**](index.md)
* [**Artifacts Summary**](artifacts.md)
* [**DV_DATE**](StructureDefinition-DV-DATE.md)
* **OperationDefinition**

## OperationDefinition: OperationDefinition 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://openehr.org/fhir/StructureDefinition/DV-DATE#diff | *Version*:0.1.0-snapshot | |
| *Standards status:*[Informative](http://hl7.org/fhir/R5/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 3 | *Computable Name*:diff |

 
Difference between this Date and`_other_`. 

