# OperationDefinition - OpenEHR Base package v0.1.0-snapshot

* [**Home Page**](index.md)
* [**Artifacts Summary**](artifacts.md)
* [**DV_DURATION**](StructureDefinition-DV-DURATION.md)
* **OperationDefinition**

## OperationDefinition: OperationDefinition 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://openehr.org/fhir/StructureDefinition/DV-DURATION#is_strictly_comparable_to | *Version*:0.1.0-snapshot | |
| *Standards status:*[Informative](http://hl7.org/fhir/R5/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 3 | *Computable Name*:is_strictly_comparable_to |

 
True, for any two Durations. 

