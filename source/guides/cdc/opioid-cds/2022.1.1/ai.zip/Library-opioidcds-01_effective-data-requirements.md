# Library - 2022 CDC Clinical Practice Guideline for Prescribing Opioids Implementation Guide v2022.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* [**Recommendation #1 - Nonpharmacologic and Nonopioid Pharmacologic Therapy Consideration**](PlanDefinition-opioidcds-01.md)
* **Library**

## Library: Library 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.org/guides/cdc/opioid-cds/PlanDefinition/opioidcds-01#effective-data-requirements | *Version*:2022.1.0 |
| Active | *Computable Name*:EffectiveDataRequirements |

