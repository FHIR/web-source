# Recommendation #10 - Urine Drug Testing (patient-view) - 2022 CDC Clinical Practice Guideline for Prescribing Opioids Implementation Guide v2022.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Recommendation #10 - Urine Drug Testing (patient-view)**

## PlanDefinition: Recommendation #10 - Urine Drug Testing (patient-view) 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.org/guides/cdc/opioid-cds/PlanDefinition/opioidcds-10-patient-view | *Version*:2022.1.0 |
| Active as of 2025-08-06 | *Computable Name*:PlanDefinition_Recommendation_10_Patient_View |
| *Other Identifiers:*cdc-opioid-guidance (use: official, ), OID:2.16.840.1.114222.34.11 | |
| **Usage:**Clinical Focus: Chronic pain (finding), Clinical Focus:  | |
| **Copyright/Legal**: © CDC 2016+. | |

 
When prescribing opioids for subacute or chronic pain, clinicians should consider the benefits and risks of toxicology testing to assess for prescribed medications as well as other prescribed and nonprescribed controlled substances. 

 
The 2022 CDC Clinical Practice Guideline for Prescribing Opioids for Pain is intended to improve communication between clinicians and patients about the benefits and risks of pain treatments, including opioid therapy; improve the effectiveness and safety of pain treatment; mitigate pain; improve function and quality of life for patients with pain; and reduce risks associated with opioid pain therapy, including opioid use disorder, overdose, and death. The recommendations do not apply to pain related to sickle cell disease or cancer or to patients receiving palliative or end-of-life care. 

* **Actions: **: **Url: **
  * : [Recommendation #10 - Urine Drug Testing (patient-view)](PlanDefinition-opioidcds-10-patient-view.md)
* **Actions: **: **Version: **
  * : 2022.1.0
* **Actions: **: **Name: **
  * : PlanDefinition_Recommendation_10_Patient_View
* **Actions: **: **Title: **
  * : Recommendation #10 - Urine Drug Testing (patient-view)
* **Actions: **: **Status: **
  * : active
* **Actions: **: **Experimental: **
  * : false
* **Actions: **: **Date: **
  * : 2025-08-06
* **Actions: **: **Publisher: **
  * : CDC / Security Risk Solutions, Inc. (SRS)
* **Actions: **: **Description: **
  * : When prescribing opioids for subacute or chronic pain, clinicians should consider the benefits and risks of toxicology testing to assess for prescribed medications as well as other prescribed and nonprescribed controlled substances.
* **Actions: **: **Knowledge Capability: **
  * : shareable computable executable publishable
* **Actions: **: **Purpose: **
  * : The 2022 CDC Clinical Practice Guideline for Prescribing Opioids for Pain is intended to improve communication between clinicians and patients about the benefits and risks of pain treatments, including opioid therapy; improve the effectiveness and safety of pain treatment; mitigate pain; improve function and quality of life for patients with pain; and reduce risks associated with opioid pain therapy, including opioid use disorder, overdose, and death. The recommendations do not apply to pain related to sickle cell disease or cancer or to patients receiving palliative or end-of-life care.
* **Actions: **: **Usage: **
  * : Before starting opioids and periodically (at least annually) during opioid therapy, clinicians should consider the benefits and risks of toxicology testing to assess for prescribed opioids and other prescription and nonprescription controlled substances that increase risk for overdose when combined with opioids, including nonprescribed and illicit opioids and benzodiazepines.
* **Actions: **: **Copyright: **
  * : © CDC 2016+.
* **Actions: **: **Libraries: **
  * : 
| |
| :--- |
| [Library - Recommendation #10 Patient View - Urine Drug Testing](Library-OpioidCDSREC10PatientView.md) |




## Resource Content

```json
{
  "resourceType" : "PlanDefinition",
  "id" : "opioidcds-10-patient-view",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-recommendationdefinition",
    "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-publishableplandefinition"]
  },
  "contained" : [{
    "resourceType" : "Library",
    "id" : "effective-data-requirements",
    "name" : "EffectiveDataRequirements",
    "status" : "active",
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/library-type",
        "code" : "module-definition"
      }]
    },
    "relatedArtifact" : [{
      "type" : "depends-on",
      "display" : "Library Common",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/Library/OpioidCDSCommon|2022.1.0"
    },
    {
      "type" : "depends-on",
      "display" : "Library Config",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/Library/OpioidCDSCommonConfig|2022.1.0"
    },
    {
      "type" : "depends-on",
      "display" : "Library FHIRHelpers",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/Library/FHIRHelpers|4.0.1"
    },
    {
      "type" : "depends-on",
      "display" : "Library Routines",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/Library/OpioidCDSRoutines|2022.1.0"
    },
    {
      "type" : "depends-on",
      "display" : "Library Rec10Common",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/Library/OpioidCDSREC10Common|2022.1.0"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Community",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/medicationrequest-category-community"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Opioid analgesics with ambulatory misuse potential",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/opioid-analgesics-with-ambulatory-misuse-potential"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Encounter Diagnosis Condition Category",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/condition-encounter-diagnosis-category"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Problem List Condition Category",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/condition-problem-list-category"
    },
    {
      "type" : "depends-on",
      "display" : "Value set US Core Health Concern Condition Category",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/condition-us-core-health-concern-category"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Sickle Cell Diseases",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/sickle-cell-diseases"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Active Condition",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/condition-clinical-status-active"
    },
    {
      "type" : "depends-on",
      "display" : "Value set CDC malignant cancer conditions",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/cdc-malignant-cancer-conditions"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Conditions likely terminal for opioid prescribing",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/conditions-likely-terminal-for-opioid-prescribing"
    },
    {
      "type" : "depends-on",
      "display" : "Value set All Drug Urine Screening",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/all-urine-drug-screening-tests"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Limited life expectancy conditions",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/limited-life-expectancy-conditions"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Hospice Finding Codes",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/hospice-finding"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Hospice Disposition",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/hospice-disposition"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Amphetamine Urine Tests",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/amphetamine-urine-drug-screening-tests"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Amphetamine Medications",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/amphetamines-class-medications"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Barbiturate Urine Tests",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/barbiturate-urine-drug-screening-tests"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Barbiturate Medications",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/barbiturate-medications"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Benzodiazepine Urine Tests",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/benzodiazepine-urine-drug-screening-tests"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Benzodiazepine medications",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/benzodiazepine-medications"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Buprenorphine Urine Tests",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/buprenorphine-urine-drug-screening-tests"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Buprenorphine Medications",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/buprenorphine-medications"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Cannabinoid Urine Tests",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/cannabinoid-urine-drug-screening-tests"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Cocaine Urine Tests",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/cocaine-urine-drug-screening-tests"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Fentanyl Urine Tests",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/fentanyl-type-urine-drug-screening-tests"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Fentanyl Medications",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/fentanyl-type-medications"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Heroin Urine Tests",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/heroin-urine-drug-screening-tests"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Methadone Urine Tests",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/methadone-urine-drug-screening-tests"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Methadone Medications",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/methadone-medications"
    },
    {
      "type" : "depends-on",
      "display" : "Value set General Opiate Urine Tests",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/general-opiate-urine-drug-screening-tests"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Opiate Medications",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/non-synthetic-opioid-medications"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Oxycodone Urine Tests",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/oxycodone-urine-drug-screening-tests"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Oxycodone Medications",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/oxycodone-medications"
    },
    {
      "type" : "depends-on",
      "display" : "Value set PCP Urine Tests",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/phencyclidine-urine-drug-screening-tests"
    }],
    "parameter" : [{
      "name" : "Is Perform Drug Screen Recommendation Applicable?",
      "use" : "out",
      "min" : 0,
      "max" : "1",
      "type" : "boolean"
    },
    {
      "name" : "Applicable Because of Unexpected Results",
      "use" : "out",
      "min" : 0,
      "max" : "1",
      "type" : "boolean"
    },
    {
      "name" : "Detail",
      "use" : "out",
      "min" : 0,
      "max" : "1",
      "type" : "string"
    }],
    "dataRequirement" : [{
      "type" : "Medication",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Medication"],
      "mustSupport" : ["id", "code"]
    },
    {
      "type" : "MedicationRequest",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/MedicationRequest"],
      "mustSupport" : ["authoredOn",
      "medication",
      "medication.reference",
      "id",
      "status",
      "intent",
      "category",
      "subject",
      "recorder",
      "dosageInstruction",
      "dispenseRequest",
      "status.value",
      "timing",
      "timing.event",
      "timing.repeat",
      "timing.repeat.bounds",
      "medication.text",
      "medication.coding"]
    },
    {
      "type" : "MedicationRequest",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/MedicationRequest"],
      "mustSupport" : ["category",
      "status",
      "intent",
      "medication",
      "medication.reference",
      "id",
      "subject",
      "authoredOn",
      "recorder",
      "dosageInstruction",
      "dispenseRequest",
      "status.value",
      "timing",
      "timing.event",
      "timing.repeat",
      "timing.repeat.bounds",
      "medication.text",
      "medication.coding"],
      "codeFilter" : [{
        "path" : "category",
        "valueSet" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/medicationrequest-category-community"
      }]
    },
    {
      "type" : "Patient",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
    },
    {
      "type" : "Condition",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Condition"],
      "mustSupport" : ["category", "code", "clinicalStatus"],
      "codeFilter" : [{
        "path" : "category",
        "valueSet" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/condition-us-core-health-concern-category"
      }]
    },
    {
      "type" : "Condition",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Condition"],
      "mustSupport" : ["category",
      "code",
      "clinicalStatus",
      "encounter",
      "encounter.reference"],
      "codeFilter" : [{
        "path" : "category",
        "valueSet" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/condition-encounter-diagnosis-category"
      }]
    },
    {
      "type" : "Condition",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Condition"],
      "mustSupport" : ["category", "code", "clinicalStatus", "clinicalStatus.coding"],
      "codeFilter" : [{
        "path" : "category",
        "valueSet" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/condition-problem-list-category"
      }]
    },
    {
      "type" : "Encounter",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Encounter"],
      "mustSupport" : ["period",
      "period.start",
      "id",
      "hospitalization",
      "hospitalization.dischargeDisposition",
      "hospitalization.dischargeDisposition.coding",
      "status",
      "status.value"]
    },
    {
      "type" : "Observation",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Observation"],
      "mustSupport" : ["code", "status", "status.value", "effective", "code.coding", "value"],
      "codeFilter" : [{
        "path" : "code",
        "valueSet" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/hospice-finding"
      }]
    },
    {
      "type" : "Observation",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Observation"],
      "mustSupport" : ["code", "effective", "status", "code.coding", "value"],
      "codeFilter" : [{
        "path" : "code",
        "valueSet" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/all-urine-drug-screening-tests"
      }]
    }]
  }],
  "extension" : [{
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "shareable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "computable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "executable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "publishable"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "Can the implementing EHR support queries for past medications by date range?"
    },
    {
      "url" : "statement",
      "valueString" : "// Subroutine 2 - Past Medications\ndefine \"Can the implementing EHR support queries for past medications by date range?\":\n  true"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 0
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "Active Ambulatory Opioid Rx"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Active Ambulatory Opioid Rx\":\n    if Config.\"Can the implementing EHR support queries for past medications by date range?\" then\n      (\n        \"Get MedicationRequest Medication as Code\"(\"Get Active Ambulatory Medication Requests\"([MedicationRequest]))\n      ) Rx\n        where date from Rx.authoredOn 2 years or less on or before Today()\n          and Rx.medication in \"Opioid analgesics with ambulatory misuse potential\"\n    else\n        List<FHIR.MedicationRequest>{}"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 1
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10PatientView"
    },
    {
      "url" : "name",
      "valueString" : "Chronic Pain Opioid Analgesic with Ambulatory Misuse Potential Prescriptions"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Chronic Pain Opioid Analgesic with Ambulatory Misuse Potential Prescriptions\":\n  Common.\"Active Ambulatory Opioid Rx\" AmbulatoryOpioidPrescription\n    where Routines.\"Is Subacute or Chronic Pain Prescription?\"(AmbulatoryOpioidPrescription)"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 2
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10PatientView"
    },
    {
      "url" : "name",
      "valueString" : "Patient Is Being Prescribed Opioid Analgesic with Ambulatory Misuse Potential"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Patient Is Being Prescribed Opioid Analgesic with Ambulatory Misuse Potential\":\n  exists (\"Chronic Pain Opioid Analgesic with Ambulatory Misuse Potential Prescriptions\")"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 3
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "Age Less than 18 Years Is Enabled"
    },
    {
      "url" : "statement",
      "valueString" : "// CDC 2022 General Inclusion Criteria\ndefine \"Age Less than 18 Years Is Enabled\":\n  true"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 4
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Patient Age Less Than 18"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Patient Age Less Than 18\":\n  if (Config.\"Age Less than 18 Years Is Enabled\") then\n    AgeInYearsAt(Today()) < 18\n  else false"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 5
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "Sickle Cell Check Enabled"
    },
    {
      "url" : "statement",
      "valueString" : "// Sickle Cell\ndefine \"Sickle Cell Check Enabled\":\n  true"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 6
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "Sickle Cell Assumed Active"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Sickle Cell Assumed Active\":\n  true"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 7
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "US Core-Categorized Conditions"
    },
    {
      "url" : "statement",
      "valueString" : "// 3. Medications indicating end of life\n    /* or exists (\n      \"Medications Indicating End of Life\"\n    ) */\n\ndefine \"US Core-Categorized Conditions\":\n  [Condition: category in \"Encounter Diagnosis Condition Category\"]\n    union [Condition: category in \"Problem List Condition Category\"]\n    union [Condition: category in \"US Core Health Concern Condition Category\"]"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 8
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "Positive Sickle Cell Condition"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Positive Sickle Cell Condition\":\n  if Config.\"Sickle Cell Check Enabled\" and not Config.\"Sickle Cell Assumed Active\"\n    then (\n      \"US Core-Categorized Conditions\" C\n        where C.code in \"Sickle Cell Diseases\"\n          and C.clinicalStatus in \"Active Condition\"\n    ) else if Config.\"Sickle Cell Check Enabled\" and Config.\"Sickle Cell Assumed Active\"\n        then (\n          \"US Core-Categorized Conditions\" C\n            where C.code in \"Sickle Cell Diseases\"\n        )\n      else null"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 9
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Condition Positive for Sickle Cell"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Condition Positive for Sickle Cell\":\n  if (Config.\"Sickle Cell Check Enabled\") then\n    exists(\n      Common.\"Positive Sickle Cell Condition\"\n    ) \n  else false"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 10
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "Active Cancer Treatment Encounters Condition Is Enabled"
    },
    {
      "url" : "statement",
      "valueString" : "// Active Cancer Treatment\ndefine \"Active Cancer Treatment Encounters Condition Is Enabled\":\n  true"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 11
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Encounter Period"
    },
    {
      "url" : "statement",
      "valueString" : "// End of Opioid Naive Routine\n\n/*\n**  Routine #3\n**  Active Cancer Treatment Routine\n**\n**  Definition                    | Answer to Proceed   | Details                                    | Data (Terminology) Requirement\n**  ---------------------------------------------------------------------------------------------------------------------------------\n**  Two office visits within the  | No                  | Look for a minimum of two distinct         | Office Visit\n**  past 12 months                |                     | encounters within 12 months of the date    |\n**                                |                     | of the current visit for which each of the |\n**                                |                     | following is true:                         |\n**                                |                     |   - the encounter diagnosis (primary or    |\n**                                |                     |     secondary or co-morbidity diagnosis)   |\n**                                |                     |     is listed in the CDC Malignant Cancer  |\n**                                |                     |     Conditions value set                   |\n**  ---------------------------------------------------------------------------------------------------------------------------------\n**  Office visits with an         | No                  | The encounter is performed by an           | Oncology specialty\n**  oncology specialist           |                     | oncologist as defined in the oncology      | designations (NUCC)\n**  present                       |                     | specialty designations using the           |\n**                                |                     | National Uniform Claim Committee           |\n**                                |                     | (NUCC) classifications                     |\n**  ---------------------------------------------------------------------------------------------------------------------------------\n**  Office visits including CDC   | No                  | The encounter diagnosis (primary or        | CDC malignant cancer\n**  malignant cancer              |                     | secondary or co-morbidity diagnosis)       | conditions\n**  condition                     |                     | is listed in the CDC Malignant Cancer      |\n**                                |                     | Conditions value set                       |\n**  ----------------------------------------------------------------------------------------------------------------------------------\n**\n*/\n\ndefine \"Encounter Period\":\n  Interval[Today() - 12 months, Today())"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 12
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "USCore Encounter Cancer Diagnoses"
    },
    {
      "url" : "statement",
      "valueString" : "define \"USCore Encounter Cancer Diagnoses\":\n  [Condition: category in \"Encounter Diagnosis Condition Category\"] CancerDiagnoses\n    where CancerDiagnoses.code in \"CDC malignant cancer conditions\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 13
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Encounters with Cancer Diagnosis During Encounter Period"
    },
    {
      "url" : "statement",
      "valueString" : "// encounter-diagnosis, problem-list and health-concern Conditions\n// define \"US Core-Categorized Cancer Diagnoses\":\n//   Common.\"US Core-Categorized Conditions\" C\n//     where C.code in Common.\"CDC malignant cancer conditions\"\n\n// define \"Encounters with Cancer Diagnosis During Encounter Period\":\n//   [Encounter] Encounter\n//     with \"US Core-Categorized Cancer Diagnoses\" CancerDiagnosis\n//     such that date from Encounter.period.\"start\".value in day of \"Encounter Period\"\n//       and EndsWith(CancerDiagnosis.encounter.reference, Encounter.id)\n\ndefine \"Encounters with Cancer Diagnosis During Encounter Period\":\n  [Encounter] Encounters\n    where date from Encounters.period.\"start\" in day of \"Encounter Period\"\n      and exists (\n        Common.\"USCore Encounter Cancer Diagnoses\" CancerDiagnoses\n          where EndsWith(CancerDiagnoses.encounter.reference, Encounters.id)\n      )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 14
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Number of Encounters with Cancer Diagnosis During Encounter Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Number of Encounters with Cancer Diagnosis During Encounter Period\":\n  Count (\"Encounters with Cancer Diagnosis During Encounter Period\")"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 15
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Has Two or More Encounters with Cancer Diagnosis During Encounter Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Has Two or More Encounters with Cancer Diagnosis During Encounter Period\":\n  \"Number of Encounters with Cancer Diagnosis During Encounter Period\" >= 2"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 16
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "USCore Problem List Cancer Diagnoses"
    },
    {
      "url" : "statement",
      "valueString" : "define \"USCore Problem List Cancer Diagnoses\":\n  [Condition: category in \"Problem List Condition Category\"] CancerDiagnoses\n    where CancerDiagnoses.code in \"CDC malignant cancer conditions\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 17
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Has Active Cancer Diagnosis on Problem List"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Has Active Cancer Diagnosis on Problem List\":\n  exists (\n    Common.\"USCore Problem List Cancer Diagnoses\" CancerDiagnoses\n      where CancerDiagnoses.category in Common.\"Problem List Condition Category\"\n        and exists(\n          CancerDiagnoses.clinicalStatus.coding ClinicalStatus\n            where ClinicalStatus.code ~ 'active'\n        )\n  )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 18
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Is Active Cancer Treatment?"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Is Active Cancer Treatment?\":\n  if (Config.\"Active Cancer Treatment Encounters Condition Is Enabled\") \n    then \"Has Two or More Encounters with Cancer Diagnosis During Encounter Period\"\n      or \"Has Active Cancer Diagnosis on Problem List\"\n  else false"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 19
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "End-Stage Disease Criteria Enabled"
    },
    {
      "url" : "statement",
      "valueString" : "// CDC 2022 General Inclusion Criteria\ndefine \"End-Stage Disease Criteria Enabled\":\n  true"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 20
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Conditions Likely Terminal for Opioid Prescribing"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Conditions Likely Terminal for Opioid Prescribing\":\n  if (Config.\"End-Stage Disease Criteria Enabled\") then\n    exists (\n      Common.\"US Core-Categorized Conditions\" EOLC\n        where EOLC.code in Common.\"Conditions likely terminal for opioid prescribing\"\n          // and EOLC.clinicalStatus in Common.\"Active Condition\"\n    )\n  else false"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 21
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "CDC 2022 Guideline General Inclusion Criteria"
    },
    {
      "url" : "statement",
      "valueString" : "define \"CDC 2022 Guideline General Inclusion Criteria\":\n  not \"Patient Age Less Than 18\"\n    and not \"Condition Positive for Sickle Cell\"\n    and not \"Is Active Cancer Treatment?\"\n    and not \"Conditions Likely Terminal for Opioid Prescribing\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 22
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "Use Alternative UDS Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Use Alternative UDS Lookback Period\":\n  false"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 23
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "Alternative UDS Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Alternative UDS Lookback Period\":\n  Interval[Today() - 6 months - 1 days, Today()]"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 24
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "All Opioid or Non-opioid UDS in Alternative Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"All Opioid or Non-opioid UDS in Alternative Lookback Period\":\n  (\n    [Observation: Common.\"All Drug Urine Screening\"] Lab\n      where date from Lab.effective in day of Config.\"Alternative UDS Lookback Period\"\n        and not (\n          Lab.status in { 'unknown', 'entered-in-error', 'cancelled' }\n        )\n  ) X sort by date from effective desc"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 25
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "UDS Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "// Constants\n\ndefine \"UDS Lookback Period\":\n  Interval[Today() - 12 months - 1 days, Today()]"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 26
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "All Opioid or Non-opioid UDS in Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"All Opioid or Non-opioid UDS in Lookback Period\":\n  (\n    [Observation: Common.\"All Drug Urine Screening\"] Lab\n      where date from Lab.effective in day of \"UDS Lookback Period\"\n        and not (\n          Lab.status in { 'unknown', 'entered-in-error', 'cancelled' }\n        )\n  ) X sort by date from effective desc"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 27
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Inclusion Criteria For UDS Recommendation"
    },
    {
      "url" : "statement",
      "valueString" : "/*\n@description: Determines whether the general inclusion criteria is met for the patient and whether they had a UDS performed in the past year\n*/\ndefine \"Inclusion Criteria For UDS Recommendation\":\n  Routines.\"CDC 2022 Guideline General Inclusion Criteria\"\n    and not exists (\n      if Config.\"Use Alternative UDS Lookback Period\"\n        then \"All Opioid or Non-opioid UDS in Alternative Lookback Period\"\n      else \"All Opioid or Non-opioid UDS in Lookback Period\"\n    )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 28
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "Conditions Indicating End of Life or With Limited Life Expectancy"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Conditions Indicating End of Life or With Limited Life Expectancy\":\n  (\n    \"US Core-Categorized Conditions\" C\n      where C.code in \"Conditions likely terminal for opioid prescribing\"\n        and C.clinicalStatus in \"Active Condition\"\n  )\n  union\n  (\n    \"US Core-Categorized Conditions\" C\n      where C.code in \"Limited life expectancy conditions\"\n        and C.clinicalStatus in \"Active Condition\"\n  )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 29
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "Hospice Findings Exclusion Enabled"
    },
    {
      "url" : "statement",
      "valueString" : "// OpioidCDSCommon\ndefine \"Hospice Findings Exclusion Enabled\":\n  false"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 30
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "Admitted/Referred/Discharged to Hospice Care"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Admitted/Referred/Discharged to Hospice Care\":\n  (\n    if (Config.\"Hospice Findings Exclusion Enabled\") then\n      [Observation: code in \"Hospice Finding Codes\"] O\n        where not (O.status.value in { 'unknown', 'entered-in-error', 'cancelled' })\n    else\n      {}\n  )\n  union\n  (\n    [Encounter] E\n      where date from E.period.start 1 year or less on or before Today()\n        and (\n          if E.hospitalization.dischargeDisposition.coding is null\n              or not exists (E.hospitalization.dischargeDisposition.coding)\n            then false\n          else E.hospitalization.dischargeDisposition in \"Hospice Disposition\"\n        )\n        and E.status.value in { 'planned', 'arrived', 'in-progress', 'finished', 'onleave' }\n  )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 31
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "End of Life Assessment"
    },
    {
      "url" : "statement",
      "valueString" : "define \"End of Life Assessment\":\n    // 1. Conditions indicating end of life or with limited life expectancy\n    exists (\n      \"Conditions Indicating End of Life or With Limited Life Expectancy\"\n    )\n    // 2. Admitted/referred/discharged to hospice care\n    or exists (\n      \"Admitted/Referred/Discharged to Hospice Care\"\n    )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 32
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Exclusion Criteria"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Exclusion Criteria\":\n  Common.\"End of Life Assessment\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 33
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10PatientView"
    },
    {
      "url" : "name",
      "valueString" : "Is Perform Drug Screen Recommendation Applicable?"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Is Perform Drug Screen Recommendation Applicable?\":\n  \"Patient Is Being Prescribed Opioid Analgesic with Ambulatory Misuse Potential\"\n    and Rec10Common.\"Inclusion Criteria For UDS Recommendation\"\n    and not Rec10Common.\"Exclusion Criteria\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 34
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Amphetamine Simple Identifier"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Amphetamine Simple Identifier\": 'Amphetamine'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 35
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Amphetamine Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "// Amphetamines\ndefine \"Amphetamine Screenings In Lookback Period\":\n  \"All Opioid or Non-opioid UDS in Lookback Period\" Lab\n    where Lab.code in Common.\"Amphetamine Urine Tests\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 36
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Positive Amphetamine Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Positive Amphetamine Screenings In Lookback Period\":\n  GetPositiveLabsInLookbackPeriod(\"Amphetamine Screenings In Lookback Period\", true)"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 37
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Negative Amphetamine Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Negative Amphetamine Screenings In Lookback Period\":\n  GetNegativeLabsInLookbackPeriod(\"Amphetamine Screenings In Lookback Period\", true)"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 38
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Rx Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Rx Lookback Period\":\n  Interval[Today() - 12 months - 31 days, Today()]"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 39
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Normalize Rx In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Normalize Rx In Lookback Period\":\n  Common.\"Get MedicationRequest Medication as Code\"(\n    [MedicationRequest: category in Common.\"Community\"] Rx\n      where Rx.status in { 'active', 'completed', 'stopped' }\n        and Rx.intent = 'order'\n        and Common.\"GetDateFromMedicationRequest\"(Rx) in day of \"Rx Lookback Period\"\n  )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 40
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Amphetamine Rx In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Amphetamine Rx In Lookback Period\":\n  \"Normalize Rx In Lookback Period\" Rx\n      where Rx.medication in Common.\"Amphetamine Medications\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 41
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Barbiturate Simple Identifier"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Barbiturate Simple Identifier\": 'Barbiturate'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 42
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Barbiturate Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "// Barbiturates\ndefine \"Barbiturate Screenings In Lookback Period\":\n  \"All Opioid or Non-opioid UDS in Lookback Period\" Lab\n    where Lab.code in Common.\"Barbiturate Urine Tests\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 43
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Positive Barbiturate Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Positive Barbiturate Screenings In Lookback Period\":\n  GetPositiveLabsInLookbackPeriod(\"Barbiturate Screenings In Lookback Period\", true)"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 44
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Negative Barbiturate Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Negative Barbiturate Screenings In Lookback Period\":\n  GetNegativeLabsInLookbackPeriod(\"Barbiturate Screenings In Lookback Period\", true)"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 45
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Barbiturate Rx In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Barbiturate Rx In Lookback Period\":\n  \"Normalize Rx In Lookback Period\" Rx\n      where Rx.medication in Common.\"Barbiturate Medications\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 46
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Benzodiazepine Simple Identifier"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Benzodiazepine Simple Identifier\": 'Benzodiazepine'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 47
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Benzodiazepine Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "// Benzodiazepines\ndefine \"Benzodiazepine Screenings In Lookback Period\":\n  \"All Opioid or Non-opioid UDS in Lookback Period\" Lab\n    where Lab.code in Common.\"Benzodiazepine Urine Tests\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 48
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Positive Benzodiazepine Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Positive Benzodiazepine Screenings In Lookback Period\":\n  GetPositiveLabsInLookbackPeriod(\"Benzodiazepine Screenings In Lookback Period\", true)"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 49
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Negative Benzodiazepine Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Negative Benzodiazepine Screenings In Lookback Period\":\n  GetNegativeLabsInLookbackPeriod(\"Benzodiazepine Screenings In Lookback Period\", true)"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 50
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Benzodiazepine Rx In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Benzodiazepine Rx In Lookback Period\":\n  \"Normalize Rx In Lookback Period\" Rx\n    where Rx.medication in Common.\"Benzodiazepine medications\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 51
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Buprenorphine Simple Identifier"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Buprenorphine Simple Identifier\": 'Buprenorphine'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 52
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Buprenorphine Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "// Buprenorphine\ndefine \"Buprenorphine Screenings In Lookback Period\":\n  \"All Opioid or Non-opioid UDS in Lookback Period\" Lab\n    where Lab.code in Common.\"Buprenorphine Urine Tests\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 53
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Positive Buprenorphine Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Positive Buprenorphine Screenings In Lookback Period\":\n  GetPositiveLabsInLookbackPeriod(\"Buprenorphine Screenings In Lookback Period\", true)"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 54
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Negative Buprenorphine Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Negative Buprenorphine Screenings In Lookback Period\":\n  GetNegativeLabsInLookbackPeriod(\"Buprenorphine Screenings In Lookback Period\", true)"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 55
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Buprenorphine Rx In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Buprenorphine Rx In Lookback Period\":\n  \"Normalize Rx In Lookback Period\" Rx\n    where Rx.medication in Common.\"Buprenorphine Medications\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 56
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Cannabinoid Simple Identifier"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Cannabinoid Simple Identifier\": 'Cannabinoid'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 57
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "Cannabinoid Urine Screening Check Enabled"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Cannabinoid Urine Screening Check Enabled\":\n  false"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 58
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Cannabinoid Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "// Cannabinoids\ndefine \"Cannabinoid Screenings In Lookback Period\":\n  if Config.\"Cannabinoid Urine Screening Check Enabled\"\n    then (\n      \"All Opioid or Non-opioid UDS in Lookback Period\" Lab\n        where Lab.code in Common.\"Cannabinoid Urine Tests\"\n    ) else null"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 59
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Positive Cannabinoid Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Positive Cannabinoid Screenings In Lookback Period\":\n  GetPositiveLabsInLookbackPeriod(\"Cannabinoid Screenings In Lookback Period\", Config.\"Cannabinoid Urine Screening Check Enabled\")"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 60
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Negative Cannabinoid Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Negative Cannabinoid Screenings In Lookback Period\":\n  GetNegativeLabsInLookbackPeriod(\"Cannabinoid Screenings In Lookback Period\", Config.\"Cannabinoid Urine Screening Check Enabled\")"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 61
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Cocaine Simple Identifier"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Cocaine Simple Identifier\": 'Cocaine'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 62
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Cocaine Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "// Cocaine\ndefine \"Cocaine Screenings In Lookback Period\":\n  \"All Opioid or Non-opioid UDS in Lookback Period\" Lab\n    where Lab.code in Common.\"Cocaine Urine Tests\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 63
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Positive Cocaine Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Positive Cocaine Screenings In Lookback Period\":\n  GetPositiveLabsInLookbackPeriod(\"Cocaine Screenings In Lookback Period\", true)"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 64
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Negative Cocaine Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Negative Cocaine Screenings In Lookback Period\":\n  GetNegativeLabsInLookbackPeriod(\"Cocaine Screenings In Lookback Period\", true)"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 65
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Fentanyl Simple Identifier"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Fentanyl Simple Identifier\": 'Fentanyl'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 66
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "Opiate Urine Screening Check Enabled"
    },
    {
      "url" : "statement",
      "valueString" : "// Recommendation 10\ndefine \"Opiate Urine Screening Check Enabled\":\n  true"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 67
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Fentanyl Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "// Fentanyl\ndefine \"Fentanyl Screenings In Lookback Period\":\n  if Config.\"Opiate Urine Screening Check Enabled\"\n  then (\n    \"All Opioid or Non-opioid UDS in Lookback Period\" AllLabs\n      where AllLabs.code in Common.\"Fentanyl Urine Tests\"\n  ) else null"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 68
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Positive Fentanyl Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Positive Fentanyl Screenings In Lookback Period\":\n  GetPositiveLabsInLookbackPeriod(\"Fentanyl Screenings In Lookback Period\", Config.\"Opiate Urine Screening Check Enabled\")"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 69
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Negative Fentanyl Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Negative Fentanyl Screenings In Lookback Period\":\n  GetNegativeLabsInLookbackPeriod(\"Fentanyl Screenings In Lookback Period\", Config.\"Opiate Urine Screening Check Enabled\")"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 70
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Fentanyl Rx In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Fentanyl Rx In Lookback Period\":\n  \"Normalize Rx In Lookback Period\" Rx\n    where Rx.medication in Common.\"Fentanyl Medications\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 71
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Heroin Simple Identifier"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Heroin Simple Identifier\": 'Heroin (6-AM)'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 72
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Heroin Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "// Heroin\ndefine \"Heroin Screenings In Lookback Period\":\n  \"All Opioid or Non-opioid UDS in Lookback Period\" Lab\n    where Lab.code in Common.\"Heroin Urine Tests\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 73
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Positive Heroin Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Positive Heroin Screenings In Lookback Period\":\n  GetPositiveLabsInLookbackPeriod(\"Heroin Screenings In Lookback Period\", true)"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 74
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Negative Heroin Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Negative Heroin Screenings In Lookback Period\":\n  GetNegativeLabsInLookbackPeriod(\"Heroin Screenings In Lookback Period\", true)"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 75
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Methadone Simple Identifier"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Methadone Simple Identifier\": 'Methadone'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 76
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Methadone Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "// Methadone\ndefine \"Methadone Screenings In Lookback Period\":\n  \"All Opioid or Non-opioid UDS in Lookback Period\" Lab\n    where Lab.code in Common.\"Methadone Urine Tests\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 77
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Positive Methadone Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Positive Methadone Screenings In Lookback Period\":\n  GetPositiveLabsInLookbackPeriod(\"Methadone Screenings In Lookback Period\", true)"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 78
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Negative Methadone Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Negative Methadone Screenings In Lookback Period\":\n  GetNegativeLabsInLookbackPeriod(\"Methadone Screenings In Lookback Period\", true)"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 79
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Methadone Rx In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Methadone Rx In Lookback Period\":\n  \"Normalize Rx In Lookback Period\" Rx\n    where Rx.medication in Common.\"Methadone Medications\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 80
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Opiate Simple Identifier"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Opiate Simple Identifier\": 'Opiate'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 81
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Opiate Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "// Opiates\ndefine \"Opiate Screenings In Lookback Period\":\n  if Config.\"Opiate Urine Screening Check Enabled\"\n    then (\n      \"All Opioid or Non-opioid UDS in Lookback Period\" Lab\n        where Lab.code in Common.\"General Opiate Urine Tests\"\n    ) else null"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 82
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Positive Opiate Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Positive Opiate Screenings In Lookback Period\":\n  GetPositiveLabsInLookbackPeriod(\"Opiate Screenings In Lookback Period\", Config.\"Opiate Urine Screening Check Enabled\")"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 83
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Negative Opiate Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Negative Opiate Screenings In Lookback Period\":\n  GetNegativeLabsInLookbackPeriod(\"Opiate Screenings In Lookback Period\", Config.\"Opiate Urine Screening Check Enabled\")"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 84
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Opiate Rx In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Opiate Rx In Lookback Period\":\n  \"Normalize Rx In Lookback Period\" Rx\n    where Rx.medication in Common.\"Opiate Medications\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 85
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Oxycodone Simple Identifier"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Oxycodone Simple Identifier\": 'Oxycodone'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 86
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Oxycodone Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "// Oxycodone\ndefine \"Oxycodone Screenings In Lookback Period\":\n  if Config.\"Opiate Urine Screening Check Enabled\"\n    then (\n      \"All Opioid or Non-opioid UDS in Lookback Period\" Lab\n        where Lab.code in Common.\"Oxycodone Urine Tests\"\n    ) else null"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 87
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Positive Oxycodone Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Positive Oxycodone Screenings In Lookback Period\":\n  GetPositiveLabsInLookbackPeriod(\"Oxycodone Screenings In Lookback Period\", Config.\"Opiate Urine Screening Check Enabled\")"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 88
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Negative Oxycodone Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Negative Oxycodone Screenings In Lookback Period\":\n  GetNegativeLabsInLookbackPeriod(\"Oxycodone Screenings In Lookback Period\", Config.\"Opiate Urine Screening Check Enabled\")"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 89
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Oxycodone Rx In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Oxycodone Rx In Lookback Period\":\n  \"Normalize Rx In Lookback Period\" Rx\n    where Rx.medication in Common.\"Oxycodone Medications\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 90
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "PCP Simple Identifier"
    },
    {
      "url" : "statement",
      "valueString" : "define \"PCP Simple Identifier\": 'Phencyclidine (PCP)'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 91
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "PCP Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "// PCP\ndefine \"PCP Screenings In Lookback Period\":\n  \"All Opioid or Non-opioid UDS in Lookback Period\" AllLabs\n    where AllLabs.code in Common.\"PCP Urine Tests\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 92
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Positive PCP Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Positive PCP Screenings In Lookback Period\":\n  GetPositiveLabsInLookbackPeriod(\"PCP Screenings In Lookback Period\", true)"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 93
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Negative PCP Screenings In Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Negative PCP Screenings In Lookback Period\":\n  GetNegativeLabsInLookbackPeriod(\"PCP Screenings In Lookback Period\", true)"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 94
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Unexpected Details"
    },
    {
      "url" : "statement",
      "valueString" : "// Details Logic\n\ndefine \"Unexpected Details\":\n  {\n    CreateDetailWithPossibleUnexpectedNegative(\n      \"Amphetamine Simple Identifier\", \"Positive Amphetamine Screenings In Lookback Period\", \n      \"Negative Amphetamine Screenings In Lookback Period\", \"Amphetamine Rx In Lookback Period\"\n    ),\n    CreateDetailWithPossibleUnexpectedNegative(\n      \"Barbiturate Simple Identifier\", \"Positive Barbiturate Screenings In Lookback Period\", \n      \"Negative Barbiturate Screenings In Lookback Period\", \"Barbiturate Rx In Lookback Period\"\n    ),\n    CreateDetailWithPossibleUnexpectedNegative(\n      \"Benzodiazepine Simple Identifier\", \"Positive Benzodiazepine Screenings In Lookback Period\", \n      \"Negative Benzodiazepine Screenings In Lookback Period\", \"Benzodiazepine Rx In Lookback Period\"\n    ),\n    CreateDetailWithPossibleUnexpectedNegative(\n      \"Buprenorphine Simple Identifier\", \"Positive Buprenorphine Screenings In Lookback Period\", \n      \"Negative Buprenorphine Screenings In Lookback Period\", \"Buprenorphine Rx In Lookback Period\"\n    ),\n    CreateDetailWithoutPossibleUnexpectedNegative(\n      \"Cannabinoid Simple Identifier\", \"Positive Cannabinoid Screenings In Lookback Period\", \n      \"Negative Cannabinoid Screenings In Lookback Period\"\n    ),\n    CreateDetailWithoutPossibleUnexpectedNegative(\n      \"Cocaine Simple Identifier\", \"Positive Cocaine Screenings In Lookback Period\", \n      \"Negative Cocaine Screenings In Lookback Period\"\n    ),\n    CreateDetailWithPossibleUnexpectedNegative(\n      \"Fentanyl Simple Identifier\", \"Positive Fentanyl Screenings In Lookback Period\", \n      \"Negative Fentanyl Screenings In Lookback Period\", \"Fentanyl Rx In Lookback Period\"\n    ),\n    CreateDetailWithoutPossibleUnexpectedNegative(\n      \"Heroin Simple Identifier\", \"Positive Heroin Screenings In Lookback Period\", \n      \"Negative Heroin Screenings In Lookback Period\"\n    ),\n    CreateDetailWithPossibleUnexpectedNegative(\n      \"Methadone Simple Identifier\", \"Positive Methadone Screenings In Lookback Period\", \n      \"Negative Methadone Screenings In Lookback Period\", \"Methadone Rx In Lookback Period\"\n    ),\n    CreateDetailWithPossibleUnexpectedNegative(\n      \"Opiate Simple Identifier\", \"Positive Opiate Screenings In Lookback Period\", \n      \"Negative Opiate Screenings In Lookback Period\", \"Opiate Rx In Lookback Period\"\n    ),\n    CreateDetailWithPossibleUnexpectedNegative(\n      \"Oxycodone Simple Identifier\", \"Positive Oxycodone Screenings In Lookback Period\", \n      \"Negative Oxycodone Screenings In Lookback Period\", \"Oxycodone Rx In Lookback Period\"\n    ),\n    CreateDetailWithoutPossibleUnexpectedNegative(\n      \"PCP Simple Identifier\", \"Positive PCP Screenings In Lookback Period\", \n      \"Negative PCP Screenings In Lookback Period\"\n    )\n  }"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 95
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Remove Substances Without Positive or Negative Results"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Remove Substances Without Positive or Negative Results\":\n  \"Unexpected Details\" Details\n    where (Details.posDates is not null and Length(Details.posDates) != 0)\n      or (Details.negDates is not null and Length(Details.negDates) != 0)"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 96
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Inclusion Criteria For Unexpected Results"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Inclusion Criteria For Unexpected Results\":\n  Routines.\"CDC 2022 Guideline General Inclusion Criteria\"\n  and AnyTrue(\n    \"Remove Substances Without Positive or Negative Results\" Details\n      return (exists Details.unexpectedPosDetails) or (exists Details.unexpectedNegDetails)\n  )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 97
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10PatientView"
    },
    {
      "url" : "name",
      "valueString" : "Applicable Because of Unexpected Results"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Applicable Because of Unexpected Results\":\n  \"Patient Is Being Prescribed Opioid Analgesic with Ambulatory Misuse Potential\"\n    and Rec10Common.\"Inclusion Criteria For Unexpected Results\"\n    and not Rec10Common.\"Exclusion Criteria\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 98
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "Style Header"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Style Header\":\n  '<style>\\r\\n  .alert-body {\\r\\n    width: 670px;\\r\\n    font-family: segoe-ui, sans-serif;\\r\\n    background-color: #FEFFF1;\\r\\n  }\\r\\n\\r\\n  .details-table {\\r\\n    border-collapse:collapse;\\r\\n    border-style: ridge;\\r\\n    background-color: #FEFFF1;\\r\\n    padding: 2px;\\r\\n  }\\r\\n\\r\\n  .details-caption {\\r\\n    border-style: ridge;\\r\\n    border-bottom: none;\\r\\n    background-color: #FEFFF1;\\r\\n    padding: 2px;\\r\\n  }\\r\\n\\r\\n  .details-table-header {\\r\\n    border-style: ridge;\\r\\n    padding: 5px;\\r\\n  }\\r\\n\\r\\n  .details-table-cell {\\r\\n    border-style: ridge;\\r\\n    padding: 5px;\\r\\n  }\\r\\n\\r\\n  .details-table-footer-cell {\\r\\n    border-style: ridge;\\r\\n    padding: 5px;\\r\\n    font-size: small;\\r\\n  }\\r\\n\\r\\n  .details-table-cell-unexpected {\\r\\n    border-style: ridge;\\r\\n    padding: 5px;\\r\\n    color: red;\\r\\n    font-weight: bold;\\r\\n  }\\r\\n\\r\\n  .more-text {\\r\\n    position: relative;\\r\\n    margin-bottom: 2em;\\r\\n  }\\r\\n  \\r\\n  .more {\\r\\n    display:none;\\r\\n  }\\r\\n\\r\\n  .show-more:checked + .more {\\r\\n    display:block;\\r\\n  }\\r\\n<\\/style>'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 99
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Unexpected Div Start"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Unexpected Div Start\":\n  '<div class=\\\"alert-body\\\"><div><p>Patient may have <strong>unexpected urine toxicology test results<\\/strong> in the past year.<\\/p><\\/div>'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 100
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Table Start"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Table Start\":\n  '<div><table class=\\\"details-table\\\"><caption class=\\\"details-caption\\\">Urine Toxicology Results<\\/caption><tr><th class=\\\"details-table-header\\\">Substance<\\/th>'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 101
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "All Lab Dates in Lookback Period"
    },
    {
      "url" : "statement",
      "valueString" : "// Helpers  \n\ndefine \"All Lab Dates in Lookback Period\":\n  (\n    \"All Opioid or Non-opioid UDS in Lookback Period\" Lab\n      return date from Lab.effective\n  ) X sort desc"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 102
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Table Headers"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Table Headers\":\n  \"All Lab Dates in Lookback Period\" LabDate\n    return '<th class=\\\"details-table-header\\\">' & ToString(LabDate) & '<\\/th>'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 103
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Generate Table Rows"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Generate Table Rows\":\n  \"Remove Substances Without Positive or Negative Results\" BOT\n    let row: ToString(IndexOf(\"Remove Substances Without Positive or Negative Results\", BOT) + 1)\n    return '<tr>' + GetExpectedColumn(BOT.ingredient) + Combine(\n      \"All Lab Dates in Lookback Period\" LabDate\n        let col: ToString(IndexOf(\"All Lab Dates in Lookback Period\", LabDate) + 2)\n        return all (\n          if BOT.unexpectedPosDetails.date contains LabDate\n            then GetUnexpectedColumn('pos', row & ':' & col)\n          else if BOT.unexpectedNegDetails.udsDate contains LabDate\n            then GetUnexpectedColumn('neg', row & ':' & col)\n          else if BOT.posDates contains LabDate\n            then GetExpectedColumn('pos*')\n          else if BOT.negDates contains LabDate\n            then GetExpectedColumn('neg*')\n          else GetExpectedColumn('n/a')\n        )\n    ) + '<\\/tr>'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 104
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Generate Footer Rows"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Generate Footer Rows\":\n  \"Remove Substances Without Positive or Negative Results\" BOT\n      let row: ToString(IndexOf(\"Remove Substances Without Positive or Negative Results\", BOT) + 1),\n      colspan: Length(\"All Lab Dates in Lookback Period\") + 1\n      return Combine(\n          \"All Lab Dates in Lookback Period\" LabDate\n            let col: ToString(IndexOf(\"All Lab Dates in Lookback Period\", LabDate) + 2)\n            return all (\n              if BOT.unexpectedPosDetails.date contains LabDate\n                then Coalesce(\n                  BOT.unexpectedPosDetails PosDetail\n                    where PosDetail.date same day as LabDate\n                      return '<tr>' & GetFooterColumn(colspan, row & ':' & col & ' - Possible unexpected substance found: ' & PosDetail.udsDetail) & '<\\/tr>'\n                )\n              else if BOT.unexpectedNegDetails.udsDate contains LabDate\n                then Coalesce(\n                  BOT.unexpectedNegDetails NegDetail\n                    where NegDetail.udsDate same day as LabDate\n                      return '<tr>' & GetFooterColumn(colspan, row + ':' & col & ' - Possible unexpected negative result found: prescribed ' & NegDetail.rxDetail & ' on ' & ToString(NegDetail.rxDate)) & '<\\/tr>'\n                )\n              else ''\n            )\n      )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 105
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Table End"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Table End\":\n  '<\\/table><\\/div>'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 106
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Details Table"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Details Table\": \n  \"Table Start\" & Combine(\"Table Headers\") \n    & '<tbody>' & Combine(\"Generate Table Rows\") & '</tbody>' \n    & '<tfoot>' & Combine(\"Generate Footer Rows\") & '<\\/tfoot>' \n  & \"Table End\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 107
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Expected Result Footnote"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Expected Result Footnote\":\n  '<div>* - These are expected results based on an analysis of the patient\\'s medication list 30 days prior to the corresponding lab results.<\\/div>'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 108
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Details More Info"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Details More Info\":\n  '<div id=\\\"box\\\">\\r\\n  <p>Note on false positives and unexpected negative results...<\\/p>\\r\\n  <input type=\\\"checkbox\\\" class=\\\"show-more\\\"> Show more\\r\\n  <div class=\\\"more\\\">\\r\\n  <p>An unexpectedly negative test may be due to time since last dose, diversion, intermittent use, aberrant drug use behavior, or other factors, including a false negative result. Clinicians should interpret this result in the context of the overall treatment plan.<\\/p>\\r\\n\\r\\n  <p>Positive results may be a false positives or could represent occasional use or possible substance use disorder.<br\\/><br\\/>For a review regarding interpreting possible false positive urine toxicology results, see <a target=\\\"_blank\\\" href=\\\"https:\\/\\/pubmed.ncbi.nlm.nih.gov\\/24986836\\\">http:\\/\\/pubmed.ncbi.nlm.nih.gov\\/24986836<\\/a>. It is unknown if the findings reported in this article can be extrapolated to other laboratory analyzers that were not used in the referenced studies.<br\\/><br\\/>For guidance regarding evaluating and addressing unexpected toxicology tests results, see <a target=\\\"_blank\\\" href=\\\"https:\\/\\/www.cdc.gov\\/mmwr\\/volumes\\/71\\/rr\\/rr7103a1.htm#Recommendation10\\\">Recommendation 10 of the 22 CDC Clinical Practice Guideiline<\\/a>.<\\/p><\\/div>\\r\\n<\\/div>'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 109
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Div End"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Div End\": '<\\/div>'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 110
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "Get HTML Details"
    },
    {
      "url" : "statement",
      "valueString" : "// HTML Generation\n\ndefine \"Get HTML Details\":\n  Common.\"Style Header\" & \"Unexpected Div Start\" & \"Details Table\" & \"Expected Result Footnote\" & \"Details More Info\" & \"Div End\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 111
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10PatientView"
    },
    {
      "url" : "name",
      "valueString" : "Detail"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Detail\":\n  Rec10Common.\"Get HTML Details\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 112
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "Get MedicationRequest Medication as Code"
    },
    {
      "url" : "statement",
      "valueString" : "define function \"Get MedicationRequest Medication as Code\"(value List<MedicationRequest>):\n  value Rx\n    let Med: \n      if Rx.medication is Reference then singleton from (\n        [Medication] M\n          where M.id = (Last(Split((Rx.medication as FHIR.Reference).reference, '/')))\n      ) else null\n    return \n      MedicationRequest {\n        id: Rx.id,\n        status: Rx.status,\n        intent: Rx.intent,\n        category: Rx.category,\n        medication: if Rx.medication is Reference then Med.code else Rx.medication as CodeableConcept,\n        subject: Rx.subject,\n        authoredOn: Rx.authoredOn,\n        recorder: Rx.recorder,\n        dosageInstruction: Rx.dosageInstruction,\n        dispenseRequest: Rx.dispenseRequest\n      }"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 113
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "FHIRHelpers"
    },
    {
      "url" : "name",
      "valueString" : "ToString"
    },
    {
      "url" : "statement",
      "valueString" : "define function ToString(value string): value.value"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 114
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "Get Active Ambulatory Medication Requests"
    },
    {
      "url" : "statement",
      "valueString" : "define function \"Get Active Ambulatory Medication Requests\" (value List<MedicationRequest>) returns List<MedicationRequest>:\n  value Rx\n    where Rx.status.value = 'active'\n      and Rx.category in \"Community\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 115
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "FHIRHelpers"
    },
    {
      "url" : "name",
      "valueString" : "ToConcept"
    },
    {
      "url" : "statement",
      "valueString" : "define function ToConcept(concept FHIR.CodeableConcept):\n    if concept is null then\n        null\n    else\n        System.Concept {\n            codes: concept.coding C return ToCode(C),\n            display: concept.text.value\n        }"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 116
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "FHIRHelpers"
    },
    {
      "url" : "name",
      "valueString" : "ToCode"
    },
    {
      "url" : "statement",
      "valueString" : "define function ToCode(coding FHIR.Coding):\n    if coding is null then\n        null\n    else\n        System.Code {\n          code: coding.code.value,\n          system: coding.system.value,\n          version: coding.version.value,\n          display: coding.display.value\n        }"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 117
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "FHIRHelpers"
    },
    {
      "url" : "name",
      "valueString" : "ToDateTime"
    },
    {
      "url" : "statement",
      "valueString" : "define function ToDateTime(value dateTime): value.value"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 118
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Is Subacute or Chronic Pain Prescription?"
    },
    {
      "url" : "statement",
      "valueString" : "// End of Active Cancer Treatment Routine\n\n/*\n**  Routine #4\n**  For Subacute or Chronic Pain Routine\n**\n**  Definition                  | Answer to Proceed   | Details                                        | Data (Terminology) Requirement\n**  -----------------------------------------------------------------------------------------------------------------------------------\n**  Order for opioid analgesic  | Yes                 | Order for opioid analgesics with ambulatory    | Opioid analgesics with\n**  with expected supply        |                     | misuse potential with a supply duration of >=  | ambulatory misuse potential\n**  duration >= 28 days         |                     | 28 days                                        |\n**                              |                     |                                                |\n**                              |                     | - Subacute definition = order for opioid       |\n**                              |                     |   analgesics with ambulatory misuse            |\n**                              |                     |   potential with a supply duration of one to   |\n**                              |                     |   two months.                                  |\n**                              |                     | - Chronic pain definition = order for opioid   |\n**                              |                     |   analgesics with ambulatory misuse            |\n**                              |                     |   potential with a supply duration of >= two   |\n**                              |                     |   months.                                      |\n**  -----------------------------------------------------------------------------------------------------------------------------------\n**\n*/\n\ndefine function \"Is Subacute or Chronic Pain Prescription?\"(prescription FHIR.MedicationRequest):\n  \"Is Subacute or Chronic Pain Using Expected Supply Duration\"(prescription)\n    or \"Is Subacute or Chronic Pain Using Validity Period\"(prescription)"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 119
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Is Subacute or Chronic Pain Using Expected Supply Duration"
    },
    {
      "url" : "statement",
      "valueString" : "define function \"Is Subacute or Chronic Pain Using Expected Supply Duration\"(prescription FHIR.MedicationRequest):\n  (\n    prescription.dispenseRequest is not null\n      and prescription.dispenseRequest.expectedSupplyDuration is not null\n      and (\n        Common.GetDurationInDays(prescription.dispenseRequest.expectedSupplyDuration) >= 28 days \n      )\n  )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 120
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "GetDurationInDays"
    },
    {
      "url" : "statement",
      "valueString" : "define function GetDurationInDays(value FHIR.Duration):\n  if value is null then null\n  else\n    case\n      when value.code.value ~ 'a' then System.Quantity{ value: value.value.value * 365.0, unit: 'days' }\n      when value.code.value ~ 'mo' then System.Quantity{ value: value.value.value * 30.0, unit: 'days' }\n      when value.code.value ~ 'wk' then System.Quantity{ value: value.value.value * 7.0, unit: 'days' }\n      when value.code.value ~ 'd' then System.Quantity{ value: value.value.value, unit: 'days' }\n      when value.code.value ~ 'h' then System.Quantity{ value: value.value.value / 24.0, unit: 'days' }\n      when value.code.value ~ 'min' then System.Quantity{ value: value.value.value / 60.0 / 24.0, unit: 'days' }\n      when value.code.value ~ 's' then System.Quantity{ value: value.value.value / 60.0 / 60.0 / 24.0, unit: 'days' }\n      when value.code.value ~ 'ms' then System.Quantity{ value: value.value.value / 60.0 / 60.0 / 24.0 / 1000.0, unit: 'days' }\n      when value.code.value is null then Message(1000, true, 'Undefined', 'Error', 'Duration unit code is null')\n      else Message(1000, true, 'Undefined', 'Error', 'Unsupported duration unit code: ' + value.code.value)\nend"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 121
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Is Subacute or Chronic Pain Using Validity Period"
    },
    {
      "url" : "statement",
      "valueString" : "define function \"Is Subacute or Chronic Pain Using Validity Period\"(prescription FHIR.MedicationRequest):\n  (\n    prescription.dispenseRequest is not null\n      and prescription.dispenseRequest.validityPeriod is not null\n      and (\n        days between prescription.dispenseRequest.validityPeriod.start and prescription.dispenseRequest.validityPeriod.end >= 28 \n      )\n  )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 122
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "FHIRHelpers"
    },
    {
      "url" : "name",
      "valueString" : "ToDateTime"
    },
    {
      "url" : "statement",
      "valueString" : "define function ToDateTime(value instant): value.value"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 123
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "FHIRHelpers"
    },
    {
      "url" : "name",
      "valueString" : "ToString"
    },
    {
      "url" : "statement",
      "valueString" : "define function ToString(value ObservationStatus): value.value"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 124
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "CreateDetailWithPossibleUnexpectedNegative"
    },
    {
      "url" : "statement",
      "valueString" : "define function CreateDetailWithPossibleUnexpectedNegative(TheSubstance String, ThePosLabs List<Observation>, TheNegLabs List<Observation>, TheMeds List<MedicationRequest>):\n  {\n    ingredient: TheSubstance,\n    posDates: (\n      ThePosLabs PosLab\n        return date from PosLab.effective\n    ),\n    negDates: (\n      TheNegLabs NegLab\n        return date from NegLab.effective\n    ),\n    unexpectedPosDetails: (\n      ThePosLabs PosLab\n        where not exists (\n          TheMeds Rx\n            where Common.GetDateFromMedicationRequest(Rx)\n              in day of Interval[\n                date from PosLab.effective - 31 days,\n                date from PosLab.effective - 1 days\n              ]\n        )\n        return {\n          date: date from PosLab.effective,\n          udsDetail:\n            if exists(PosLab.code.coding)\n              then PosLab.code.coding[0].display\n              else 'Unable to determine a detailed identifier'\n        }\n    ),\n    unexpectedNegDetails: (\n      from TheNegLabs NegLab,\n        ( if exists(TheMeds) then TheMeds else { null as MedicationRequest } ) Rx\n        let medDate: Common.GetDateFromMedicationRequest(Rx)\n          where medDate in day of Interval[date from NegLab.effective - 31 days, date from NegLab.effective - 1 days]\n          return {\n            udsDate: date from NegLab.effective,\n            udsDetail: if exists (NegLab.code.coding) then NegLab.code.coding[0].display else 'Unable to determine a detailed identifier',\n            rxDate: medDate,\n            rxDetail: \n              if Rx.medication.text is not null then Rx.medication.text\n              else if exists (Rx.medication.coding) and Rx.medication.coding[0].display is not null then Rx.medication.coding[0].display \n              else 'Unable to determine a detailed identifier'\n          }\n    )\n  }"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 125
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "GetDateFromMedicationRequest"
    },
    {
      "url" : "statement",
      "valueString" : "define function \"GetDateFromMedicationRequest\"(med FHIR.MedicationRequest):\n  if med is null then\n    null\n  else if med.authoredOn is not null then\n    date from med.authoredOn\n  else\n    Max(\n      med.dosageInstruction DI\n        return Coalesce(\n          // If there are timing events, take the latest.\n          Max(DI.timing.event E return date from E),\n          // Otherwise, if there's a Period, use its start.\n          if DI.timing.repeat is not null\n             and DI.timing.repeat.bounds is FHIR.Period\n          then\n            date from start of FHIRHelpers.ToInterval(DI.timing.repeat.bounds as FHIR.Period)\n          else\n            null\n        )\n    )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 126
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "FHIRHelpers"
    },
    {
      "url" : "name",
      "valueString" : "ToInterval"
    },
    {
      "url" : "statement",
      "valueString" : "define function ToInterval(period FHIR.Period):\n    if period is null then\n        null\n    else\n        if period.\"start\" is null then\n            Interval(period.\"start\".value, period.\"end\".value]\n        else\n            Interval[period.\"start\".value, period.\"end\".value]"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 127
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "GetPositiveLabsInLookbackPeriod"
    },
    {
      "url" : "statement",
      "valueString" : "define function GetPositiveLabsInLookbackPeriod(Labs List<FHIR.Observation>, Enabled Boolean):\n  if Enabled\n    then Labs Lab\n     where StartsWith(Lower(Lab.value as FHIR.string), 'pos')\n  else {}"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 128
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "GetNegativeLabsInLookbackPeriod"
    },
    {
      "url" : "statement",
      "valueString" : "define function GetNegativeLabsInLookbackPeriod(Labs List<FHIR.Observation>, Enabled Boolean):\n  if Enabled\n    then Labs Lab\n     where StartsWith(Lower(Lab.value as FHIR.string), 'neg')\n  else {}"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 129
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "FHIRHelpers"
    },
    {
      "url" : "name",
      "valueString" : "ToString"
    },
    {
      "url" : "statement",
      "valueString" : "define function ToString(value MedicationRequestStatus): value.value"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 130
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "FHIRHelpers"
    },
    {
      "url" : "name",
      "valueString" : "ToString"
    },
    {
      "url" : "statement",
      "valueString" : "define function ToString(value MedicationRequestIntent): value.value"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 131
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "CreateDetailWithoutPossibleUnexpectedNegative"
    },
    {
      "url" : "statement",
      "valueString" : "define function CreateDetailWithoutPossibleUnexpectedNegative(TheSubstance String, ThePosLabs List<Observation>, TheNegLabs List<Observation>):\n  {\n    ingredient: TheSubstance,\n    posDates: (\n      ThePosLabs PosLab\n        return date from PosLab.effective\n    ),\n    negDates: (\n      TheNegLabs NegLab\n        return date from NegLab.effective\n    ),\n    unexpectedPosDetails: (\n      ThePosLabs PosLab\n        return {\n          date: date from PosLab.effective,\n          udsDetail: if exists (PosLab.code.coding) then PosLab.code.coding[0].display else 'Unable to determine a detailed identifier'\n        }\n    ),\n    unexpectedNegDetails: {\n      null as Tuple{ udsDate System.Date, udsDetail System.String, rxDate System.Date, rxDetail System.String }\n    }\n  }"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 132
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "GetExpectedColumn"
    },
    {
      "url" : "statement",
      "valueString" : "define function GetExpectedColumn(Content String):\n  '<td class=\\\"details-table-cell\\\">' & Content & '<\\/td>'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 133
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "GetUnexpectedColumn"
    },
    {
      "url" : "statement",
      "valueString" : "// Functions\n\ndefine function GetUnexpectedColumn(Result String, Superscript String):\n  '<td class=\\\"details-table-cell-unexpected\\\">' & Result & '<sup>' & Superscript & '<\\/sup><\\/td>'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 134
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC10Common"
    },
    {
      "url" : "name",
      "valueString" : "GetFooterColumn"
    },
    {
      "url" : "statement",
      "valueString" : "define function GetFooterColumn(colspan Integer, message String):\n  '<td class=\\\"details-table-cell\\\"' & ' colspan=' & ToString(colspan) & '>' & message & '<\\/td>'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 135
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "id" : "effective-data-requirements",
    "url" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-effectiveDataRequirements",
    "valueCanonical" : "#effective-data-requirements"
  },
  {
    "url" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-softwaresystem",
    "valueReference" : {
      "reference" : "Device/cqf-tooling"
    }
  }],
  "url" : "http://fhir.org/guides/cdc/opioid-cds/PlanDefinition/opioidcds-10-patient-view",
  "identifier" : [{
    "use" : "official",
    "value" : "cdc-opioid-guidance"
  },
  {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.16.840.1.114222.34.11"
  }],
  "version" : "2022.1.0",
  "name" : "PlanDefinition_Recommendation_10_Patient_View",
  "title" : "Recommendation #10 - Urine Drug Testing (patient-view)",
  "type" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/plan-definition-type",
      "code" : "eca-rule",
      "display" : "ECA Rule"
    }]
  },
  "status" : "active",
  "experimental" : false,
  "date" : "2025-08-06",
  "publisher" : "CDC / Security Risk Solutions, Inc. (SRS)",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.securityrisksolutions.com"
    }]
  }],
  "description" : "When prescribing opioids for subacute or chronic pain, clinicians should consider the benefits and risks of toxicology testing to assess for prescribed medications as well as other prescribed and nonprescribed controlled substances.",
  "useContext" : [{
    "code" : {
      "system" : "http://terminology.hl7.org/CodeSystem/usage-context-type",
      "code" : "focus",
      "display" : "Clinical Focus"
    },
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "82423001",
        "display" : "Chronic pain (finding)"
      }]
    }
  },
  {
    "code" : {
      "system" : "http://terminology.hl7.org/CodeSystem/usage-context-type",
      "code" : "focus",
      "display" : "Clinical Focus"
    },
    "valueCodeableConcept" : {
      "text" : "Subacute pain"
    }
  }],
  "purpose" : "The 2022 CDC Clinical Practice Guideline for Prescribing Opioids for Pain is intended to improve communication between clinicians and patients about the benefits and risks of pain treatments, including opioid therapy; improve the effectiveness and safety of pain treatment; mitigate pain; improve function and quality of life for patients with pain; and reduce risks associated with opioid pain therapy, including opioid use disorder, overdose, and death. The recommendations do not apply to pain related to sickle cell disease or cancer or to patients receiving palliative or end-of-life care.",
  "usage" : "Before starting opioids and periodically (at least annually) during opioid therapy, clinicians should consider the benefits and risks of toxicology testing to assess for prescribed opioids and other prescription and nonprescription controlled substances that increase risk for overdose when combined with opioids, including nonprescribed and illicit opioids and benzodiazepines.",
  "copyright" : "© CDC 2016+.",
  "topic" : [{
    "text" : "Opioid Prescribing"
  }],
  "author" : [{
    "name" : "Kensaku Kawamoto, MD, PhD, MHS"
  },
  {
    "name" : "Bryn Rhodes"
  },
  {
    "name" : "Floyd Eisenberg, MD, MPH"
  },
  {
    "name" : "Robert McClure, MD, MPH"
  }],
  "relatedArtifact" : [{
    "type" : "documentation",
    "display" : "2022 CDC Clinical Practice Guideline for Prescribing Opioids for Pain",
    "url" : "https://www.cdc.gov/mmwr/volumes/71/rr/pdfs/rr7103a1-H.pdf",
    "document" : {
      "contentType" : "application/pdf",
      "language" : "en-US",
      "url" : "https://www.cdc.gov/mmwr/volumes/71/rr/pdfs/rr7103a1-H.pdf"
    }
  }],
  "library" : ["http://fhir.org/guides/cdc/opioid-cds/Library/OpioidCDSREC10PatientView"],
  "action" : [{
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-strengthOfRecommendation",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/recommendation-strength",
          "code" : "weak",
          "display" : "Weak"
        }]
      }
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-qualityOfEvidence",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/evidence-quality",
          "code" : "very-low",
          "display" : "Very Low quality"
        }]
      }
    }],
    "prefix" : "1.",
    "title" : "Consider the Benefits and Risks of Conducting a Urine Toxicology Screen",
    "description" : "Consider the benefits and risks of toxicology testing to assess for prescribed medications as well as other prescribed and nonprescribed controlled substances.\r\n\r\nFor guidance regarding utilizing toxicology tests when prescribing opioids, see [Recommendation 10 of the 2022 CDC Clinical Practice Guideline](https://www.cdc.gov/mmwr/volumes/71/rr/rr7103a1.htm#:~:text=evidence%20type%3A%204).-,Implementation%20Considerations,-Toxicology%20testing%20should).",
    "priority" : "urgent",
    "trigger" : [{
      "type" : "named-event",
      "name" : "patient-view"
    }],
    "condition" : [{
      "kind" : "applicability",
      "expression" : {
        "description" : "Patient has not had a urine screening in the past 12 months",
        "language" : "text/cql.identifier",
        "expression" : "Is Perform Drug Screen Recommendation Applicable?"
      }
    }],
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/action-type",
        "code" : "create",
        "display" : "Create"
      }]
    },
    "definitionCanonical" : "http://fhir.org/guides/cdc/opioid-cds/ActivityDefinition/opioidcds-urine-screening-request",
    "action" : [{
      "description" : "Document - Ordered toxicology screen"
    },
    {
      "description" : "Document - Risks outweigh benefits"
    },
    {
      "description" : "Snooze* - N/A see comment, snooze 3 months"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-strengthOfRecommendation",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/recommendation-strength",
          "code" : "weak",
          "display" : "Weak"
        }]
      }
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-qualityOfEvidence",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/evidence-quality",
          "code" : "very-low",
          "display" : "Very Low quality"
        }]
      }
    }],
    "prefix" : "2.",
    "title" : "Patient May Have Unexpected Toxicology Test Results",
    "description" : "Patient may have unexpected urine toxicology test results in the past year",
    "priority" : "urgent",
    "trigger" : [{
      "type" : "named-event",
      "name" : "patient-view"
    }],
    "condition" : [{
      "kind" : "applicability",
      "expression" : {
        "description" : "Urine screening tested positive for cocaine, opiates or PCP",
        "language" : "text/cql.identifier",
        "expression" : "Applicable Because of Unexpected Results"
      }
    }],
    "dynamicValue" : [{
      "path" : "action.description",
      "expression" : {
        "language" : "text/cql.identifier",
        "expression" : "Detail"
      }
    }],
    "action" : [{
      "description" : "Document - Will repeat urine drug screen more frequently"
    },
    {
      "description" : "Will consult with patient regarding possible unexpected test results"
    },
    {
      "description" : "Document - Will assess patient for substance use disorder"
    },
    {
      "description" : "Snooze* - Patient's test results were expected, snooze for 3 months"
    },
    {
      "description" : "Snooze* - N/A snooze for 3 months"
    }]
  }]
}

```
