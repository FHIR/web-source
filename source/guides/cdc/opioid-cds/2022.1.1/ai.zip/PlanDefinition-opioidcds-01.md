# Recommendation #1 - Nonpharmacologic and Nonopioid Pharmacologic Therapy Consideration - 2022 CDC Clinical Practice Guideline for Prescribing Opioids Implementation Guide v2022.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Recommendation #1 - Nonpharmacologic and Nonopioid Pharmacologic Therapy Consideration**

## PlanDefinition: Recommendation #1 - Nonpharmacologic and Nonopioid Pharmacologic Therapy Consideration 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.org/guides/cdc/opioid-cds/PlanDefinition/opioidcds-01 | *Version*:2022.1.0 |
| Active as of 2025-08-06 | *Computable Name*:PlanDefinition_Recommendation_01_Order_Sign |
| *Other Identifiers:*cdc-opioid-guidance (use: official, ), OID:2.16.840.1.114222.34.1 | |
| **Usage:**Clinical Focus: Medication requested (situation), Clinical Focus: Acute pain (finding) | |
| **Copyright/Legal**: © CDC 2016+. | |

 
Nonopioid therapies are at least as effective as opioids for many common types of acute pain. Clinicians should maximize use of nonpharmacologic and nonopioid pharmacologic therapies as appropriate for the specific condition and patient and only consider opioid therapy for acute pain if benefits are anticipated to outweigh risks to the patient. Before prescribing opioid therapy for acute pain, clinicians should discuss with patients the realistic benefits and known risks of opioid therapy. 

 
The 2022 CDC Clinical Practice Guideline for Prescribing Opioids for Pain is intended to improve communication between providers and patients about the risks and benefits of opioid therapy for chronic pain, improve the safety and effectiveness of pain treatment, and reduce the risks associated with long-term opioid therapy, including opioid use disorder and overdose. The Guideline is not intended for patients who are in active cancer treatment, palliative care, or end-of-life care. 

* **Actions: **: **Url: **
  * : [Recommendation #1 - Nonpharmacologic and Nonopioid Pharmacologic Therapy Consideration](PlanDefinition-opioidcds-01.md)
* **Actions: **: **Version: **
  * : 2022.1.0
* **Actions: **: **Name: **
  * : PlanDefinition_Recommendation_01_Order_Sign
* **Actions: **: **Title: **
  * : Recommendation #1 - Nonpharmacologic and Nonopioid Pharmacologic Therapy Consideration
* **Actions: **: **Status: **
  * : active
* **Actions: **: **Experimental: **
  * : false
* **Actions: **: **Date: **
  * : 2025-08-06
* **Actions: **: **Publisher: **
  * : CDC / Security Risk Solutions, Inc. (SRS)
* **Actions: **: **Description: **
  * : Nonopioid therapies are at least as effective as opioids for many common types of acute pain. Clinicians should maximize use of nonpharmacologic and nonopioid pharmacologic therapies as appropriate for the specific condition and patient and only consider opioid therapy for acute pain if benefits are anticipated to outweigh risks to the patient. Before prescribing opioid therapy for acute pain, clinicians should discuss with patients the realistic benefits and known risks of opioid therapy.
* **Actions: **: **Knowledge Capability: **
  * : shareable computable executable publishable
* **Actions: **: **Purpose: **
  * : The 2022 CDC Clinical Practice Guideline for Prescribing Opioids for Pain is intended to improve communication between providers and patients about the risks and benefits of opioid therapy for chronic pain, improve the safety and effectiveness of pain treatment, and reduce the risks associated with long-term opioid therapy, including opioid use disorder and overdose. The Guideline is not intended for patients who are in active cancer treatment, palliative care, or end-of-life care.
* **Actions: **: **Usage: **
  * : Clinicians should consider opioid therapy only if expected benefits for both pain and function are anticipated to outweigh risks to the patient.
* **Actions: **: **Copyright: **
  * : © CDC 2016+.
* **Actions: **: **Libraries: **
  * : 
| |
| :--- |
| [Library - Recommendation #1 - Nonpharmacologic and Nonopioid Pharmacologic Therapy Consideration](Library-OpioidCDSREC01.md) |




## Resource Content

```json
{
  "resourceType" : "PlanDefinition",
  "id" : "opioidcds-01",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-recommendationdefinition",
    "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-publishableplandefinition"]
  },
  "contained" : [{
    "resourceType" : "Library",
    "id" : "effective-data-requirements",
    "name" : "EffectiveDataRequirements",
    "status" : "active",
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/library-type",
        "code" : "module-definition"
      }]
    },
    "relatedArtifact" : [{
      "type" : "depends-on",
      "display" : "Library Common",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/Library/OpioidCDSCommon|2022.1.0"
    },
    {
      "type" : "depends-on",
      "display" : "Library FHIRHelpers",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/Library/FHIRHelpers|4.0.1"
    },
    {
      "type" : "depends-on",
      "display" : "Library Routines",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/Library/OpioidCDSRoutines|2022.1.0"
    },
    {
      "type" : "depends-on",
      "display" : "Library Config",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/Library/OpioidCDSCommonConfig|2022.1.0"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Opioid analgesics with ambulatory misuse potential",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/opioid-analgesics-with-ambulatory-misuse-potential"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Community",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/medicationrequest-category-community"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Encounter Diagnosis Condition Category",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/condition-encounter-diagnosis-category"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Problem List Condition Category",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/condition-problem-list-category"
    },
    {
      "type" : "depends-on",
      "display" : "Value set US Core Health Concern Condition Category",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/condition-us-core-health-concern-category"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Sickle Cell Diseases",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/sickle-cell-diseases"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Active Condition",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/condition-clinical-status-active"
    },
    {
      "type" : "depends-on",
      "display" : "Value set CDC malignant cancer conditions",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/cdc-malignant-cancer-conditions"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Conditions likely terminal for opioid prescribing",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/conditions-likely-terminal-for-opioid-prescribing"
    }],
    "parameter" : [{
      "name" : "ContextPrescriptions",
      "use" : "in",
      "min" : 0,
      "max" : "*",
      "type" : "MedicationRequest"
    },
    {
      "name" : "Is Recommendation Applicable?",
      "use" : "out",
      "min" : 0,
      "max" : "1",
      "type" : "boolean"
    }],
    "dataRequirement" : [{
      "type" : "Medication",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Medication"],
      "mustSupport" : ["id", "code"]
    },
    {
      "type" : "Patient",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
    },
    {
      "type" : "Condition",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Condition"],
      "mustSupport" : ["category", "code", "clinicalStatus"],
      "codeFilter" : [{
        "path" : "category",
        "valueSet" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/condition-us-core-health-concern-category"
      }]
    },
    {
      "type" : "Condition",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Condition"],
      "mustSupport" : ["category",
      "code",
      "clinicalStatus",
      "encounter",
      "encounter.reference"],
      "codeFilter" : [{
        "path" : "category",
        "valueSet" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/condition-encounter-diagnosis-category"
      }]
    },
    {
      "type" : "Condition",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Condition"],
      "mustSupport" : ["category", "code", "clinicalStatus", "clinicalStatus.coding"],
      "codeFilter" : [{
        "path" : "category",
        "valueSet" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/condition-problem-list-category"
      }]
    },
    {
      "type" : "Encounter",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Encounter"],
      "mustSupport" : ["period", "period.start", "id"]
    },
    {
      "type" : "MedicationRequest",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/MedicationRequest"],
      "mustSupport" : ["authoredOn",
      "medication",
      "medication.reference",
      "id",
      "status",
      "intent",
      "category",
      "subject",
      "recorder",
      "dosageInstruction",
      "dispenseRequest",
      "status.value"]
    },
    {
      "type" : "MedicationDispense",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/MedicationDispense"],
      "mustSupport" : ["medication", "whenHandedOver", "status"],
      "codeFilter" : [{
        "path" : "medication",
        "valueSet" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/opioid-analgesics-with-ambulatory-misuse-potential"
      }]
    },
    {
      "type" : "MedicationDispense",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/MedicationDispense"],
      "mustSupport" : ["medication.reference", "whenHandedOver", "status"]
    }]
  }],
  "extension" : [{
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "shareable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "computable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "executable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "publishable"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC01"
    },
    {
      "url" : "name",
      "valueString" : "Acute Pain Opioid Analgesic with Ambulatory Misuse Potential Prescriptions"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Acute Pain Opioid Analgesic with Ambulatory Misuse Potential Prescriptions\":\n  ( Common.\"Is Opioid Analgesic with Ambulatory Misuse Potential?\"( ContextPrescriptions ) ) AmbulatoryOpioidPrescription\n    where Routines.\"Is Acute Pain Prescription?\"( AmbulatoryOpioidPrescription )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 0
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC01"
    },
    {
      "url" : "name",
      "valueString" : "Patient Is Being Prescribed Opioid Analgesic with Ambulatory Misuse Potential"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Patient Is Being Prescribed Opioid Analgesic with Ambulatory Misuse Potential\":\n  exists( \"Acute Pain Opioid Analgesic with Ambulatory Misuse Potential Prescriptions\" )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 1
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "Age Less than 18 Years Is Enabled"
    },
    {
      "url" : "statement",
      "valueString" : "// CDC 2022 General Inclusion Criteria\ndefine \"Age Less than 18 Years Is Enabled\":\n  true"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 2
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Patient Age Less Than 18"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Patient Age Less Than 18\":\n  if (Config.\"Age Less than 18 Years Is Enabled\") then\n    AgeInYearsAt(Today()) < 18\n  else false"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 3
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "Sickle Cell Check Enabled"
    },
    {
      "url" : "statement",
      "valueString" : "// Sickle Cell\ndefine \"Sickle Cell Check Enabled\":\n  true"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 4
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "Sickle Cell Assumed Active"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Sickle Cell Assumed Active\":\n  true"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 5
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "US Core-Categorized Conditions"
    },
    {
      "url" : "statement",
      "valueString" : "// 3. Medications indicating end of life\n    /* or exists (\n      \"Medications Indicating End of Life\"\n    ) */\n\ndefine \"US Core-Categorized Conditions\":\n  [Condition: category in \"Encounter Diagnosis Condition Category\"]\n    union [Condition: category in \"Problem List Condition Category\"]\n    union [Condition: category in \"US Core Health Concern Condition Category\"]"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 6
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "Positive Sickle Cell Condition"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Positive Sickle Cell Condition\":\n  if Config.\"Sickle Cell Check Enabled\" and not Config.\"Sickle Cell Assumed Active\"\n    then (\n      \"US Core-Categorized Conditions\" C\n        where C.code in \"Sickle Cell Diseases\"\n          and C.clinicalStatus in \"Active Condition\"\n    ) else if Config.\"Sickle Cell Check Enabled\" and Config.\"Sickle Cell Assumed Active\"\n        then (\n          \"US Core-Categorized Conditions\" C\n            where C.code in \"Sickle Cell Diseases\"\n        )\n      else null"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 7
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Condition Positive for Sickle Cell"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Condition Positive for Sickle Cell\":\n  if (Config.\"Sickle Cell Check Enabled\") then\n    exists(\n      Common.\"Positive Sickle Cell Condition\"\n    ) \n  else false"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 8
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "Active Cancer Treatment Encounters Condition Is Enabled"
    },
    {
      "url" : "statement",
      "valueString" : "// Active Cancer Treatment\ndefine \"Active Cancer Treatment Encounters Condition Is Enabled\":\n  true"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 9
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Encounter Period"
    },
    {
      "url" : "statement",
      "valueString" : "// End of Opioid Naive Routine\n\n/*\n**  Routine #3\n**  Active Cancer Treatment Routine\n**\n**  Definition                    | Answer to Proceed   | Details                                    | Data (Terminology) Requirement\n**  ---------------------------------------------------------------------------------------------------------------------------------\n**  Two office visits within the  | No                  | Look for a minimum of two distinct         | Office Visit\n**  past 12 months                |                     | encounters within 12 months of the date    |\n**                                |                     | of the current visit for which each of the |\n**                                |                     | following is true:                         |\n**                                |                     |   - the encounter diagnosis (primary or    |\n**                                |                     |     secondary or co-morbidity diagnosis)   |\n**                                |                     |     is listed in the CDC Malignant Cancer  |\n**                                |                     |     Conditions value set                   |\n**  ---------------------------------------------------------------------------------------------------------------------------------\n**  Office visits with an         | No                  | The encounter is performed by an           | Oncology specialty\n**  oncology specialist           |                     | oncologist as defined in the oncology      | designations (NUCC)\n**  present                       |                     | specialty designations using the           |\n**                                |                     | National Uniform Claim Committee           |\n**                                |                     | (NUCC) classifications                     |\n**  ---------------------------------------------------------------------------------------------------------------------------------\n**  Office visits including CDC   | No                  | The encounter diagnosis (primary or        | CDC malignant cancer\n**  malignant cancer              |                     | secondary or co-morbidity diagnosis)       | conditions\n**  condition                     |                     | is listed in the CDC Malignant Cancer      |\n**                                |                     | Conditions value set                       |\n**  ----------------------------------------------------------------------------------------------------------------------------------\n**\n*/\n\ndefine \"Encounter Period\":\n  Interval[Today() - 12 months, Today())"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 10
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "USCore Encounter Cancer Diagnoses"
    },
    {
      "url" : "statement",
      "valueString" : "define \"USCore Encounter Cancer Diagnoses\":\n  [Condition: category in \"Encounter Diagnosis Condition Category\"] CancerDiagnoses\n    where CancerDiagnoses.code in \"CDC malignant cancer conditions\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 11
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Encounters with Cancer Diagnosis During Encounter Period"
    },
    {
      "url" : "statement",
      "valueString" : "// encounter-diagnosis, problem-list and health-concern Conditions\n// define \"US Core-Categorized Cancer Diagnoses\":\n//   Common.\"US Core-Categorized Conditions\" C\n//     where C.code in Common.\"CDC malignant cancer conditions\"\n\n// define \"Encounters with Cancer Diagnosis During Encounter Period\":\n//   [Encounter] Encounter\n//     with \"US Core-Categorized Cancer Diagnoses\" CancerDiagnosis\n//     such that date from Encounter.period.\"start\".value in day of \"Encounter Period\"\n//       and EndsWith(CancerDiagnosis.encounter.reference, Encounter.id)\n\ndefine \"Encounters with Cancer Diagnosis During Encounter Period\":\n  [Encounter] Encounters\n    where date from Encounters.period.\"start\" in day of \"Encounter Period\"\n      and exists (\n        Common.\"USCore Encounter Cancer Diagnoses\" CancerDiagnoses\n          where EndsWith(CancerDiagnoses.encounter.reference, Encounters.id)\n      )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 12
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Number of Encounters with Cancer Diagnosis During Encounter Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Number of Encounters with Cancer Diagnosis During Encounter Period\":\n  Count (\"Encounters with Cancer Diagnosis During Encounter Period\")"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 13
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Has Two or More Encounters with Cancer Diagnosis During Encounter Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Has Two or More Encounters with Cancer Diagnosis During Encounter Period\":\n  \"Number of Encounters with Cancer Diagnosis During Encounter Period\" >= 2"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 14
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "USCore Problem List Cancer Diagnoses"
    },
    {
      "url" : "statement",
      "valueString" : "define \"USCore Problem List Cancer Diagnoses\":\n  [Condition: category in \"Problem List Condition Category\"] CancerDiagnoses\n    where CancerDiagnoses.code in \"CDC malignant cancer conditions\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 15
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Has Active Cancer Diagnosis on Problem List"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Has Active Cancer Diagnosis on Problem List\":\n  exists (\n    Common.\"USCore Problem List Cancer Diagnoses\" CancerDiagnoses\n      where CancerDiagnoses.category in Common.\"Problem List Condition Category\"\n        and exists(\n          CancerDiagnoses.clinicalStatus.coding ClinicalStatus\n            where ClinicalStatus.code ~ 'active'\n        )\n  )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 16
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Is Active Cancer Treatment?"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Is Active Cancer Treatment?\":\n  if (Config.\"Active Cancer Treatment Encounters Condition Is Enabled\") \n    then \"Has Two or More Encounters with Cancer Diagnosis During Encounter Period\"\n      or \"Has Active Cancer Diagnosis on Problem List\"\n  else false"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 17
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "End-Stage Disease Criteria Enabled"
    },
    {
      "url" : "statement",
      "valueString" : "// CDC 2022 General Inclusion Criteria\ndefine \"End-Stage Disease Criteria Enabled\":\n  true"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 18
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Conditions Likely Terminal for Opioid Prescribing"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Conditions Likely Terminal for Opioid Prescribing\":\n  if (Config.\"End-Stage Disease Criteria Enabled\") then\n    exists (\n      Common.\"US Core-Categorized Conditions\" EOLC\n        where EOLC.code in Common.\"Conditions likely terminal for opioid prescribing\"\n          // and EOLC.clinicalStatus in Common.\"Active Condition\"\n    )\n  else false"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 19
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "CDC 2022 Guideline General Inclusion Criteria"
    },
    {
      "url" : "statement",
      "valueString" : "define \"CDC 2022 Guideline General Inclusion Criteria\":\n  not \"Patient Age Less Than 18\"\n    and not \"Condition Positive for Sickle Cell\"\n    and not \"Is Active Cancer Treatment?\"\n    and not \"Conditions Likely Terminal for Opioid Prescribing\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 20
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "Opioid Naive Prescription Condition Is Enabled"
    },
    {
      "url" : "statement",
      "valueString" : "// Opioid Naive\ndefine \"Opioid Naive Prescription Condition Is Enabled\":\n  true"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 21
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "Can the implementing EHR support queries for past medications by date range?"
    },
    {
      "url" : "statement",
      "valueString" : "// Subroutine 2 - Past Medications\ndefine \"Can the implementing EHR support queries for past medications by date range?\":\n  true"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 22
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "Active Ambulatory Opioid Rx"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Active Ambulatory Opioid Rx\":\n    if Config.\"Can the implementing EHR support queries for past medications by date range?\" then\n      (\n        \"Get MedicationRequest Medication as Code\"(\"Get Active Ambulatory Medication Requests\"([MedicationRequest]))\n      ) Rx\n        where date from Rx.authoredOn 2 years or less on or before Today()\n          and Rx.medication in \"Opioid analgesics with ambulatory misuse potential\"\n    else\n        List<FHIR.MedicationRequest>{}"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 23
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Prescription/Dispense Inclusion Period"
    },
    {
      "url" : "statement",
      "valueString" : "// End of CDC 2022 General Inclusion Criteria Routine\n\n/*\n**  Routine #2\n**  Opioid Naive Routine\n**\n**  Definition                    | Answer to Proceed   | Details                                           | Data (Terminology) Requirement\n**  ----------------------------------------------------------------------------------------------------------------------------------------\n**  Opioid analgesics with        | No                  | Look for an existing prescription (order) for     | Opioid analgesics with\n**  ambulatory misuse potential   |                     | opioid that is in the value set for opioid with   | ambulatory misuse potential\n**  prescription in past 90 days  |                     | ambulatory abuse potential authored               |\n**  excluding the previous 24     |                     | within the past 90 days (excluding previous 24    |\n**  hours                         |                     | hours)                                            |\n**  ----------------------------------------------------------------------------------------------------------------------------------------\n**  Opioid analgesics with        | No                  | Look for evidence of active medication on         | Opioid analgesics with\n**  ambulatory misuse potential   |                     | the medication list that is in the value set      | ambulatory misuse potential\n**  reported in past 90 days      |                     | for opioid with ambulatory care abuse             |\n**  excluding previous 24 hours*  |                     | potential                                         |\n**  ----------------------------------------------------------------------------------------------------------------------------------------\n**  Opioid analgesics with        | No                  | Look for evidence of a dispensing event for       | Opioid analgesics with\n**  ambulatory misuse potential   |                     | medication that is in the value set for opioid    | ambulatory misuse potential\n**  dispensing event in past 90   |                     | with ambulatory use potential occurring           |\n**  days excluding previous 24    |                     | within the past 90 days (excluding previous 24    |\n**  hours                         |                     | hours)                                            |\n**  ----------------------------------------------------------------------------------------------------------------------------------------\n**  *Future consideration: Current algorithm addresses only orders (prescriptions).\n**\n**  Note – orders use RxNorm, but medication lists and dispensed medication will\n**  require an NDC value set and/or local mapping of NDC to RxNorm to enable this element\n**\n*/\n\ndefine \"Prescription/Dispense Inclusion Period\":\n  Interval[Now() - 90 days, Now() - 24 hours]"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 24
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Opioid RX with Ambulatory Abuse Potential In Past 90 Days"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Opioid RX with Ambulatory Abuse Potential In Past 90 Days\":\n  Common.\"Active Ambulatory Opioid Rx\" Rx\n      where Rx.authoredOn during day of \"Prescription/Dispense Inclusion Period\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 25
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Has Opioid RX with Ambulatory Abuse Potential In Past 90 Days"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Has Opioid RX with Ambulatory Abuse Potential In Past 90 Days\":\n    if (Config.\"Opioid Naive Prescription Condition Is Enabled\") then\n      exists (\"Opioid RX with Ambulatory Abuse Potential In Past 90 Days\")\n    else false"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 26
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Opioid Dispense with Ambulatory Abuse Potential In Past 90 Days"
    },
    {
      "url" : "statement",
      "valueString" : "// NOTE: 2020-02-05: Review direction of MedicationStatement resource (US-Core focusing on MedicationRequest i/o Statement)\n// NOTE: 2020-04-21: MedicationStatement a) Shouldn't be use since guidance/direction from USCore is targeting MedicationUse in R5, and b) Breaks in the publisher\n/* define \"Reports of Opioid with Ambulatory Care Abuse Potential Reported in Past 90 Days\":\n    [MedicationStatement: Common.\"Opioid analgesics with ambulatory misuse potential\"] Statement\n        where Statement.status in {'active', 'completed'}\n            and Statement.effective during day of \"Report Inclusion Period\" */\n\n/* define \"Has Report of Opioid with Ambulatory Care Abuse Potential Reported in Past 90 Days\":\n    Config.\"Opioid Naive Report Condition Is Enabled\"\n        and exists (\"Reports of Opioid with Ambulatory Care Abuse Potential Reported in Past 90 Days\") */\n\ndefine \"Opioid Dispense with Ambulatory Abuse Potential In Past 90 Days\":\n    [MedicationDispense: Common.\"Opioid analgesics with ambulatory misuse potential\"] OpioidDispense\n        where OpioidDispense.whenHandedOver during day of \"Prescription/Dispense Inclusion Period\"\n            and OpioidDispense.status = 'completed'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 27
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Has Opioid Dispense with Ambulatory Abuse Potential In Past 90 Days"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Has Opioid Dispense with Ambulatory Abuse Potential In Past 90 Days\":\n  if (Config.\"Opioid Naive Prescription Condition Is Enabled\") then\n    exists (\"Opioid Dispense with Ambulatory Abuse Potential In Past 90 Days\")\n  else false"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 28
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Is Opioid Naive?"
    },
    {
      "url" : "statement",
      "valueString" : "// NOTE: MedicationStatement-dependent logic comment out due to bug in Publisher not supporting MedicationStatement in AllTypes.\ndefine \"Is Opioid Naive?\":\n    not (\"Has Opioid RX with Ambulatory Abuse Potential In Past 90 Days\")\n    /* and not (\"Has Report of Opioid with Ambulatory Care Abuse Potential Reported in Past 90 Days\") */\n    and not (\"Has Opioid Dispense with Ambulatory Abuse Potential In Past 90 Days\")"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 29
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC01"
    },
    {
      "url" : "name",
      "valueString" : "Inclusion Criteria"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Inclusion Criteria\":\n  \"Patient Is Being Prescribed Opioid Analgesic with Ambulatory Misuse Potential\"\n    and Routines.\"CDC 2022 Guideline General Inclusion Criteria\"\n    and Routines.\"Is Opioid Naive?\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 30
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC01"
    },
    {
      "url" : "name",
      "valueString" : "Exclusion Criteria"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Exclusion Criteria\":\n  false"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 31
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC01"
    },
    {
      "url" : "name",
      "valueString" : "Is Recommendation Applicable?"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Is Recommendation Applicable?\":\n  \"Inclusion Criteria\"\n    and not \"Exclusion Criteria\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 32
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "Is Opioid Analgesic with Ambulatory Misuse Potential?"
    },
    {
      "url" : "statement",
      "valueString" : "define function \"Is Opioid Analgesic with Ambulatory Misuse Potential?\"(value List<MedicationRequest>):\n  (\"Get MedicationRequest Medication as Code\"(value)) Rx\n    where Rx.medication in \"Opioid analgesics with ambulatory misuse potential\" \n      and Rx.category in \"Community\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 33
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "Get MedicationRequest Medication as Code"
    },
    {
      "url" : "statement",
      "valueString" : "define function \"Get MedicationRequest Medication as Code\"(value List<MedicationRequest>):\n  value Rx\n    let Med: \n      if Rx.medication is Reference then singleton from (\n        [Medication] M\n          where M.id = (Last(Split((Rx.medication as FHIR.Reference).reference, '/')))\n      ) else null\n    return \n      MedicationRequest {\n        id: Rx.id,\n        status: Rx.status,\n        intent: Rx.intent,\n        category: Rx.category,\n        medication: if Rx.medication is Reference then Med.code else Rx.medication as CodeableConcept,\n        subject: Rx.subject,\n        authoredOn: Rx.authoredOn,\n        recorder: Rx.recorder,\n        dosageInstruction: Rx.dosageInstruction,\n        dispenseRequest: Rx.dispenseRequest\n      }"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 34
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "FHIRHelpers"
    },
    {
      "url" : "name",
      "valueString" : "ToString"
    },
    {
      "url" : "statement",
      "valueString" : "define function ToString(value string): value.value"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 35
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "FHIRHelpers"
    },
    {
      "url" : "name",
      "valueString" : "ToConcept"
    },
    {
      "url" : "statement",
      "valueString" : "define function ToConcept(concept FHIR.CodeableConcept):\n    if concept is null then\n        null\n    else\n        System.Concept {\n            codes: concept.coding C return ToCode(C),\n            display: concept.text.value\n        }"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 36
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "FHIRHelpers"
    },
    {
      "url" : "name",
      "valueString" : "ToCode"
    },
    {
      "url" : "statement",
      "valueString" : "define function ToCode(coding FHIR.Coding):\n    if coding is null then\n        null\n    else\n        System.Code {\n          code: coding.code.value,\n          system: coding.system.value,\n          version: coding.version.value,\n          display: coding.display.value\n        }"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 37
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Is Acute Pain Prescription?"
    },
    {
      "url" : "statement",
      "valueString" : "// End of For Subacute or Chronic Pain Routine\n\n/*\n**  Routine #5\n**  For Acute Pain Routine\n**\n**  Definition                  | Answer to Proceed   | Details                                        | Data (Terminology) Requirement\n**  -----------------------------------------------------------------------------------------------------------------------------------\n**  Order for opioid analgesics | Yes                 | Look for an existing prescription (order) for  | Opioid analgesics with\n**  with ambulatory misuse      |                     | opioid analgesics with ambulatory abuse        | ambulatory misuse potential\n**  potential of duration < 28  |                     | potential of duration < 28 days                |\n**  days                        |                     |                                                |\n**  -----------------------------------------------------------------------------------------------------------------------------------\n**\n*/\n\n// should allow DateTime precision, but not working in the Ruler specifically\ndefine function \"Is Acute Pain Prescription?\"(prescription FHIR.MedicationRequest):\n  prescription.dispenseRequest is not null\n    and prescription.dispenseRequest.expectedSupplyDuration is not null\n    and Common.GetDurationInDays( prescription.dispenseRequest.expectedSupplyDuration ) < 28 days"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 38
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "GetDurationInDays"
    },
    {
      "url" : "statement",
      "valueString" : "define function GetDurationInDays(value FHIR.Duration):\n  if value is null then null\n  else\n    case\n      when value.code.value ~ 'a' then System.Quantity{ value: value.value.value * 365.0, unit: 'days' }\n      when value.code.value ~ 'mo' then System.Quantity{ value: value.value.value * 30.0, unit: 'days' }\n      when value.code.value ~ 'wk' then System.Quantity{ value: value.value.value * 7.0, unit: 'days' }\n      when value.code.value ~ 'd' then System.Quantity{ value: value.value.value, unit: 'days' }\n      when value.code.value ~ 'h' then System.Quantity{ value: value.value.value / 24.0, unit: 'days' }\n      when value.code.value ~ 'min' then System.Quantity{ value: value.value.value / 60.0 / 24.0, unit: 'days' }\n      when value.code.value ~ 's' then System.Quantity{ value: value.value.value / 60.0 / 60.0 / 24.0, unit: 'days' }\n      when value.code.value ~ 'ms' then System.Quantity{ value: value.value.value / 60.0 / 60.0 / 24.0 / 1000.0, unit: 'days' }\n      when value.code.value is null then Message(1000, true, 'Undefined', 'Error', 'Duration unit code is null')\n      else Message(1000, true, 'Undefined', 'Error', 'Unsupported duration unit code: ' + value.code.value)\nend"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 39
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "FHIRHelpers"
    },
    {
      "url" : "name",
      "valueString" : "ToDateTime"
    },
    {
      "url" : "statement",
      "valueString" : "define function ToDateTime(value dateTime): value.value"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 40
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "Get Active Ambulatory Medication Requests"
    },
    {
      "url" : "statement",
      "valueString" : "define function \"Get Active Ambulatory Medication Requests\" (value List<MedicationRequest>) returns List<MedicationRequest>:\n  value Rx\n    where Rx.status.value = 'active'\n      and Rx.category in \"Community\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 41
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "FHIRHelpers"
    },
    {
      "url" : "name",
      "valueString" : "ToString"
    },
    {
      "url" : "statement",
      "valueString" : "define function ToString(value MedicationDispenseStatus): value.value"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 42
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "id" : "effective-data-requirements",
    "url" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-effectiveDataRequirements",
    "valueCanonical" : "#effective-data-requirements"
  },
  {
    "url" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-softwaresystem",
    "valueReference" : {
      "reference" : "Device/cqf-tooling"
    }
  }],
  "url" : "http://fhir.org/guides/cdc/opioid-cds/PlanDefinition/opioidcds-01",
  "identifier" : [{
    "use" : "official",
    "value" : "cdc-opioid-guidance"
  },
  {
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.16.840.1.114222.34.1"
  }],
  "version" : "2022.1.0",
  "name" : "PlanDefinition_Recommendation_01_Order_Sign",
  "title" : "Recommendation #1 - Nonpharmacologic and Nonopioid Pharmacologic Therapy Consideration",
  "type" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/plan-definition-type",
      "code" : "eca-rule",
      "display" : "ECA Rule"
    }]
  },
  "status" : "active",
  "experimental" : false,
  "date" : "2025-08-06",
  "publisher" : "CDC / Security Risk Solutions, Inc. (SRS)",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.securityrisksolutions.com"
    }]
  }],
  "description" : "Nonopioid therapies are at least as effective as opioids for many common types of acute pain. Clinicians should maximize use of nonpharmacologic and nonopioid pharmacologic therapies as appropriate for the specific condition and patient and only consider opioid therapy for acute pain if benefits are anticipated to outweigh risks to the patient. Before prescribing opioid therapy for acute pain, clinicians should discuss with patients the realistic benefits and known risks of opioid therapy.",
  "useContext" : [{
    "code" : {
      "system" : "http://terminology.hl7.org/CodeSystem/usage-context-type",
      "code" : "focus",
      "display" : "Clinical Focus"
    },
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "182888003",
        "display" : "Medication requested (situation)"
      }]
    }
  },
  {
    "code" : {
      "system" : "http://terminology.hl7.org/CodeSystem/usage-context-type",
      "code" : "focus",
      "display" : "Clinical Focus"
    },
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "274663001",
        "display" : "Acute pain (finding)"
      }]
    }
  }],
  "purpose" : "The 2022 CDC Clinical Practice Guideline for Prescribing Opioids for Pain is intended to improve communication between providers and patients about the risks and benefits of opioid therapy for chronic pain, improve the safety and effectiveness of pain treatment, and reduce the risks associated with long-term opioid therapy, including opioid use disorder and overdose. The Guideline is not intended for patients who are in active cancer treatment, palliative care, or end-of-life care.",
  "usage" : "Clinicians should consider opioid therapy only if expected benefits for both pain and function are anticipated to outweigh risks to the patient.",
  "copyright" : "© CDC 2016+.",
  "topic" : [{
    "text" : "Opioid Prescribing"
  }],
  "author" : [{
    "name" : "Kensaku Kawamoto, MD, PhD, MHS"
  },
  {
    "name" : "Bryn Rhodes"
  },
  {
    "name" : "Floyd Eisenberg, MD, MPH"
  },
  {
    "name" : "Robert McClure, MD, MPH"
  }],
  "relatedArtifact" : [{
    "type" : "documentation",
    "display" : "2022 CDC Clinical Practice Guideline for Prescribing Opioids for Pain",
    "url" : "https://www.cdc.gov/mmwr/volumes/71/rr/rr7103a1.htm",
    "document" : {
      "url" : "https://www.cdc.gov/mmwr/volumes/71/rr/rr7103a1.htm"
    }
  }],
  "library" : ["http://fhir.org/guides/cdc/opioid-cds/Library/OpioidCDSREC01"],
  "action" : [{
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-strengthOfRecommendation",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/recommendation-strength",
          "code" : "weak",
          "display" : "Weak"
        }]
      }
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-qualityOfEvidence",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/evidence-quality",
          "code" : "low",
          "display" : "Low quality"
        }]
      }
    }],
    "title" : "Consider Nonopioid Treatment Options for Acute Pain",
    "description" : "For many types of acute pain, clinicians should maximize the use of nonpharmacologic (for example, physical therapy) and nonopioid pharmacologic therapies (for example, NSAIDs), as appropriate for the specific condition and patient and only consider opioid therapy for acute pain if benefits are anticipated to outweigh risks to the patient. Before prescribing opioid therapy for acute pain, clinicians should discuss with patients the realistic benefits and known risks of opioid therapy.\r\n\r\n[Recommendation 1 of the 2022 CDC Clinical Practice Guideline](https://www.cdc.gov/mmwr/volumes/71/rr/rr7103a1.htm#Recommendation1) provides nonopioid therapy options for common acute pain conditions.\r\n\r\n**Nonopioid Pharmacological Therapy**\r\n- [Dental pain (acute)](https://www.cdc.gov/mmwr/volumes/71/rr/rr7103a1.htm#:~:text=The%20American%20Dental%20Association%20(ADA)%20recommends%20NSAIDs%20as%20first%2Dline%20treatment%20for%20acute%20dental%20pain%20management)\r\n- [Dental pain (surgical)](https://www.cdc.gov/mmwr/volumes/71/rr/rr7103a1.htm#:~:text=NSAIDs%20have%20been%20found%20to%20be%20more%20effective%20than%20opioids%20for%20surgical%20dental%20pain)\r\n- [Kidney stone pain (acute)](https://www.cdc.gov/mmwr/volumes/71/rr/rr7103a1.htm#:~:text=For%20acute%20kidney%20stone%20pain%2C%20NSAIDs%20are%20at%20least%20as%20effective%20as%20opioids%20(124%E2%80%93127)%2C%20can%20decrease%20the%20ureteral%20smooth%20muscle%20tone%20and%20ureteral%20spasm%20(128)%20causing%20kidney%20stone%20pain%2C%20and%20are%20preferred%20for%20kidney%20stone%20pain%20if%20not%20contraindicated.)\r\n- [Low back pain (acute)](https://www.cdc.gov/mmwr/volumes/71/rr/rr7103a1.htm#:~:text=NSAIDs%20have%20been%20found%20to%20be%20more%20effective%20than%20opioids%20for%20surgical%20dental%20pain%20and%20kidney%20stone%20pain%20and%20similarly%20effective%20to%20opioids%20for%20low%20back%20pain)\r\n- [Migraine pain (episodic)](https://www.cdc.gov/mmwr/volumes/71/rr/rr7103a1.htm#:~:text=For%20episodic%20migraine%2C%20triptans%2C%20NSAIDs%2C%20antiemetics%2C%20dihydroergotamine%2C%20calcitonin%20gene%2Drelated%20peptide%20antagonists%20(gepants)%2C%20and%20lasmiditan%20are%20associated%20with%20improved%20pain%20and%20function%20with%20usually%20mild%20and%20transient%20adverse%20events)\r\n- [Musculoskeletal pain](https://www.cdc.gov/mmwr/volumes/71/rr/rr7103a1.htm#:~:text=A%20systematic%20review%20found%20that%20for%20musculoskeletal%20injuries%20such%20as%20sprains%2C%20whiplash%2C%20and%20muscle%20strains%2C%20topical%20NSAIDs%20provided%20the%20greatest%20benefit%2Dharm%20ratio%2C%20followed%20by%20oral%20NSAIDs%20or%20acetaminophen%20with%20or%20without%20diclofenac)\r\n- [Postpartum pain](https://www.cdc.gov/mmwr/volumes/71/rr/rr7103a1.htm#:~:text=Pain%20Management%20for%20Pregnant%20and%20Postpartum%20Persons)\r\n\r\n**Nonpharmacologic Treatments**\r\n- [Back pain (acute)](https://www.cdc.gov/mmwr/volumes/71/rr/rr7103a1.htm#:~:text=The%20American%20College%20of%20Physicians%20(ACP)%20recommends%20nonpharmacologic%20treatment%20with%20superficial%20heat%2C%20massage%2C%20acupuncture%2C%20or%20spinal%20manipulation%20as%20a%20cornerstone%20of%20treatment%20for%20acute%20low%20back%20pain)\r\n- [Migraine pain (episodic)](https://www.cdc.gov/mmwr/volumes/71/rr/rr7103a1.htm#:~:text=remote%20electrical%20neuromodulation%20for%20acute%20pain%20related%20to%20episodic%20migraine)\r\n- [Musculoskeletal pain](https://www.cdc.gov/mmwr/volumes/71/rr/rr7103a1.htm#:~:text=acupressure%20for%20acute%20musculoskeletal%20pain)\r\n- [Postoperative pain](https://www.cdc.gov/mmwr/volumes/71/rr/rr7103a1.htm#:~:text=massage%20for%20postoperative%20pain)",
    "priority" : "urgent",
    "trigger" : [{
      "type" : "named-event",
      "name" : "order-sign"
    }],
    "condition" : [{
      "kind" : "applicability",
      "expression" : {
        "description" : "Check whether the current order is for an opioid with ambulatory misuse potential, the patient is opioid naive and if the 2022 CDC guideline general inclusion criteria is met",
        "language" : "text/cql.identifier",
        "expression" : "Is Recommendation Applicable?"
      }
    }],
    "groupingBehavior" : "visual-group",
    "selectionBehavior" : "any",
    "action" : [{
      "description" : "Document - Record reason for opioid therapy"
    },
    {
      "description" : "Snooze* - Attempt alternative therapy, snooze 3 months"
    },
    {
      "description" : "Order - Select alternative therapies from order set"
    },
    {
      "description" : "Snooze* - N/A see comment, snooze 3 months"
    },
    {
      "description" : "Remove - Will remove triggering medication order"
    }]
  }]
}

```
