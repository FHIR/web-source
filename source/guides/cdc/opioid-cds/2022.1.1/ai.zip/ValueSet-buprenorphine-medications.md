# Buprenorphine Medications - 2022 CDC Clinical Practice Guideline for Prescribing Opioids Implementation Guide v2022.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Buprenorphine Medications**

## ValueSet: Buprenorphine Medications 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.org/guides/cdc/opioid-cds/ValueSet/buprenorphine-medications | *Version*:2022.1.1 |
| Active as of 2025-02-24 | *Computable Name*:BUPRENORPHINE_MEDICATIONS |
| *Other Identifiers:*OID:2.16.840.1.113883.4.642.40.65.48.59 | |
| **Copyright/Legal**: © CDC 2016+. | |

 
All Buprenorphine medications 

 
Buprenorphine medications for opioid management 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

This ValueSet does not have a formal definition; instead, the value set must be prepared by hand using these instructions.

https://mor.nlm.nih.gov/RxMix/ Script: Step 1 Upload to RxMix a workflow config file named GetRelatedByType.config containing the following workflow text: <WFE><filteredOutputs>RXCUI|name|term_type</filteredOutputs><input>NOINPUT</input><FS><service>NOINPUT</service><function>getRelatedByType</function><level>0</level><paramSize>2</paramSize><param order ='0'>?</param><param order ='1'>BPCK,GPCK,SBD,SCD</param></FS></WFE>

Step 2 Create Batch text input file (Ingredients.txt) with following RxNorm Buprenorphine as an input within the file: 1819

Step 3 Upload the batch text input file Ingredients.txt created in step 2.

Step 4 Submit the batch which will run the workflow using the input codes to generate a combined set of all the concepts needed..

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "buprenorphine-medications",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-computablevalueset",
    "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-executablevalueset"]
  },
  "extension" : [{
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-clinical-focus",
    "valueString" : "Buprenorphine medications"
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-dataelement-scope",
    "valueString" : "Medication"
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-inclusion-criteria",
    "valueString" : "All Buprenorphine medications"
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-exclusion-criteria",
    "valueString" : "None"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-author",
    "valueContactDetail" : {
      "name" : "MD Partners, Inc.",
      "telecom" : [{
        "system" : "email",
        "value" : "info@mdpartners.com"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "computable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "executable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeRepresentationLevel",
    "valueCode" : "structured"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeRepresentationLevel",
    "valueCode" : "executable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-usageWarning",
    "valueString" : "This value set contains a point-in-time expansion enumerating the codes that meet the value set intent. As new versions of the code systems used by the value set are released, the contents of this expansion will need to be updated to incorporate newly defined codes that meet the value set intent. Before, and periodically during production use, the value set expansion contents SHOULD be updated. The value set expansion specifies the timestamp when the expansion was produced, SHOULD contain the parameters used for the expansion, and SHALL contain the codes that are obtained by evaluating the value set definition. If this is ONLY an executable value set, a distributable definition of the value set must be obtained to compute the updated expansion."
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-rules-text",
    "valueMarkdown" : "https://mor.nlm.nih.gov/RxMix/ Script: \r\nStep 1 Upload to RxMix a workflow config file  named GetRelatedByType.config containing the following workflow text: <WFE><filteredOutputs>RXCUI|name|term_type</filteredOutputs><input>NOINPUT</input><FS><service>NOINPUT</service><function>getRelatedByType</function><level>0</level><paramSize>2</paramSize><param order ='0'>?</param><param order ='1'>BPCK,GPCK,SBD,SCD</param></FS></WFE> \r\n\r\nStep 2 Create Batch text input file (Ingredients.txt) with following RxNorm Buprenorphine as an input within the file:\r\n1819\r\n\r\nStep 3 Upload the batch text input file Ingredients.txt created in step 2. \r\n\r\nStep 4 Submit the batch which will run the workflow using the input codes to generate a combined set of all the concepts needed..\r\n"
  }],
  "url" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/buprenorphine-medications",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.16.840.1.113883.4.642.40.65.48.59"
  }],
  "version" : "2022.1.1",
  "name" : "BUPRENORPHINE_MEDICATIONS",
  "title" : "Buprenorphine Medications",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-02-24T13:06:39-07:00",
  "publisher" : "CDC / Security Risk Solutions, Inc. (SRS)",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.securityrisksolutions.com"
    }]
  }],
  "description" : "All Buprenorphine medications",
  "purpose" : "Buprenorphine medications for opioid management",
  "copyright" : "© CDC 2016+.",
  "expansion" : {
    "identifier" : "urn:uuid:bcd99597-fed7-4838-882c-2c58f52a4d9c",
    "timestamp" : "2025-02-24T13:06:39-07:00",
    "total" : 83,
    "parameter" : [{
      "name" : "used-codesystem",
      "valueUri" : "http://www.nlm.nih.gov/research/umls/rxnorm|03022026"
    },
    {
      "name" : "version",
      "valueUri" : "http://www.nlm.nih.gov/research/umls/rxnorm|03022026"
    }],
    "contains" : [{
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1010603",
      "display" : "buprenorphine 2 MG / naloxone 0.5 MG Sublingual Film [Suboxone]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1010606",
      "display" : "buprenorphine 8 MG / naloxone 2 MG Sublingual Film [Suboxone]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1307058",
      "display" : "buprenorphine 4 MG / naloxone 1 MG Sublingual Film [Suboxone]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1307063",
      "display" : "buprenorphine 12 MG / naloxone 3 MG Sublingual Film [Suboxone]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1431083",
      "display" : "buprenorphine 1.4 MG / naloxone 0.36 MG Sublingual Tablet [Zubsolv]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1431104",
      "display" : "buprenorphine 5.7 MG / naloxone 1.4 MG Sublingual Tablet [Zubsolv]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1432971",
      "display" : "168 HR buprenorphine 0.015 MG/HR Transdermal System [BuTrans]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1542396",
      "display" : "buprenorphine 2.1 MG / naloxone 0.3 MG Buccal Film [Bunavail]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1542999",
      "display" : "168 HR buprenorphine 0.0075 MG/HR Transdermal System [BuTrans]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1544853",
      "display" : "buprenorphine 4.2 MG / naloxone 0.7 MG Buccal Film [Bunavail]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1544856",
      "display" : "buprenorphine 6.3 MG / naloxone 1 MG Buccal Film [Bunavail]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1594655",
      "display" : "buprenorphine 1.8 MG/ML Injectable Solution [Simbadol]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1597570",
      "display" : "buprenorphine 11.4 MG / naloxone 2.9 MG Sublingual Tablet [Zubsolv]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1597575",
      "display" : "buprenorphine 8.6 MG / naloxone 2.1 MG Sublingual Tablet [Zubsolv]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1666385",
      "display" : "buprenorphine 2.9 MG / naloxone 0.71 MG Sublingual Tablet [Zubsolv]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716063",
      "display" : "buprenorphine 0.15 MG Buccal Film [Belbuca]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716067",
      "display" : "buprenorphine 0.3 MG Buccal Film [Belbuca]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716071",
      "display" : "buprenorphine 0.45 MG Buccal Film [Belbuca]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716075",
      "display" : "buprenorphine 0.6 MG Buccal Film [Belbuca]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716079",
      "display" : "buprenorphine 0.075 MG Buccal Film [Belbuca]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716083",
      "display" : "buprenorphine 0.75 MG Buccal Film [Belbuca]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716090",
      "display" : "buprenorphine 0.9 MG Buccal Film [Belbuca]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1797655",
      "display" : "buprenorphine 74.2 MG Drug Implant [Probuphine]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1864414",
      "display" : "buprenorphine 0.7 MG / naloxone 0.18 MG Sublingual Tablet [Zubsolv]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1996189",
      "display" : "0.5 ML buprenorphine 200 MG/ML Prefilled Syringe [Sublocade]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1996193",
      "display" : "1.5 ML buprenorphine 200 MG/ML Prefilled Syringe [Sublocade]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "205533",
      "display" : "1 ML buprenorphine 0.3 MG/ML Injection [Buprenex]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2599851",
      "display" : "buprenorphine 20 MG/ML Topical Solution [Zorbium]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2639027",
      "display" : "0.16 ML buprenorphine 50 MG/ML Prefilled Syringe [Brixadi]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2639030",
      "display" : "0.32 ML buprenorphine 50 MG/ML Prefilled Syringe [Brixadi]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2639032",
      "display" : "0.48 ML buprenorphine 50 MG/ML Prefilled Syringe [Brixadi]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2639034",
      "display" : "0.64 ML buprenorphine 50 MG/ML Prefilled Syringe [Brixadi]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2639039",
      "display" : "0.18 ML buprenorphine 356 MG/ML Prefilled Syringe [Brixadi]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2639042",
      "display" : "0.27 ML buprenorphine 356 MG/ML Prefilled Syringe [Brixadi]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2639044",
      "display" : "0.36 ML buprenorphine 356 MG/ML Prefilled Syringe [Brixadi]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "904874",
      "display" : "168 HR buprenorphine 0.01 MG/HR Transdermal System [BuTrans]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "904878",
      "display" : "168 HR buprenorphine 0.02 MG/HR Transdermal System [BuTrans]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "904882",
      "display" : "168 HR buprenorphine 0.005 MG/HR Transdermal System [BuTrans]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1010600",
      "display" : "buprenorphine 2 MG / naloxone 0.5 MG Sublingual Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1010604",
      "display" : "buprenorphine 8 MG / naloxone 2 MG Sublingual Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1307056",
      "display" : "buprenorphine 4 MG / naloxone 1 MG Sublingual Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1307061",
      "display" : "buprenorphine 12 MG / naloxone 3 MG Sublingual Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1431076",
      "display" : "buprenorphine 1.4 MG / naloxone 0.36 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1431102",
      "display" : "buprenorphine 5.7 MG / naloxone 1.4 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1432969",
      "display" : "168 HR buprenorphine 0.015 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1542390",
      "display" : "buprenorphine 2.1 MG / naloxone 0.3 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1542997",
      "display" : "168 HR buprenorphine 0.0075 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1544851",
      "display" : "buprenorphine 4.2 MG / naloxone 0.7 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1544854",
      "display" : "buprenorphine 6.3 MG / naloxone 1 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1594650",
      "display" : "buprenorphine 1.8 MG/ML Injectable Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1597568",
      "display" : "buprenorphine 11.4 MG / naloxone 2.9 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1597573",
      "display" : "buprenorphine 8.6 MG / naloxone 2.1 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1655032",
      "display" : "1 ML buprenorphine 0.3 MG/ML Cartridge"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1666338",
      "display" : "buprenorphine 2.9 MG / naloxone 0.71 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716057",
      "display" : "buprenorphine 0.15 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716065",
      "display" : "buprenorphine 0.3 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716069",
      "display" : "buprenorphine 0.45 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716073",
      "display" : "buprenorphine 0.6 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716077",
      "display" : "buprenorphine 0.075 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716081",
      "display" : "buprenorphine 0.75 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716086",
      "display" : "buprenorphine 0.9 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1797650",
      "display" : "buprenorphine 74.2 MG Drug Implant"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1864412",
      "display" : "buprenorphine 0.7 MG / naloxone 0.18 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1996184",
      "display" : "0.5 ML buprenorphine 200 MG/ML Prefilled Syringe"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1996192",
      "display" : "1.5 ML buprenorphine 200 MG/ML Prefilled Syringe"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "238129",
      "display" : "1 ML buprenorphine 0.3 MG/ML Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "246474",
      "display" : "buprenorphine 0.2 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "250426",
      "display" : "buprenorphine 0.4 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2599846",
      "display" : "buprenorphine 20 MG/ML Topical Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2639021",
      "display" : "0.16 ML buprenorphine 50 MG/ML Prefilled Syringe"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2639029",
      "display" : "0.32 ML buprenorphine 50 MG/ML Prefilled Syringe"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2639031",
      "display" : "0.48 ML buprenorphine 50 MG/ML Prefilled Syringe"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2639033",
      "display" : "0.64 ML buprenorphine 50 MG/ML Prefilled Syringe"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2639036",
      "display" : "0.18 ML buprenorphine 356 MG/ML Prefilled Syringe"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2639041",
      "display" : "0.27 ML buprenorphine 356 MG/ML Prefilled Syringe"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2639043",
      "display" : "0.36 ML buprenorphine 356 MG/ML Prefilled Syringe"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "351264",
      "display" : "buprenorphine 2 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "351265",
      "display" : "buprenorphine 8 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "351266",
      "display" : "buprenorphine 2 MG / naloxone 0.5 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "351267",
      "display" : "buprenorphine 8 MG / naloxone 2 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "904870",
      "display" : "168 HR buprenorphine 0.01 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "904876",
      "display" : "168 HR buprenorphine 0.02 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "904880",
      "display" : "168 HR buprenorphine 0.005 MG/HR Transdermal System"
    }]
  }
}

```
