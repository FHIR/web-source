# Benzodiazepine medications - 2022 CDC Clinical Practice Guideline for Prescribing Opioids Implementation Guide v2022.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Benzodiazepine medications**

## ValueSet: Benzodiazepine medications 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.org/guides/cdc/opioid-cds/ValueSet/benzodiazepine-medications | *Version*:2022.1.1 |
| Active as of 2025-02-24 | *Computable Name*:BENZODIAZEPINE_MEDICATIONS |
| *Other Identifiers:*OID:2.16.840.1.114222.48.4 | |
| **Copyright/Legal**: © CDC 2016+. | |

 
All benzodiazepine clinical drugs 

 
Benzodiazepine medications for opioid management 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

This ValueSet does not have a formal definition; instead, the value set must be prepared by hand using these instructions.

https://mor.nlm.nih.gov/RxMix/ Script: Step 1a Create Batch text input file (SCT-benzo.txt) with following SCT identifier (for the concept "Product containing benzodiazepine (product)") as an input within the file: 16047007

Step 1b Submit batch job using the above SCT-benzo.txt file to following workflow by uploading file (SCT-benzo.config) with the following in the file: <WFE><filteredOutputs>RXCUI|name|term_type</filteredOutputs><input>NOINPUT</input><FS><service>NOINPUT</service><function>findClassById</function><level>0</level><paramSize>1</paramSize><param order ='0'>?</param></FS><FS><service>NOINPUT</service><function>getClassMembers</function><level>1</level><paramSize>5</paramSize><param order ='0'>?</param><param order ='1'>SNOMEDCT</param><param order ='2'>isa_structure</param><param order ='3'>0</param><param order ='4'>IN,MIN,PIN</param></FS><FS><service>NOINPUT</service><function>getRelatedByType</function><level>2</level><paramSize>2</paramSize><param order ='0'>?</param><param order ='1'>BPCK,GPCK,SBD,SCD</param></FS></WFE> This will produce a result file with all benzodiazepine clinical drugs included.

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "benzodiazepine-medications",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-computablevalueset",
    "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-executablevalueset"]
  },
  "extension" : [{
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-clinical-focus",
    "valueString" : "All benzodiazepine clinical drugs"
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-dataelement-scope",
    "valueString" : "Medication"
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-inclusion-criteria",
    "valueString" : "All benzodiazepine-class medications"
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-exclusion-criteria",
    "valueString" : "None"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-author",
    "valueContactDetail" : {
      "name" : "MD Partners, Inc.",
      "telecom" : [{
        "system" : "email",
        "value" : "info@mdpartners.com"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "computable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "executable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-usageWarning",
    "valueString" : "This value set contains a point-in-time expansion enumerating the codes that meet the value set intent. As new versions of the code systems used by the value set are released, the contents of this expansion will need to be updated to incorporate newly defined codes that meet the value set intent. Before, and periodically during production use, the value set expansion contents SHOULD be updated. The value set expansion specifies the timestamp when the expansion was produced, SHOULD contain the parameters used for the expansion, and SHALL contain the codes that are obtained by evaluating the value set definition. If this is ONLY an executable value set, a distributable definition of the value set must be obtained to compute the updated expansion."
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-rules-text",
    "valueMarkdown" : "https://mor.nlm.nih.gov/RxMix/ Script:\r\nStep 1a \r\nCreate Batch text input file (SCT-benzo.txt) with following SCT identifier (for the concept \"Product containing benzodiazepine (product)\") as an input within the file: \r\n16047007       \r\n\r\nStep 1b\r\nSubmit batch job using the above SCT-benzo.txt file to following workflow by uploading file (SCT-benzo.config) with the following in the file:  <WFE><filteredOutputs>RXCUI|name|term_type</filteredOutputs><input>NOINPUT</input><FS><service>NOINPUT</service><function>findClassById</function><level>0</level><paramSize>1</paramSize><param order ='0'>?</param></FS><FS><service>NOINPUT</service><function>getClassMembers</function><level>1</level><paramSize>5</paramSize><param order ='0'>?</param><param order ='1'>SNOMEDCT</param><param order ='2'>isa_structure</param><param order ='3'>0</param><param order ='4'>IN,MIN,PIN</param></FS><FS><service>NOINPUT</service><function>getRelatedByType</function><level>2</level><paramSize>2</paramSize><param order ='0'>?</param><param order ='1'>BPCK,GPCK,SBD,SCD</param></FS></WFE>\r\nThis will produce a result file with all benzodiazepine clinical drugs included."
  }],
  "url" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/benzodiazepine-medications",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.16.840.1.114222.48.4"
  }],
  "version" : "2022.1.1",
  "name" : "BENZODIAZEPINE_MEDICATIONS",
  "title" : "Benzodiazepine medications",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-02-24T13:06:39-07:00",
  "publisher" : "CDC / Security Risk Solutions, Inc. (SRS)",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.securityrisksolutions.com"
    }]
  }],
  "description" : "All benzodiazepine clinical drugs",
  "purpose" : "Benzodiazepine medications for opioid management",
  "copyright" : "© CDC 2016+.",
  "expansion" : {
    "identifier" : "urn:uuid:482d7312-bf2d-4f10-9e84-0605000906c3",
    "timestamp" : "2025-02-24T13:06:39-07:00",
    "total" : 207,
    "parameter" : [{
      "name" : "used-codesystem",
      "valueUri" : "http://www.nlm.nih.gov/research/umls/rxnorm|03022026"
    },
    {
      "name" : "version",
      "valueUri" : "http://www.nlm.nih.gov/research/umls/rxnorm|03022026"
    }],
    "contains" : [{
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "208463",
      "display" : "temazepam 7.5 MG Oral Capsule [Restoril]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "208464",
      "display" : "temazepam 15 MG Oral Capsule [Restoril]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "208465",
      "display" : "temazepam 30 MG Oral Capsule [Restoril]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "539384",
      "display" : "temazepam 22.5 MG Oral Capsule [Restoril]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "104693",
      "display" : "temazepam 20 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "151283",
      "display" : "temazepam 2 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "198241",
      "display" : "temazepam 15 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "198242",
      "display" : "temazepam 30 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "198243",
      "display" : "temazepam 7.5 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "199975",
      "display" : "temazepam 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "485489",
      "display" : "temazepam 22.5 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "208681",
      "display" : "triazolam 0.25 MG Oral Tablet [Halcion]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "198317",
      "display" : "triazolam 0.125 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "198318",
      "display" : "triazolam 0.25 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "104707",
      "display" : "bromazepam 1.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "199436",
      "display" : "bromazepam 3 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "199437",
      "display" : "bromazepam 6 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1191056",
      "display" : "clobazam 10 MG Oral Tablet [Onfi]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1191058",
      "display" : "clobazam 20 MG Oral Tablet [Onfi]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1366196",
      "display" : "clobazam 2.5 MG/ML Oral Suspension [Onfi]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2102713",
      "display" : "clobazam 10 MG Oral Film [Sympazan]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2102715",
      "display" : "clobazam 20 MG Oral Film [Sympazan]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2102717",
      "display" : "clobazam 5 MG Oral Film [Sympazan]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1366192",
      "display" : "clobazam 2.5 MG/ML Oral Suspension"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "199450",
      "display" : "clobazam 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2058253",
      "display" : "clobazam 10 MG Oral Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2058254",
      "display" : "clobazam 20 MG Oral Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2058255",
      "display" : "clobazam 5 MG Oral Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "246172",
      "display" : "clobazam 20 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "427538",
      "display" : "clobazam 5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1149627",
      "display" : "clorazepate dipotassium 7.5 MG Oral Tablet [Tranxene]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "542857",
      "display" : "clorazepate dipotassium 15 MG Oral Tablet [Tranxene]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "542967",
      "display" : "clorazepate dipotassium 3.75 MG Oral Tablet [Tranxene]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1251277",
      "display" : "clorazepate dipotassium 11.3 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "197464",
      "display" : "clorazepate dipotassium 15 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "197465",
      "display" : "clorazepate dipotassium 3.75 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "197466",
      "display" : "clorazepate dipotassium 7.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "576647",
      "display" : "clorazepate dipotassium 15 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "618739",
      "display" : "clorazepate dipotassium 22.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "618751",
      "display" : "clorazepate dipotassium 7.5 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "889616",
      "display" : "chlordiazepoxide hydrochloride 5 MG / clidinium bromide 2.5 MG Oral Capsule [Librax]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "249035",
      "display" : "chlordiazepoxide 5 MG / clidinium bromide 2.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "856769",
      "display" : "amitriptyline hydrochloride 12.5 MG / chlordiazepoxide 5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "856792",
      "display" : "amitriptyline hydrochloride 25 MG / chlordiazepoxide 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "856863",
      "display" : "amitriptyline hydrochloride 12.5 MG / chlordiazepoxide 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "889614",
      "display" : "chlordiazepoxide hydrochloride 5 MG / clidinium bromide 2.5 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "905369",
      "display" : "chlordiazepoxide hydrochloride 10 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "905495",
      "display" : "chlordiazepoxide hydrochloride 25 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "905505",
      "display" : "chlordiazepoxide hydrochloride 25 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "905516",
      "display" : "chlordiazepoxide hydrochloride 5 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "905521",
      "display" : "chlordiazepoxide hydrochloride 5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "905532",
      "display" : "chlordiazepoxide hydrochloride 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2383951",
      "display" : "remimazolam 20 MG Injection [Byfavo]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2383946",
      "display" : "remimazolam 20 MG Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "206157",
      "display" : "clonazepam 0.5 MG Oral Tablet [Klonopin]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "206159",
      "display" : "clonazepam 1 MG Oral Tablet [Klonopin]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "206160",
      "display" : "clonazepam 2 MG Oral Tablet [Klonopin]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "197527",
      "display" : "clonazepam 0.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "197528",
      "display" : "clonazepam 1 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "197529",
      "display" : "clonazepam 2 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "349194",
      "display" : "clonazepam 0.125 MG Disintegrating Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "349195",
      "display" : "clonazepam 0.25 MG Disintegrating Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "349196",
      "display" : "clonazepam 1 MG Disintegrating Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "349197",
      "display" : "clonazepam 2 MG Disintegrating Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "349198",
      "display" : "clonazepam 0.5 MG Disintegrating Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "387007",
      "display" : "clonazepam 0.1 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "387008",
      "display" : "clonazepam 0.4 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "197747",
      "display" : "halazepam 20 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "197748",
      "display" : "halazepam 40 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "199763",
      "display" : "lormetazepam 1 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "250487",
      "display" : "lormetazepam 0.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2272622",
      "display" : "{1 (0.1 ML) (diazepam 100 MG/ML Nasal Spray [Valtoco]) } Pack [Valtoco 10 MG Dose Kit]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2272624",
      "display" : "{2 (0.1 ML) (diazepam 100 MG/ML Nasal Spray [Valtoco]) } Pack [Valtoco 20 MG Dose Kit]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2272630",
      "display" : "{1 (0.1 ML) (diazepam 50 MG/ML Nasal Spray [Valtoco]) } Pack [Valtoco 5 MG Dose Kit]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2272636",
      "display" : "{2 (0.1 ML) (diazepam 75 MG/ML Nasal Spray [Valtoco]) } Pack [Valtoco 15 MG Dose Kit]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2272621",
      "display" : "{1 (0.1 ML) (diazepam 100 MG/ML Nasal Spray) } Pack"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2272623",
      "display" : "{2 (0.1 ML) (diazepam 100 MG/ML Nasal Spray) } Pack"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2272627",
      "display" : "{1 (0.1 ML) (diazepam 50 MG/ML Nasal Spray) } Pack"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2272633",
      "display" : "{2 (0.1 ML) (diazepam 75 MG/ML Nasal Spray) } Pack"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "104699",
      "display" : "diazepam 2 MG Oral Tablet [Valium]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "104700",
      "display" : "diazepam 5 MG Oral Tablet [Valium]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "104701",
      "display" : "diazepam 10 MG Oral Tablet [Valium]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2272619",
      "display" : "diazepam 100 MG/ML Nasal Spray [Valtoco]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2272629",
      "display" : "diazepam 50 MG/ML Nasal Spray [Valtoco]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2272635",
      "display" : "diazepam 75 MG/ML Nasal Spray [Valtoco]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2682570",
      "display" : "diazepam 5 MG Buccal Film [Libervant]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2682573",
      "display" : "diazepam 10 MG Buccal Film [Libervant]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2682577",
      "display" : "diazepam 12.5 MG Buccal Film [Libervant]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2682580",
      "display" : "diazepam 15 MG Buccal Film [Libervant]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2682583",
      "display" : "diazepam 7.5 MG Buccal Film [Libervant]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "801958",
      "display" : "0.5 ML diazepam 5 MG/ML Rectal Gel [Diastat]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "801962",
      "display" : "2 ML diazepam 5 MG/ML Rectal Gel [Diastat]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "801965",
      "display" : "4 ML diazepam 5 MG/ML Rectal Gel [Diastat]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "104706",
      "display" : "diazepam 10 MG Rectal Suppository"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "105032",
      "display" : "diazepam 5 MG/ML Injectable Suspension"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "108379",
      "display" : "diazepam 0.5 MG/ML Oral Suspension"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "108380",
      "display" : "diazepam 2 MG/ML Oral Suspension"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "141926",
      "display" : "diazepam 0.4 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1807452",
      "display" : "2 ML diazepam 5 MG/ML Auto-Injector"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1807459",
      "display" : "2 ML diazepam 5 MG/ML Cartridge"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "197589",
      "display" : "diazepam 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "197590",
      "display" : "diazepam 2 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "197591",
      "display" : "diazepam 5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2120550",
      "display" : "2 ML diazepam 5 MG/ML Prefilled Syringe"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2272613",
      "display" : "diazepam 100 MG/ML Nasal Spray"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2272626",
      "display" : "diazepam 50 MG/ML Nasal Spray"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2272632",
      "display" : "diazepam 75 MG/ML Nasal Spray"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2682564",
      "display" : "diazepam 5 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2682571",
      "display" : "diazepam 10 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2682575",
      "display" : "diazepam 12.5 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2682578",
      "display" : "diazepam 15 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2682581",
      "display" : "diazepam 7.5 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "309843",
      "display" : "diazepam 1 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "309844",
      "display" : "diazepam 5 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "309845",
      "display" : "diazepam 5 MG/ML Injectable Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "422657",
      "display" : "diazepam 4 MG/ML Enema"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "422658",
      "display" : "diazepam 2 MG/ML Enema"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "801957",
      "display" : "0.5 ML diazepam 5 MG/ML Rectal Gel"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "801961",
      "display" : "2 ML diazepam 5 MG/ML Rectal Gel"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "801966",
      "display" : "4 ML diazepam 5 MG/ML Rectal Gel"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "207889",
      "display" : "quazepam 15 MG Oral Tablet [Doral]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "198183",
      "display" : "quazepam 15 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "198184",
      "display" : "quazepam 7.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "197653",
      "display" : "estazolam 1 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "197654",
      "display" : "estazolam 2 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "104683",
      "display" : "flunitrazepam 1 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1298088",
      "display" : "flurazepam hydrochloride 15 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1298091",
      "display" : "flurazepam hydrochloride 30 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "141927",
      "display" : "alprazolam 0.25 MG Oral Tablet [Xanax]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "141928",
      "display" : "alprazolam 0.5 MG Oral Tablet [Xanax]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "214003",
      "display" : "alprazolam 1 MG Oral Tablet [Xanax]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "214004",
      "display" : "alprazolam 2 MG Oral Tablet [Xanax]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "687022",
      "display" : "24 HR alprazolam 3 MG Extended Release Oral Tablet [Xanax]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "687023",
      "display" : "24 HR alprazolam 2 MG Extended Release Oral Tablet [Xanax]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "687024",
      "display" : "24 HR alprazolam 1 MG Extended Release Oral Tablet [Xanax]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "687025",
      "display" : "24 HR alprazolam 0.5 MG Extended Release Oral Tablet [Xanax]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "197321",
      "display" : "alprazolam 1 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "197322",
      "display" : "alprazolam 2 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "308047",
      "display" : "alprazolam 0.25 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "308048",
      "display" : "alprazolam 0.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "308049",
      "display" : "alprazolam 0.1 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "308050",
      "display" : "alprazolam 1 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "433798",
      "display" : "24 HR alprazolam 0.5 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "433799",
      "display" : "24 HR alprazolam 2 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "433800",
      "display" : "24 HR alprazolam 1 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "433801",
      "display" : "24 HR alprazolam 3 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "485413",
      "display" : "alprazolam 0.25 MG Disintegrating Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "485414",
      "display" : "alprazolam 1 MG Disintegrating Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "485415",
      "display" : "alprazolam 0.5 MG Disintegrating Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "485416",
      "display" : "alprazolam 2 MG Disintegrating Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "104719",
      "display" : "lorazepam 1 MG Oral Tablet [Ativan]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1665190",
      "display" : "1 ML lorazepam 2 MG/ML Injection [Ativan]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1665327",
      "display" : "1 ML lorazepam 4 MG/ML Injection [Ativan]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "206819",
      "display" : "lorazepam 2 MG/ML Injectable Solution [Ativan]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "206820",
      "display" : "lorazepam 4 MG/ML Injectable Solution [Ativan]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "206821",
      "display" : "lorazepam 0.5 MG Oral Tablet [Ativan]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "206828",
      "display" : "lorazepam 2 MG Oral Tablet [Ativan]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2569571",
      "display" : "24 HR lorazepam 1 MG Extended Release Oral Capsule [Loreev]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2569575",
      "display" : "24 HR lorazepam 2 MG Extended Release Oral Capsule [Loreev]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2569580",
      "display" : "24 HR lorazepam 3 MG Extended Release Oral Capsule [Loreev]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2594603",
      "display" : "24 HR lorazepam 1.5 MG Extended Release Oral Capsule [Loreev]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1665188",
      "display" : "1 ML lorazepam 2 MG/ML Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1665326",
      "display" : "1 ML lorazepam 4 MG/ML Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "197900",
      "display" : "lorazepam 0.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "197901",
      "display" : "lorazepam 1 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "197902",
      "display" : "lorazepam 2 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "199275",
      "display" : "lorazepam 2.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "238100",
      "display" : "lorazepam 2 MG/ML Injectable Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "238101",
      "display" : "lorazepam 4 MG/ML Injectable Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2569564",
      "display" : "24 HR lorazepam 1 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2569573",
      "display" : "24 HR lorazepam 2 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2569577",
      "display" : "24 HR lorazepam 3 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2594600",
      "display" : "24 HR lorazepam 1.5 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "311376",
      "display" : "lorazepam 2 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "763028",
      "display" : "1 ML lorazepam 2 MG/ML Cartridge"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2057964",
      "display" : "midazolam 5 MG/ML Injectable Solution [Seizalam]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2173500",
      "display" : "midazolam 50 MG/ML Nasal Spray [Nayzilam]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "106517",
      "display" : "midazolam 2 MG/ML Injectable Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1551393",
      "display" : "2 ML midazolam 5 MG/ML Prefilled Syringe"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1551395",
      "display" : "1 ML midazolam 5 MG/ML Prefilled Syringe"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1666777",
      "display" : "2 ML midazolam 1 MG/ML Cartridge"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1666798",
      "display" : "2 ML midazolam 1 MG/ML Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1666800",
      "display" : "5 ML midazolam 1 MG/ML Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1666814",
      "display" : "1 ML midazolam 5 MG/ML Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1666821",
      "display" : "1 ML midazolam 5 MG/ML Cartridge"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1666823",
      "display" : "2 ML midazolam 5 MG/ML Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "199775",
      "display" : "midazolam 7.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2173494",
      "display" : "midazolam 50 MG/ML Nasal Spray"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "248630",
      "display" : "midazolam 15 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2541170",
      "display" : "50 ML midazolam 1 MG/ML Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2541171",
      "display" : "100 ML midazolam 1 MG/ML Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2608698",
      "display" : "0.7 ML midazolam 14.3 MG/ML Auto-Injector"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "311700",
      "display" : "midazolam 1 MG/ML Injectable Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "311702",
      "display" : "midazolam 5 MG/ML Injectable Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "422410",
      "display" : "midazolam 2 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "998211",
      "display" : "2 ML midazolam 1 MG/ML Prefilled Syringe"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "108880",
      "display" : "nitrazepam 1 MG/ML Oral Suspension"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "141922",
      "display" : "nitrazepam 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "141923",
      "display" : "nitrazepam 0.5 MG/ML Oral Suspension"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "199492",
      "display" : "nitrazepam 5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "198057",
      "display" : "oxazepam 10 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "198058",
      "display" : "oxazepam 15 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "198059",
      "display" : "oxazepam 30 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "312133",
      "display" : "oxazepam 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "312134",
      "display" : "oxazepam 15 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "312135",
      "display" : "oxazepam 30 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "312590",
      "display" : "prazepam 10 MG Oral Tablet"
    }]
  }
}

```
