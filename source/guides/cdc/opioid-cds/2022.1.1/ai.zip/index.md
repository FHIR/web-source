# Home - 2022 CDC Clinical Practice Guideline for Prescribing Opioids Implementation Guide v2022.1.1

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://fhir.org/guides/cdc/opioid-cds/ImplementationGuide/fhir.cdc.opioid-cds | *Version*:2022.1.1 |
| Active as of 2026-03-07 | *Computable Name*:Opioid_CDC |
| *Other Identifiers:*OID:2.16.840.1.113883.4.642.40.65 | |
| **Copyright/Legal**: Centers for Disease Control and Prevention (CDC) | |

### Introduction

This implementation guide (IG) provides resources and discussion in support of applying the [Centers for Disease Control and Prevention (CDC) 2022 CDC Clinical Practice Guideline for Prescribing Opioids for Pain](https://www.cdc.gov/mmwr/volumes/71/rr/rr7103a1.htm), including support for the following guideline recommendations:

* [Recommendation #1 - Nonpharmacologic and Nonopioid Pharmacologic Therapy Consideration](recommendation-01.md)
* [Recommendation #2 - Prioritize Nonopioid Pain Therapies](recommendation-02.md)
* [Recommendation #3 - Opioid Immediate Release Form When Starting Opioid Therapy](recommendation-03.md)
* [Recommendations #4 and #5 - Lowest Effective Dose](recommendation-04-05.md)
* [Recommendation #6 - Prescribe Lowest Effective Dose and Duration](recommendation-06.md)
* [Recommendation #7 - Opioid Therapy Risk Assessment](recommendation-07.md)
* [Recommendation #8 - Naloxone Consideration](recommendation-08.md)
* [Recommendation #9 - Consider Patient’s History of Controlled Substance Prescriptions](recommendation-09.md)
* [Recommendation #10 - Urine Drug Testing](recommendation-10.md)
* [Recommendation #11 - Concurrent Use of Opioids and Benzodiazepines](recommendation-11.md)
* [Recommendation #12 - Evidence-based Treatment for Patients with Opioid Use Disorder](recommendation-12.md)

For further details on how the behaviors for the artifacts were determined, refer to the [Process Documentation](process-documentation.md).

### Background

This implementation guide was developed based on work initially done as part of the [Clinical Quality Framework (CQF)](https://confluence.hl7.org/display/CQIWC/Clinical+Quality+Framework) Initiative, a public-private partnership sponsored by the Centers for Medicare & Medicaid Services (CMS) and the U.S. Assistant Secretary for Technology Policy/Office of the National Coordinator for Health Information Technology (ASTP/ONC), to identify, develop, and harmonize standards for clinical decision support and electronic clinical quality measurement, as well as a joint effort by the CDC and ASTP/ONC focused on improving processes for the development of standardized, shareable, computable decision support artifacts using the [2022 CDC Clinical Practice Guideline for Prescribing Opioids for Pain](https://www.cdc.gov/mmwr/volumes/71/rr/rr7103a1.htm) as a model case.

### Feedback and Discussion

Discussions on the use of this IG happen at the [HL7 Clinical Decision Support (CDS) Workgroup](https://confluence.hl7.org/spaces/CDS/pages/40742688/WorkGroup+Home). Feedback and contributions are welcome and can be raised with the CDS Workgroup or submitted directly using the **New Issue** link in the footer of every page.

### Related IGs

#### CPG IG

This implementation guide has followed and applied the [methodology laid out by the HL7 Clinical Practice Guideline (CPG) IG](https://www.hl7.org/fhir/uv/cpg/methodology.html). The CPG IG offers an abstract high-level methodology for translating clinical guidelines into electronic Clinical Decision Support (eCDS) artifacts based on the following steps:

* **Select**: Select content and recommendations for implementation
* **Represent**: Apply selected recommendations to the implementation approach
* **Translate**: Formally express concepts, flow diagrams, and narrative content
* **Validate**: Build and run test cases to verify expected functionality

The following diagram depicts the relationship and (navigable) links between the artifacts in the CPG IG and their respective instantiations in this IG.

![](assets/images/cpg-ig-diagram.svg)

#### Data Exchange Profiles IG

The [HL7 Data Exchange Profiles for 2022 CDC Clinical Practice Guideline for Prescribing Opioids](https://build.fhir.org/ig/HL7/cdc-opioid-cpg/) has been developed to define a set of conformance requirements for supporting the data queries used in this implementation guide. By conforming to these profiles (which are derived from US Core) EHRs can ensure they are prepared to support the integration with this IG.

### Trigger Overview

This implementation guide [assumes](process-documentation.md#technical-assumptions) that [CDS Hooks](http://cds-hooks.hl7.org/index.html) serves as the technical framework for EHR integration. The table below outlines the supported triggering events for each guideline recommendation:

| | | | |
| :--- | :--- | :--- | :--- |
| [Recommendation 1](recommendation-01.md) |   |   | ✓ |
| [Recommendation 2](recommendation-02.md) |   |   | ✓ |
| [Recommendation 3](recommendation-03.md) |   |   | ✓ |
| [Recommendation 4](recommendation-04-05.md) |   |   | ✓ |
| [Recommendation 5](recommendation-04-05.md) |   |   | ✓ |
| [Recommendation 6](recommendation-06.md) |   |   | ✓ |
| [Recommendation 7](recommendation-07.md) |   |   | ✓ |
| [Recommendation 8](recommendation-08.md) |   |   | ✓ |
| [Recommendation 9](recommendation-09.md) |   |   | ✓ |
| [Recommendation 10](recommendation-10.md) | ✓* |   | ✓ |
| [Recommendation 11](recommendation-11.md) | ✓* | ✓ |   |
| [Recommendation 12](recommendation-12.md) | ✓ |   |   |

(*) Developed for implementations without capabilities to support the preferred trigger.

### Morphine Milligram Equivalent (MME) Calculation Cautions

1. All doses are in mg/day except for fentanyl, which is mcg/hr.
1. Equianalgesic dose conversions are only estimates and cannot account for individual variability in genetics and pharmacokinetics.
1. Do not use the calculated dose in MMEs to determine the doses to use when converting one opioid to another; when converting opioids, the new opioid is typically dosed at a substantially lower dose than the calculated MME dose to avoid overdose because of incomplete cross-tolerance and individual variability in opioid pharmacokinetics. Consult the FDA approved product labeling for specific guidance on medications.
1. Use particular caution with methadone dose conversions because methadone has a long and variable half-life, and peak respiratory depressant effect occurs later and lasts longer than peak analgesic effect.
1. Use particular caution with transdermal fentanyl because it is dosed in mcg/hr instead of mg/day, and its absorption is affected by heat and other factors.
1. Buprenorphine products approved for the treatment of pain are not included in the table because of their partial µ-receptor agonist activity and resultant ceiling effects compared with full µ-receptor agonists.
1. These conversion factors should not be applied to dosage decisions related to the management of opioid use disorder.

#### Morphine milligram equivalent doses for commonly prescribed opioids for pain management table

| | |
| :--- | :--- |
| Codeine | 0.15 |
| Fentanyl transdermal (in mcg/hr) | 2.4 |
| Hydrocodone | 1.0 |
| Hydromorphone | 5.0 |
| Methadone | 4.7 |
| Morphine | 1.0 |
| Oxycodone | 1.5 |
| Oxymorphone | 3.0 |
| Tapentadol * | 0.4 |
| Tramadol ** | 0.2 |

* Tapentadol is a µ-receptor agonist and norepinephrine reuptake inhibitor. MMEs are based on degree of µ-receptor agonist activity; however, it is unknown whether tapentadol is associated with overdose in the same dose-dependent manner as observed with medications that are solely µ-receptor agonists.

** Tramadol is a µ-receptor agonist and norepinephrine and serotonin reuptake inhibitor. MMEs are based on degree of µ-receptor agonist activity; however, it is unknown whether tramadol is associated with overdose in the same dose-dependent manner as observed with medications that are solely µ-receptor agonists.

### Credits

**Project Team**

* Johnathan Coleman (Security Risk Solutions)
* Mohammad Jafari, PhD (Security Risk Solutions)
* Kensaku Kawamoto, MD, PhD, MHS (Independent)
* Robert McClure, MD (Independent)
* Amber Patel (Security Risk Solutions)
* Bryn Rhodes (Smile CDR)
* Chris Schuler (Smile CDR)
* Greg White (Security Risk Solutions)

**Government Leadership**

* Mera Choi (ASTP)
* Alison Kemp, MPH (ASTP)
* Anastasia Perchem (ASTP)
* Adam Wong, MPP (ASTP)

### Intellectual Property

This publication includes IP covered under the following statements.

* © Copyright 2022 American Medical Association

* [NUCC Provider Taxonomy](http://tx.fhir.org/r4/ValueSet/nucc-provider-taxonomy): [Encounter/oncologist-participant](Encounter-oncologist-participant.md), [ONCOLOGY_SPECIALTY_DESIGNATIONS](ValueSet-oncology-specialty-designations.md) and [PractitionerRole/oncology-specialist](PractitionerRole-oncology-specialist.md)


* Centers for Disease Control and Prevention (CDC)

* [CDC Opioid Override Reasons](CodeSystem-opioidcds-overrideReasons.md): [PlanDefinition_Recommendation_10_Order_Sign](PlanDefinition-opioidcds-10-order-sign.md)


* Copyright 2019+ Centers for Disease Control and Prevention (CDC)

* [CDC MME Usage Context Codes](http://fhir.org/guides/cdc/opioid-mme-r4/3.0.0/CodeSystem-CDCMMEUsageContextCodes.html): [PlanDefinition_Recommendation_04_05_Order_Sign](PlanDefinition-opioidcds-04-05.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/5.5.0/CodeSystem-v3-loinc.html): [ALL_URINE_DRUG_SCREENING_TESTS](ValueSet-all-urine-drug-screening-tests.md), [AMPHETAMINE_URINE_DRUG_SCREENING_TESTS](ValueSet-amphetamine-urine-drug-screening-tests.md)... Show 18 more, [BARBITURATE_URINE_DRUG_SCREENING_TESTS](ValueSet-barbiturate-urine-drug-screening-tests.md), [BENZODIAZEPINE_URINE_DRUG_SCREENING_TESTS](ValueSet-benzodiazepine-urine-drug-screening-tests.md), [BUPRENORPHINE_URINE_DRUG_SCREENING_TESTS](ValueSet-buprenorphine-urine-drug-screening-tests.md), [CANNABINOID_URINE_DRUG_SCREENING_TESTS](ValueSet-cannabinoid-urine-drug-screening-tests.md), [COCAINE_URINE_DRUG_SCREENING_TESTS](ValueSet-cocaine-urine-drug-screening-tests.md), [FENTANYL_TYPE_URINE_DRUG_SCREENING_TESTS](ValueSet-fentanyl-type-urine-drug-screening-tests.md), [GENERAL_OPIATE_URINE_DRUG_SCREENING_TESTS](ValueSet-general-opiate-urine-drug-screening-tests.md), [HEROIN_URINE_DRUG_SCREENING_TESTS](ValueSet-heroin-urine-drug-screening-tests.md), [METHADONE_URINE_DRUG_SCREENING_TESTS](ValueSet-methadone-urine-drug-screening-tests.md), [NON_OPIOID_URINE_DRUG_SCREENING](ValueSet-non-opioid-urine-drug-screening.md), [OPIATE_SPECIFIC_URINE_DRUG_SCREENING_TESTS](ValueSet-opiate-specific-urine-drug-screening-tests.md), [OPIOID_URINE_DRUG_SCREENING](ValueSet-opioid-urine-drug-screening.md), [OXYCODONE_URINE_DRUG_SCREENING_TESTS](ValueSet-oxycodone-urine-drug-screening-tests.md), [Observation/example-opioidcds](Observation-example-opioidcds.md), [PAIN_TREATMENT_PLAN](ValueSet-pain-treatment-plan.md), [PHENCYCLIDINE_URINE_DRUG_SCREENING_TESTS](ValueSet-phencyclidine-urine-drug-screening-tests.md), [SYNTHETIC_OPIOID_URINE_DRUG_SCREENING_TESTS](ValueSet-synthetic-opioid-urine-drug-screening-tests.md) and [XYLAZINE_URINE_DRUG_SCREENING_TESTS](ValueSet-xylazine-urine-drug-screening-tests.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [ActivityDefinition_Risk_Assessment_ServiceRequest](ActivityDefinition-opioidcds-risk-assessment-request.md), [ActivityDefinition_Urine_Screening_ServiceRequest](ActivityDefinition-opioidcds-urine-screening-request.md)... Show 39 more, [CONDITIONS_DOCUMENTING_SUBSTANCE_ABUSE](ValueSet-conditions-documenting-substance-misuse.md), [CONDITIONS_LIKELY_TERMINAL_FOR_OPIOID_PRESCRIBING](ValueSet-conditions-likely-terminal-for-opioid-prescribing.md), [Condition/end-of-life](Condition-end-of-life.md), [Condition/terminal](Condition-terminal.md), [ConversionFactors](Library-ConversionFactors.md), [HOSPICE_DISPOSITION](ValueSet-hospice-disposition.md), [HOSPICE_FINDING](ValueSet-hospice-finding.md), [HOSPICE_PROCEDURE](ValueSet-hospice-procedure.md), [LIMITED_LIFE_EXPECTANCY_CONDITIONS](ValueSet-limited-life-expectancy-conditions.md), [MMECalculator](Library-MMECalculator.md), [MedicationRequest/example-opioidcds](MedicationRequest-example-opioidcds.md), [OFFICE_VISIT](ValueSet-office-visit.md), [OMTKData](Library-OMTKData.md), [OMTKLogic](Library-OMTKLogic.md), [OPIOID_COUNSELING_PROCEDURE](ValueSet-opioid-counseling-procedure.md), [OPIOID_MISUSE_ASSESSMENT_PROCEDURE](ValueSet-opioid-misuse-assessment-procedure.md), [OPIOID_MISUSE_DISORDERS](ValueSet-opioid-misuse-disorders.md), [OPIOID_TREATMENT_ASSESSMENT_PROCEDURE](ValueSet-opioid-treatment-assessment-procedure.md), [PAIN_MANAGEMENT_PROCEDURE](ValueSet-pain-management-procedure.md), [PDMP_DATA_REVIEWED_FINDING](ValueSet-pdmp-data-reviewed-finding.md), [PDMP_REVIEW_PROCEDURE](ValueSet-pdmp-review-procedure.md), [PlanDefinition_Recommendation_01_Order_Sign](PlanDefinition-opioidcds-01.md), [PlanDefinition_Recommendation_02_Order_Sign](PlanDefinition-opioidcds-02.md), [PlanDefinition_Recommendation_03_Order_Sign](PlanDefinition-opioidcds-03.md), [PlanDefinition_Recommendation_04_05_Order_Sign](PlanDefinition-opioidcds-04-05.md), [PlanDefinition_Recommendation_06_Order_Sign](PlanDefinition-opioidcds-06.md), [PlanDefinition_Recommendation_07_Order_Sign](PlanDefinition-opioidcds-07.md), [PlanDefinition_Recommendation_08_Order_Sign](PlanDefinition-opioidcds-08.md), [PlanDefinition_Recommendation_09_Order_Sign](PlanDefinition-opioidcds-09.md), [PlanDefinition_Recommendation_10_Order_Sign](PlanDefinition-opioidcds-10-order-sign.md), [PlanDefinition_Recommendation_10_Patient_View](PlanDefinition-opioidcds-10-patient-view.md), [PlanDefinition_Recommendation_11_Order_Select](PlanDefinition-opioidcds-11-order-select.md), [PlanDefinition_Recommendation_11_Patient_View](PlanDefinition-opioidcds-11-patient-view.md), [PlanDefinition_Recommendation_12_Patient_View](PlanDefinition-opioidcds-12-patient-view.md), [SICKLE_CELL_DISEASES](ValueSet-sickle-cell-diseases.md), [SLEEP_DISORDERED_BREATHING](ValueSet-conditions-documenting-sleep-disordered-breathing.md), [SUBSTANCE_MISUSE_BEHAVIORAL_COUNSELING](ValueSet-substance-misuse-behavioral-counseling.md), [ServiceRequest/palliative-care](ServiceRequest-palliative-care.md) and [THERAPIES_INDICATING_END_OF_LIFE_CARE](ValueSet-therapies-indicating-end-of-life-care.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [ActionType](http://terminology.hl7.org/7.3.0/CodeSystem-action-type.html): [PlanDefinition_Recommendation_07_Order_Sign](PlanDefinition-opioidcds-07.md) and [PlanDefinition_Recommendation_10_Patient_View](PlanDefinition-opioidcds-10-patient-view.md)
* [Condition Category Codes](http://terminology.hl7.org/7.3.0/CodeSystem-condition-category.html): [Condition/cancer-diagnosis](Condition-cancer-diagnosis.md), [Condition/terminal](Condition-terminal.md), [ENCOUNTER_DIAGNOSIS_CONDITION_CATEGORY](ValueSet-condition-encounter-diagnosis-category.md) and [PROBLEM_LIST_CONDITION_CATEGORY](ValueSet-condition-problem-list-category.md)
* [Condition Clinical Status Codes](http://terminology.hl7.org/7.3.0/CodeSystem-condition-clinical.html): [CONDITION_CLINICAL_STATUS_ACTIVE](ValueSet-condition-clinical-status-active.md), [Condition/cancer-diagnosis](Condition-cancer-diagnosis.md), [Condition/end-of-life](Condition-end-of-life.md) and [Condition/terminal](Condition-terminal.md)
* [DefinitionTopic](http://terminology.hl7.org/7.3.0/CodeSystem-definition-topic.html): [ActivityDefinition_Risk_Assessment_ServiceRequest](ActivityDefinition-opioidcds-risk-assessment-request.md) and [ActivityDefinition_Urine_Screening_ServiceRequest](ActivityDefinition-opioidcds-urine-screening-request.md)
* [DoseAndRateType](http://terminology.hl7.org/7.3.0/CodeSystem-dose-rate-type.html): [MedicationRequest/example-opioidcds](MedicationRequest-example-opioidcds.md)
* [QualityOfEvidenceRating](http://terminology.hl7.org/7.3.0/CodeSystem-evidence-quality.html): [PlanDefinition_Recommendation_01_Order_Sign](PlanDefinition-opioidcds-01.md), [PlanDefinition_Recommendation_02_Order_Sign](PlanDefinition-opioidcds-02.md)... Show 11 more, [PlanDefinition_Recommendation_03_Order_Sign](PlanDefinition-opioidcds-03.md), [PlanDefinition_Recommendation_04_05_Order_Sign](PlanDefinition-opioidcds-04-05.md), [PlanDefinition_Recommendation_06_Order_Sign](PlanDefinition-opioidcds-06.md), [PlanDefinition_Recommendation_07_Order_Sign](PlanDefinition-opioidcds-07.md), [PlanDefinition_Recommendation_08_Order_Sign](PlanDefinition-opioidcds-08.md), [PlanDefinition_Recommendation_09_Order_Sign](PlanDefinition-opioidcds-09.md), [PlanDefinition_Recommendation_10_Order_Sign](PlanDefinition-opioidcds-10-order-sign.md), [PlanDefinition_Recommendation_10_Patient_View](PlanDefinition-opioidcds-10-patient-view.md), [PlanDefinition_Recommendation_11_Order_Select](PlanDefinition-opioidcds-11-order-select.md), [PlanDefinition_Recommendation_11_Patient_View](PlanDefinition-opioidcds-11-patient-view.md) and [PlanDefinition_Recommendation_12_Patient_View](PlanDefinition-opioidcds-12-patient-view.md)
* [LibraryType](http://terminology.hl7.org/7.3.0/CodeSystem-library-type.html): [CDCMMEClinicalConversionFactors](Library-CDCMMEClinicalConversionFactors.md), [ConversionFactors](Library-ConversionFactors.md)... Show 39 more, [FHIR](Library-FHIR-ModelInfo.md), [FHIRHelpers](Library-FHIRHelpers.md), [HelloWorld](Library-HelloWorld.md), [HelloWorldPatientView](Library-HelloWorldPatientView.md), [MMECalculator](Library-MMECalculator.md), [OMTKData](Library-OMTKData.md), [OMTKData2020](Library-OMTKData2020.md), [OMTKLogic](Library-OMTKLogic.md), [OMTKLogicMK2020](Library-OMTKLogicMK2020.md), [OpioidCDSCommon](Library-OpioidCDSCommon.md), [OpioidCDSCommonConfig](Library-OpioidCDSCommonConfig.md), [OpioidCDSREC01](Library-OpioidCDSREC01.md), [OpioidCDSREC02](Library-OpioidCDSREC02.md), [OpioidCDSREC03](Library-OpioidCDSREC03.md), [OpioidCDSREC04And05](Library-OpioidCDSREC04And05.md), [OpioidCDSREC06](Library-OpioidCDSREC06.md), [OpioidCDSREC07](Library-OpioidCDSREC07.md), [OpioidCDSREC08](Library-OpioidCDSREC08.md), [OpioidCDSREC09](Library-OpioidCDSREC09.md), [OpioidCDSREC10Common](Library-OpioidCDSREC10Common.md), [OpioidCDSREC10OrderSign](Library-OpioidCDSREC10OrderSign.md), [OpioidCDSREC10PatientView](Library-OpioidCDSREC10PatientView.md), [OpioidCDSREC11OrderSelect](Library-OpioidCDSREC11OrderSelect.md), [OpioidCDSREC11PatientView](Library-OpioidCDSREC11PatientView.md), [OpioidCDSREC12PatientView](Library-OpioidCDSREC12PatientView.md), [OpioidCDSRoutines](Library-OpioidCDSRoutines.md), [PlanDefinition_Recommendation_01_Order_Sign](PlanDefinition-opioidcds-01.md), [PlanDefinition_Recommendation_02_Order_Sign](PlanDefinition-opioidcds-02.md), [PlanDefinition_Recommendation_03_Order_Sign](PlanDefinition-opioidcds-03.md), [PlanDefinition_Recommendation_04_05_Order_Sign](PlanDefinition-opioidcds-04-05.md), [PlanDefinition_Recommendation_06_Order_Sign](PlanDefinition-opioidcds-06.md), [PlanDefinition_Recommendation_07_Order_Sign](PlanDefinition-opioidcds-07.md), [PlanDefinition_Recommendation_08_Order_Sign](PlanDefinition-opioidcds-08.md), [PlanDefinition_Recommendation_09_Order_Sign](PlanDefinition-opioidcds-09.md), [PlanDefinition_Recommendation_10_Order_Sign](PlanDefinition-opioidcds-10-order-sign.md), [PlanDefinition_Recommendation_10_Patient_View](PlanDefinition-opioidcds-10-patient-view.md), [PlanDefinition_Recommendation_11_Order_Select](PlanDefinition-opioidcds-11-order-select.md), [PlanDefinition_Recommendation_11_Patient_View](PlanDefinition-opioidcds-11-patient-view.md) and [PlanDefinition_Recommendation_12_Patient_View](PlanDefinition-opioidcds-12-patient-view.md)
* [MedicationRequest Category Codes](http://terminology.hl7.org/7.3.0/CodeSystem-medicationrequest-category.html): [MedicationRequest/ambulatory-opioid](MedicationRequest-ambulatory-opioid.md) and [Valueset_medicationrequest_category_community](ValueSet-medicationrequest-category-community.md)
* [Observation Category Codes](http://terminology.hl7.org/7.3.0/CodeSystem-observation-category.html): [OBSERVATION_CATEGORY_LABORATORY](ValueSet-observation-category-laboratory.md) and [OBSERVATION_CATEGORY_PROCEDURE](ValueSet-observation-category-procedure.md)
* [PlanDefinitionType](http://terminology.hl7.org/7.3.0/CodeSystem-plan-definition-type.html): [PlanDefinition_Recommendation_01_Order_Sign](PlanDefinition-opioidcds-01.md), [PlanDefinition_Recommendation_02_Order_Sign](PlanDefinition-opioidcds-02.md)... Show 11 more, [PlanDefinition_Recommendation_03_Order_Sign](PlanDefinition-opioidcds-03.md), [PlanDefinition_Recommendation_04_05_Order_Sign](PlanDefinition-opioidcds-04-05.md), [PlanDefinition_Recommendation_06_Order_Sign](PlanDefinition-opioidcds-06.md), [PlanDefinition_Recommendation_07_Order_Sign](PlanDefinition-opioidcds-07.md), [PlanDefinition_Recommendation_08_Order_Sign](PlanDefinition-opioidcds-08.md), [PlanDefinition_Recommendation_09_Order_Sign](PlanDefinition-opioidcds-09.md), [PlanDefinition_Recommendation_10_Order_Sign](PlanDefinition-opioidcds-10-order-sign.md), [PlanDefinition_Recommendation_10_Patient_View](PlanDefinition-opioidcds-10-patient-view.md), [PlanDefinition_Recommendation_11_Order_Select](PlanDefinition-opioidcds-11-order-select.md), [PlanDefinition_Recommendation_11_Patient_View](PlanDefinition-opioidcds-11-patient-view.md) and [PlanDefinition_Recommendation_12_Patient_View](PlanDefinition-opioidcds-12-patient-view.md)
* [StrengthOfRecommendationRating](http://terminology.hl7.org/7.3.0/CodeSystem-recommendation-strength.html): [PlanDefinition_Recommendation_01_Order_Sign](PlanDefinition-opioidcds-01.md), [PlanDefinition_Recommendation_02_Order_Sign](PlanDefinition-opioidcds-02.md)... Show 11 more, [PlanDefinition_Recommendation_03_Order_Sign](PlanDefinition-opioidcds-03.md), [PlanDefinition_Recommendation_04_05_Order_Sign](PlanDefinition-opioidcds-04-05.md), [PlanDefinition_Recommendation_06_Order_Sign](PlanDefinition-opioidcds-06.md), [PlanDefinition_Recommendation_07_Order_Sign](PlanDefinition-opioidcds-07.md), [PlanDefinition_Recommendation_08_Order_Sign](PlanDefinition-opioidcds-08.md), [PlanDefinition_Recommendation_09_Order_Sign](PlanDefinition-opioidcds-09.md), [PlanDefinition_Recommendation_10_Order_Sign](PlanDefinition-opioidcds-10-order-sign.md), [PlanDefinition_Recommendation_10_Patient_View](PlanDefinition-opioidcds-10-patient-view.md), [PlanDefinition_Recommendation_11_Order_Select](PlanDefinition-opioidcds-11-order-select.md), [PlanDefinition_Recommendation_11_Patient_View](PlanDefinition-opioidcds-11-patient-view.md) and [PlanDefinition_Recommendation_12_Patient_View](PlanDefinition-opioidcds-12-patient-view.md)
* [Software System Type Codes](http://terminology.hl7.org/7.3.0/CodeSystem-software-system-type-codes.html): [Device/cqf-tooling](Device-cqf-tooling.md)
* [UsageContextType](http://terminology.hl7.org/7.3.0/CodeSystem-usage-context-type.html): [ActivityDefinition_Risk_Assessment_ServiceRequest](ActivityDefinition-opioidcds-risk-assessment-request.md), [ActivityDefinition_Urine_Screening_ServiceRequest](ActivityDefinition-opioidcds-urine-screening-request.md)... Show 17 more, [ConversionFactors](Library-ConversionFactors.md), [MMECalculator](Library-MMECalculator.md), [OMTKData](Library-OMTKData.md), [OMTKLogic](Library-OMTKLogic.md), [PlanDefinition_Recommendation_01_Order_Sign](PlanDefinition-opioidcds-01.md), [PlanDefinition_Recommendation_02_Order_Sign](PlanDefinition-opioidcds-02.md), [PlanDefinition_Recommendation_03_Order_Sign](PlanDefinition-opioidcds-03.md), [PlanDefinition_Recommendation_04_05_Order_Sign](PlanDefinition-opioidcds-04-05.md), [PlanDefinition_Recommendation_06_Order_Sign](PlanDefinition-opioidcds-06.md), [PlanDefinition_Recommendation_07_Order_Sign](PlanDefinition-opioidcds-07.md), [PlanDefinition_Recommendation_08_Order_Sign](PlanDefinition-opioidcds-08.md), [PlanDefinition_Recommendation_09_Order_Sign](PlanDefinition-opioidcds-09.md), [PlanDefinition_Recommendation_10_Order_Sign](PlanDefinition-opioidcds-10-order-sign.md), [PlanDefinition_Recommendation_10_Patient_View](PlanDefinition-opioidcds-10-patient-view.md), [PlanDefinition_Recommendation_11_Order_Select](PlanDefinition-opioidcds-11-order-select.md), [PlanDefinition_Recommendation_11_Patient_View](PlanDefinition-opioidcds-11-patient-view.md) and [PlanDefinition_Recommendation_12_Patient_View](PlanDefinition-opioidcds-12-patient-view.md)
* [ActCode](http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActCode.html): [Encounter/cancer-diagnosis](Encounter-cancer-diagnosis.md) and [Encounter/oncologist-participant](Encounter-oncologist-participant.md)
* [ObservationInterpretation](http://terminology.hl7.org/7.3.0/CodeSystem-v3-ObservationInterpretation.html): [Observation/example-opioidcds](Observation-example-opioidcds.md)


* Used by permission of HL7 International, all rights reserved Creative Commons License

* [US Core Condition Category Extension Codes](http://tx.fhir.org/r4/ValueSet/966): [Condition/end-of-life](Condition-end-of-life.md) and [US_CORE_HEALTH_CONCERN_CONDITION_CATEGORY](ValueSet-condition-us-core-health-concern-category.md)


* Using RxNorm codes of type SAB=RXNORM as this specification describes does not require a UMLS license. Access to the full set of RxNorm definitions, and/or additional use of other RxNorm structures and information requires a UMLS license. The use of RxNorm in this specification is pursuant to HL7's status as a licensee of the NLM UMLS. HL7's license does not convey the right to use RxNorm to any users of this specification; implementers must acquire a license to use RxNorm in their own right.

* [RxNorm](http://terminology.hl7.org/5.5.0/CodeSystem-v3-rxNorm.html): [AMPHETAMINES_CLASS_MEDICATIONS](ValueSet-amphetamines-class-medications.md), [BARBITURATE_MEDICATIONS](ValueSet-barbiturate-medications.md)... Show 15 more, [BENZODIAZEPINE_MEDICATIONS](ValueSet-benzodiazepine-medications.md), [BUPRENORPHINE_AND_METHADONE_MEDICATIONS](ValueSet-buprenorphine-and-methadone-medications.md), [BUPRENORPHINE_MEDICATIONS](ValueSet-buprenorphine-medications.md), [CNS_DEPRESSANT_MEDICATIONS](ValueSet-cns-depressant-medications.md), [EXTENDED_RELEASE_OPIOID_WITH_AMBULATORY_MISUSE_POTENTIAL](ValueSet-extended-release-opioid-with-ambulatory-misuse-potential.md), [FENTANYL_TYPE_MEDICATIONS](ValueSet-fentanyl-type-medications.md), [METHADONE_MEDICATIONS](ValueSet-methadone-medications.md), [MedicationDispense/ambulatory-opioid](MedicationDispense-ambulatory-opioid.md), [MedicationRequest/ambulatory-opioid](MedicationRequest-ambulatory-opioid.md), [MedicationRequest/example-opioidcds](MedicationRequest-example-opioidcds.md), [NALOXONE_MEDICATIONS](ValueSet-naloxone-medications.md), [NON_SYNTHETIC_OPIOID_MEDICATIONS](ValueSet-non-synthetic-opioid-medications.md), [OPIOID_ANALGESICS_WITH_AMBULATORY_MISUSE_POTENTIAL](ValueSet-opioid-analgesics-with-ambulatory-misuse-potential.md), [OXYCODONE_MEDICATIONS](ValueSet-oxycodone-medications.md) and [SYNTHETIC_OPIOID_MEDICATIONS](ValueSet-synthetic-opioid-medications.md)


### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (fhir.cdc.opioid-cds.r4)](package.r4.tgz) and [R4B (fhir.cdc.opioid-cds.r4b)](package.r4b.tgz) are available.

### Dependencies










### Globals

*There are no Global profiles defined*

### Expansion Parameters

* Parameter: system-version
  * Value: [SCT US vhttp://snomed.info/sct/731000124108/version/20250901](http://snomed.info/sct/731000124108/version/20250901)
* Parameter: default-canonical-version
  * Value: [Strength of recommendation](http://hl7.org/fhir/extensions/5.3.0/StructureDefinition-cqf-strengthOfRecommendation.html)
* Parameter: default-canonical-version
  * Value: [Quality of evidence](http://hl7.org/fhir/extensions/5.3.0/StructureDefinition-cqf-qualityOfEvidence.html)
* Parameter: default-canonical-version
  * Value: [CPGComputableValueSet](http://hl7.org/fhir/uv/cpg/STU1/StructureDefinition-cpg-computablevalueset.html)
* Parameter: default-canonical-version
  * Value: [CPGExecutableValueSet](http://hl7.org/fhir/uv/cpg/STU1/StructureDefinition-cpg-executablevalueset.html)
* Parameter: system-version
  * Value: [Logical Observation Identifiers, Names and Codes (LOINC) v3.1.0](http://terminology.hl7.org/5.5.0/CodeSystem-v3-loinc.html)
* Parameter: system-version
  * Value: [International Classification of Diseases, 10th Revision, Clinical Modification (ICD-10-CM) v2.0.1](http://terminology.hl7.org/5.5.0/CodeSystem-icd10CM.html)
* Parameter: system-version
  * Value: [Medicationrequest status v4.0.1](http://hl7.org/fhir/R4/codesystem-medicationrequest-status.html)
* Parameter: default-canonical-version
  * Value: [CPGShareableLibrary](http://hl7.org/fhir/uv/cpg/STU1/StructureDefinition-cpg-shareablelibrary.html)
* Parameter: default-canonical-version
  * Value: [CPGComputableLibrary](http://hl7.org/fhir/uv/cpg/STU1/StructureDefinition-cpg-computablelibrary.html)
* Parameter: default-canonical-version
  * Value: [CPGPublishableLibrary](http://hl7.org/fhir/uv/cpg/STU1/StructureDefinition-cpg-publishablelibrary.html)
* Parameter: default-canonical-version
  * Value: [CPGExecutableLibrary](http://hl7.org/fhir/uv/cpg/STU1/StructureDefinition-cpg-executablelibrary.html)
* Parameter: system-version
  * Value: [UsageContextType v2.0.1](http://terminology.hl7.org/7.3.0/CodeSystem-usage-context-type.html)
* Parameter: system-version
  * Value: [CDC MME Usage Context Codes v3.0.0](http://fhir.org/guides/cdc/opioid-mme-r4/3.0.0/CodeSystem-CDCMMEUsageContextCodes.html)
* Parameter: default-canonical-version
  * Value: [Patient](http://hl7.org/fhir/R4/patient.html)
* Parameter: system-version
  * Value: [RxNorm v3.0.1](http://terminology.hl7.org/5.5.0/CodeSystem-v3-rxNorm.html)
* Parameter: default-valueset-version
  * Value: [Limited life expectancy conditions v2022.1.1](ValueSet-limited-life-expectancy-conditions.md)
* Parameter: default-valueset-version
  * Value: [Therapies indicating end of life care v2022.1.1](ValueSet-therapies-indicating-end-of-life-care.md)
* Parameter: default-valueset-version
  * Value: [Conditions likely terminal for opioid prescribing v2022.1.1](ValueSet-conditions-likely-terminal-for-opioid-prescribing.md)
* Parameter: default-valueset-version
  * Value: [CDC malignant cancer conditions v2022.1.1](ValueSet-cdc-malignant-cancer-conditions.md)
* Parameter: default-valueset-version
  * Value: [Oncology specialty designations (NUCC) v2022.1.1](ValueSet-oncology-specialty-designations.md)
* Parameter: default-valueset-version
  * Value: [Opioid misuse disorders v2022.1.1](ValueSet-opioid-misuse-disorders.md)
* Parameter: default-valueset-version
  * Value: [Substance misuse behavioral counseling v2022.1.1](ValueSet-substance-misuse-behavioral-counseling.md)
* Parameter: default-valueset-version
  * Value: [Conditions documenting substance misuse v2022.1.1](ValueSet-conditions-documenting-substance-misuse.md)
* Parameter: default-valueset-version
  * Value: [Office Visit v0.2.0](ValueSet-office-visit.md)
* Parameter: default-valueset-version
  * Value: [Opioid counseling procedure v2022.1.1](ValueSet-opioid-counseling-procedure.md)
* Parameter: default-valueset-version
  * Value: [Opioid misuse assessment procedure v2022.1.1](ValueSet-opioid-misuse-assessment-procedure.md)
* Parameter: default-valueset-version
  * Value: [Hospice Disposition v2022.1.1](ValueSet-hospice-disposition.md)
* Parameter: default-valueset-version
  * Value: [Hospice Finding v2022.1.1](ValueSet-hospice-finding.md)
* Parameter: default-valueset-version
  * Value: [Observation Category Laboratory v2022.1.1](ValueSet-observation-category-laboratory.md)
* Parameter: default-valueset-version
  * Value: [Observation Category Procedure v2022.1.1](ValueSet-observation-category-procedure.md)
* Parameter: default-valueset-version
  * Value: [Pain treatment plan v2022.1.1](ValueSet-pain-treatment-plan.md)
* Parameter: default-valueset-version
  * Value: [Pain management procedure v2022.1.1](ValueSet-pain-management-procedure.md)
* Parameter: default-valueset-version
  * Value: [PDMP review procedure v2022.1.1](ValueSet-pdmp-review-procedure.md)
* Parameter: default-valueset-version
  * Value: [PDMP data reviewed finding v2022.1.1](ValueSet-pdmp-data-reviewed-finding.md)
* Parameter: default-valueset-version
  * Value: [Sleep disordered breathing v2022.1.1](ValueSet-conditions-documenting-sleep-disordered-breathing.md)
* Parameter: default-valueset-version
  * Value: [Opioid analgesics with ambulatory misuse potential v2022.1.1](ValueSet-opioid-analgesics-with-ambulatory-misuse-potential.md)
* Parameter: default-valueset-version
  * Value: [Extended release opioid with ambulatory misuse potential v2022.1.1](ValueSet-extended-release-opioid-with-ambulatory-misuse-potential.md)
* Parameter: default-valueset-version
  * Value: [Buprenorphine Medications v2022.1.1](ValueSet-buprenorphine-medications.md)
* Parameter: default-valueset-version
  * Value: [Buprenorphine and Methadone medications v2022.1.1](ValueSet-buprenorphine-and-methadone-medications.md)
* Parameter: default-valueset-version
  * Value: [Non-synthetic opioid medications v2022.1.1](ValueSet-non-synthetic-opioid-medications.md)
* Parameter: default-valueset-version
  * Value: [Barbiturate Medications v2022.1.1](ValueSet-barbiturate-medications.md)
* Parameter: default-valueset-version
  * Value: [Benzodiazepine medications v2022.1.1](ValueSet-benzodiazepine-medications.md)
* Parameter: default-valueset-version
  * Value: [Naloxone medications v2022.1.1](ValueSet-naloxone-medications.md)
* Parameter: default-valueset-version
  * Value: [Fentanyl-type medications v2022.1.1](ValueSet-fentanyl-type-medications.md)
* Parameter: default-valueset-version
  * Value: [Amphetamine class medications v2022.1.1](ValueSet-amphetamines-class-medications.md)
* Parameter: default-valueset-version
  * Value: [Methadone medications v2022.1.1](ValueSet-methadone-medications.md)
* Parameter: default-valueset-version
  * Value: [Oxycodone Medications v2022.1.1](ValueSet-oxycodone-medications.md)
* Parameter: default-valueset-version
  * Value: [Synthetic opioid medications v2022.1.1](ValueSet-synthetic-opioid-medications.md)
* Parameter: default-valueset-version
  * Value: [CNS depressant medications v2022.1.1](ValueSet-cns-depressant-medications.md)
* Parameter: default-valueset-version
  * Value: [All urine drug screening tests v2022.1.1](ValueSet-all-urine-drug-screening-tests.md)
* Parameter: default-valueset-version
  * Value: [Non-opioid drug urine screening v2022.1.1](ValueSet-non-opioid-urine-drug-screening.md)
* Parameter: default-valueset-version
  * Value: [Opiate specific urine drug screening tests v2022.1.1](ValueSet-opiate-specific-urine-drug-screening-tests.md)
* Parameter: default-valueset-version
  * Value: [General opiate urine drug screening tests v2022.1.1](ValueSet-general-opiate-urine-drug-screening-tests.md)
* Parameter: default-valueset-version
  * Value: [Opioid drug urine screening v2022.1.1](ValueSet-opioid-urine-drug-screening.md)
* Parameter: default-valueset-version
  * Value: [Cocaine urine drug screening tests v2022.1.1](ValueSet-cocaine-urine-drug-screening-tests.md)
* Parameter: default-valueset-version
  * Value: [Phencyclidine urine drug screening tests v2022.1.1](ValueSet-phencyclidine-urine-drug-screening-tests.md)
* Parameter: default-valueset-version
  * Value: [Fentanyl-type urine drug screening tests v2022.1.1](ValueSet-fentanyl-type-urine-drug-screening-tests.md)
* Parameter: default-valueset-version
  * Value: [Amphetamine-class drugs and metabolite urine tests v2022.1.1](ValueSet-amphetamine-urine-drug-screening-tests.md)
* Parameter: default-valueset-version
  * Value: [Cannabinoid class urine drug screening v2022.1.1](ValueSet-cannabinoid-urine-drug-screening-tests.md)
* Parameter: default-valueset-version
  * Value: [Methadone urine drug screening tests v2022.1.1](ValueSet-methadone-urine-drug-screening-tests.md)
* Parameter: default-valueset-version
  * Value: [Synthetic opioid urine drug screening tests v2022.1.1](ValueSet-synthetic-opioid-urine-drug-screening-tests.md)
* Parameter: default-valueset-version
  * Value: [Barbiturate urine drug screening tests v2022.1.1](ValueSet-barbiturate-urine-drug-screening-tests.md)
* Parameter: default-valueset-version
  * Value: [Benzodiazepine urine drug screening tests v2022.1.1](ValueSet-benzodiazepine-urine-drug-screening-tests.md)
* Parameter: default-valueset-version
  * Value: [Buprenorphine urine drug screening tests v2022.1.1](ValueSet-buprenorphine-urine-drug-screening-tests.md)
* Parameter: default-valueset-version
  * Value: [Heroin urine drug screening tests v2022.1.1](ValueSet-heroin-urine-drug-screening-tests.md)
* Parameter: default-valueset-version
  * Value: [Oxycodone urine drug screening tests v2022.1.1](ValueSet-oxycodone-urine-drug-screening-tests.md)
* Parameter: default-valueset-version
  * Value: [ValueSet - Medication Request Category Community v0.0.1](ValueSet-medicationrequest-category-community.md)
* Parameter: default-valueset-version
  * Value: [Condition Clinical Status Active v2022.1.1](ValueSet-condition-clinical-status-active.md)
* Parameter: default-valueset-version
  * Value: [ValueSet - Medication Request Status Active v0.0.1](ValueSet-medicationrequest-status-active.md)
* Parameter: default-valueset-version
  * Value: [Encounter Diagnosis Condition Category v2022.1.1](ValueSet-condition-encounter-diagnosis-category.md)
* Parameter: default-valueset-version
  * Value: [Problem List Condition Category v2022.1.1](ValueSet-condition-problem-list-category.md)
* Parameter: default-valueset-version
  * Value: [US Core Health Concern Condition Category v2022.1.1](ValueSet-condition-us-core-health-concern-category.md)
* Parameter: default-valueset-version
  * Value: [Sickle-cell diseases v2022.1.1](ValueSet-sickle-cell-diseases.md)
* Parameter: default-canonical-version
  * Value: [MedicationRequest](http://hl7.org/fhir/R4/medicationrequest.html)
* Parameter: default-canonical-version
  * Value: [Medication](http://hl7.org/fhir/R4/medication.html)
* Parameter: default-canonical-version
  * Value: [Condition](http://hl7.org/fhir/R4/condition.html)
* Parameter: default-canonical-version
  * Value: [Observation](http://hl7.org/fhir/R4/observation.html)
* Parameter: default-canonical-version
  * Value: [Encounter](http://hl7.org/fhir/R4/encounter.html)
* Parameter: default-canonical-version
  * Value: [CarePlan](http://hl7.org/fhir/R4/careplan.html)
* Parameter: default-canonical-version
  * Value: [Procedure](http://hl7.org/fhir/R4/procedure.html)
* Parameter: default-canonical-version
  * Value: [MedicationDispense](http://hl7.org/fhir/R4/medicationdispense.html)
* Parameter: default-canonical-version
  * Value: [CPGRecommendationDefinition](http://hl7.org/fhir/uv/cpg/STU1/StructureDefinition-cpg-recommendationdefinition.html)
* Parameter: default-canonical-version
  * Value: [CPGPublishablePlanDefinition](http://hl7.org/fhir/uv/cpg/STU1/StructureDefinition-cpg-publishableplandefinition.html)
* Parameter: default-canonical-version
  * Value: [Library - Recommendation #1 - Nonpharmacologic and Nonopioid Pharmacologic Therapy Consideration](Library-OpioidCDSREC01.md)
* Parameter: default-canonical-version
  * Value: [Library - Recommendation #2 - Opioid Therapy Goals Discussion](Library-OpioidCDSREC02.md)
* Parameter: default-canonical-version
  * Value: [Library - Recommendation #3 - Opioid Immediate Release Form When Starting Opioid Therapy](Library-OpioidCDSREC03.md)
* Parameter: default-canonical-version
  * Value: [Library - Recommendations #4 and #5 - Lowest Effective Dose](Library-OpioidCDSREC04And05.md)
* Parameter: default-canonical-version
  * Value: [Library - Recommendation #6 - Prescribe Lowest Effective Dose and Duration](Library-OpioidCDSREC06.md)
* Parameter: default-canonical-version
  * Value: [Library - Recommendation #7 - Opioid Therapy Risk Assessment](Library-OpioidCDSREC07.md)
* Parameter: default-canonical-version
  * Value: [ActivityDefinition - Risk Assessment ServiceRequest](ActivityDefinition-opioidcds-risk-assessment-request.md)
* Parameter: default-canonical-version
  * Value: [Library - Recommendation #8 - Naloxone Consideration](Library-OpioidCDSREC08.md)
* Parameter: default-canonical-version
  * Value: [Library - Recommendation #9 - Consider Patient's History of Controlled Substance Prescriptions](Library-OpioidCDSREC09.md)
* Parameter: default-canonical-version
  * Value: [Library - Recommendation #10 - Urine Drug Testing](Library-OpioidCDSREC10OrderSign.md)
* Parameter: default-canonical-version
  * Value: [Library - Recommendation #10 Patient View - Urine Drug Testing](Library-OpioidCDSREC10PatientView.md)
* Parameter: default-canonical-version
  * Value: [ActivityDefinition - Urine Screening ServiceRequest](ActivityDefinition-opioidcds-urine-screening-request.md)
* Parameter: default-canonical-version
  * Value: [Library - Recommendation #11 - Concurrent Use of Opioids and Benzodiazepines](Library-OpioidCDSREC11OrderSelect.md)
* Parameter: default-canonical-version
  * Value: [Library - Recommendation #11 Patient View - Concurrent Use of Opioids and Benzodiazepines](Library-OpioidCDSREC11PatientView.md)
* Parameter: default-canonical-version
  * Value: [Library - Recommendation #12 (patient-view) - Evidence-based Treatment for Patients with Opioid Use Disorder](Library-OpioidCDSREC12PatientView.md)

