# Opioid analgesics with ambulatory misuse potential - 2022 CDC Clinical Practice Guideline for Prescribing Opioids Implementation Guide v2022.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Opioid analgesics with ambulatory misuse potential**

## ValueSet: Opioid analgesics with ambulatory misuse potential 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.org/guides/cdc/opioid-cds/ValueSet/opioid-analgesics-with-ambulatory-misuse-potential | *Version*:2022.1.1 |
| Active as of 2025-02-24 | *Computable Name*:OPIOID_ANALGESICS_WITH_AMBULATORY_MISUSE_POTENTIAL |
| *Other Identifiers:*OID:2.16.840.1.114222.48.28 | |
| **Copyright/Legal**: © CDC 2016+. | |

 
All opioid clinical drugs except cough medications, antispasmodics, or those restricted to surgical use only as identified by those using an injectable form. 

 
Opioid medications that should have opioid management CDS 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

This ValueSet does not have a formal definition; instead, the value set must be prepared by hand using these instructions.

https://mor.nlm.nih.gov/RxMix/ Script: Step 1a Create Batch text input file (SCT-Opioids.txt) with following SCT identifier (for the concept "Product containing opioid receptor agonist (product)") as an input within the file: 360204007

Step 1b Submit batch job using the above SCT-Opioids.txt file to following workflow by uploading file (SCT-Opioid-wf.config) with the following in the file: <WFE><filteredOutputs>RXCUI|name|term_type</filteredOutputs><input>NOINPUT</input><FS><service>NOINPUT</service><function>findClassById</function><level>0</level><paramSize>1</paramSize><param order ='0'>?</param></FS><FS><service>NOINPUT</service><function>getClassMembers</function><level>1</level><paramSize>5</paramSize><param order ='0'>?</param><param order ='1'>SNOMEDCT</param><param order ='2'>isa_disposition</param><param order ='3'>0</param><param order ='4'>IN,MIN,PIN</param></FS><FS><service>NOINPUT</service><function>getRelatedByType</function><level>2</level><paramSize>2</paramSize><param order ='0'>?</param><param order ='1'>BPCK,GPCK,SBD,SCD</param></FS></WFE> This will produce a result file with all Opioid clinical drugs included

Step 2 To remove all cough and bowel transit formulation codes and to remove the injectable codes filter out all codes with the following strings: Ingredient strings: Guaifenesin, Chlorpheniramine, Pseudoephedrine, Brompheniramine, Phenylephrine, Phenylpropanolamine, Promethazine, Bromodiphenhydramine, guaiacolsulfonate, homatropine Form strings: inject, cartridge, syringe

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "opioid-analgesics-with-ambulatory-misuse-potential",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-computablevalueset",
    "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-executablevalueset"]
  },
  "extension" : [{
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-clinical-focus",
    "valueString" : "All opioid clinical drugs except cough medications, antispasmodics, or those restricted to surgical use only."
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-dataelement-scope",
    "valueString" : "Medication"
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-inclusion-criteria",
    "valueString" : "All opioid-class medications"
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-exclusion-criteria",
    "valueString" : "All medications including ingredients intended to treat cough or act as an antispasmodic. All injectable forms."
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-author",
    "valueContactDetail" : {
      "name" : "MD Partners, Inc.",
      "telecom" : [{
        "system" : "email",
        "value" : "info@mdpartners.com"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "computable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "executable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-usageWarning",
    "valueString" : "This value set contains a point-in-time expansion enumerating the codes that meet the value set intent. As new versions of the code systems used by the value set are released, the contents of this expansion will need to be updated to incorporate newly defined codes that meet the value set intent. Before, and periodically during production use, the value set expansion contents SHOULD be updated. The value set expansion specifies the timestamp when the expansion was produced, SHOULD contain the parameters used for the expansion, and SHALL contain the codes that are obtained by evaluating the value set definition. If this is ONLY an executable value set, a distributable definition of the value set must be obtained to compute the updated expansion."
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-rules-text",
    "valueMarkdown" : "https://mor.nlm.nih.gov/RxMix/ Script:\r\nStep 1a \r\nCreate Batch text input file (SCT-Opioids.txt) with following SCT identifier (for the concept \"Product containing opioid receptor agonist (product)\") as an input within the file: \r\n360204007       \r\n\r\nStep 1b\r\nSubmit batch job using the above SCT-Opioids.txt file to following workflow by uploading file (SCT-Opioid-wf.config) with the following in the file:  <WFE><filteredOutputs>RXCUI|name|term_type</filteredOutputs><input>NOINPUT</input><FS><service>NOINPUT</service><function>findClassById</function><level>0</level><paramSize>1</paramSize><param order ='0'>?</param></FS><FS><service>NOINPUT</service><function>getClassMembers</function><level>1</level><paramSize>5</paramSize><param order ='0'>?</param><param order ='1'>SNOMEDCT</param><param order ='2'>isa_disposition</param><param order ='3'>0</param><param order ='4'>IN,MIN,PIN</param></FS><FS><service>NOINPUT</service><function>getRelatedByType</function><level>2</level><paramSize>2</paramSize><param order ='0'>?</param><param order ='1'>BPCK,GPCK,SBD,SCD</param></FS></WFE>\r\nThis will produce a result file with all Opioid clinical drugs included\r\n\r\nStep 2\r\nTo remove all cough and bowel transit formulation codes and to remove the injectable codes filter out all codes with the following strings:\r\nIngredient strings: \r\nGuaifenesin, Chlorpheniramine, Pseudoephedrine, Brompheniramine, Phenylephrine, Phenylpropanolamine, Promethazine, Bromodiphenhydramine, guaiacolsulfonate, homatropine\r\nForm strings:\r\ninject, cartridge, syringe"
  }],
  "url" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/opioid-analgesics-with-ambulatory-misuse-potential",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.16.840.1.114222.48.28"
  }],
  "version" : "2022.1.1",
  "name" : "OPIOID_ANALGESICS_WITH_AMBULATORY_MISUSE_POTENTIAL",
  "title" : "Opioid analgesics with ambulatory misuse potential",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-02-24T13:06:46-07:00",
  "publisher" : "CDC / Security Risk Solutions, Inc. (SRS)",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.securityrisksolutions.com"
    }]
  }],
  "description" : "All opioid clinical drugs except cough medications, antispasmodics, or those restricted to surgical use only as identified by those using an injectable form.",
  "purpose" : "Opioid medications that should have opioid management CDS",
  "copyright" : "© CDC 2016+.",
  "expansion" : {
    "identifier" : "urn:uuid:2d7e6507-7ffe-4c34-8f8f-9289813e4600",
    "timestamp" : "2025-02-24T13:06:46-07:00",
    "total" : 557,
    "parameter" : [{
      "name" : "used-codesystem",
      "valueUri" : "http://www.nlm.nih.gov/research/umls/rxnorm|03022026"
    },
    {
      "name" : "version",
      "valueUri" : "http://www.nlm.nih.gov/research/umls/rxnorm|03022026"
    }],
    "contains" : [{
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1148482",
      "display" : "24 HR tramadol hydrochloride 100 MG Extended Release Oral Capsule [ConZip]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1148487",
      "display" : "24 HR tramadol hydrochloride 200 MG Extended Release Oral Capsule [ConZip]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1148491",
      "display" : "24 HR tramadol hydrochloride 300 MG Extended Release Oral Capsule [ConZip]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2395814",
      "display" : "tramadol hydrochloride 5 MG/ML Oral Solution [Qdolo]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2588484",
      "display" : "celecoxib 56 MG / tramadol hydrochloride 44 MG Oral Tablet [Seglentis]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "835605",
      "display" : "tramadol hydrochloride 50 MG Oral Tablet [Ultram]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "836397",
      "display" : "acetaminophen 325 MG / tramadol hydrochloride 37.5 MG Oral Tablet [Ultracet]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "845315",
      "display" : "24 HR tramadol hydrochloride 200 MG Extended Release Oral Tablet [Ultram]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "845316",
      "display" : "24 HR tramadol hydrochloride 300 MG Extended Release Oral Tablet [Ultram]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1148478",
      "display" : "24 HR tramadol hydrochloride 100 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1148485",
      "display" : "24 HR tramadol hydrochloride 200 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1148489",
      "display" : "24 HR tramadol hydrochloride 300 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1248115",
      "display" : "24 HR tramadol hydrochloride 150 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1946525",
      "display" : "Matrix Delivery 24 HR tramadol hydrochloride 300 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1946527",
      "display" : "Matrix Delivery 24 HR tramadol hydrochloride 200 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1946529",
      "display" : "Matrix Delivery 24 HR tramadol hydrochloride 100 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2179635",
      "display" : "tramadol hydrochloride 100 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2395808",
      "display" : "tramadol hydrochloride 5 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2588478",
      "display" : "celecoxib 56 MG / tramadol hydrochloride 44 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2670390",
      "display" : "tramadol hydrochloride 25 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2692878",
      "display" : "tramadol hydrochloride 75 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "833709",
      "display" : "24 HR tramadol hydrochloride 100 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "833711",
      "display" : "24 HR tramadol hydrochloride 200 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "833713",
      "display" : "24 HR tramadol hydrochloride 300 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "835603",
      "display" : "tramadol hydrochloride 50 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "836395",
      "display" : "acetaminophen 325 MG / tramadol hydrochloride 37.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "836408",
      "display" : "tramadol hydrochloride 50 MG Disintegrating Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "836466",
      "display" : "tramadol hydrochloride 50 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "836485",
      "display" : "tramadol hydrochloride 1 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "849331",
      "display" : "tramadol hydrochloride 75 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "849561",
      "display" : "12 HR tramadol hydrochloride 150 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "849903",
      "display" : "tramadol hydrochloride 50 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1010603",
      "display" : "buprenorphine 2 MG / naloxone 0.5 MG Sublingual Film [Suboxone]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1010606",
      "display" : "buprenorphine 8 MG / naloxone 2 MG Sublingual Film [Suboxone]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1307058",
      "display" : "buprenorphine 4 MG / naloxone 1 MG Sublingual Film [Suboxone]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1307063",
      "display" : "buprenorphine 12 MG / naloxone 3 MG Sublingual Film [Suboxone]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1431083",
      "display" : "buprenorphine 1.4 MG / naloxone 0.36 MG Sublingual Tablet [Zubsolv]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1431104",
      "display" : "buprenorphine 5.7 MG / naloxone 1.4 MG Sublingual Tablet [Zubsolv]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1432971",
      "display" : "168 HR buprenorphine 0.015 MG/HR Transdermal System [BuTrans]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1542396",
      "display" : "buprenorphine 2.1 MG / naloxone 0.3 MG Buccal Film [Bunavail]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1542999",
      "display" : "168 HR buprenorphine 0.0075 MG/HR Transdermal System [BuTrans]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1544853",
      "display" : "buprenorphine 4.2 MG / naloxone 0.7 MG Buccal Film [Bunavail]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1544856",
      "display" : "buprenorphine 6.3 MG / naloxone 1 MG Buccal Film [Bunavail]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1597570",
      "display" : "buprenorphine 11.4 MG / naloxone 2.9 MG Sublingual Tablet [Zubsolv]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1597575",
      "display" : "buprenorphine 8.6 MG / naloxone 2.1 MG Sublingual Tablet [Zubsolv]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1666385",
      "display" : "buprenorphine 2.9 MG / naloxone 0.71 MG Sublingual Tablet [Zubsolv]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716063",
      "display" : "buprenorphine 0.15 MG Buccal Film [Belbuca]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716067",
      "display" : "buprenorphine 0.3 MG Buccal Film [Belbuca]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716071",
      "display" : "buprenorphine 0.45 MG Buccal Film [Belbuca]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716075",
      "display" : "buprenorphine 0.6 MG Buccal Film [Belbuca]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716079",
      "display" : "buprenorphine 0.075 MG Buccal Film [Belbuca]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716083",
      "display" : "buprenorphine 0.75 MG Buccal Film [Belbuca]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716090",
      "display" : "buprenorphine 0.9 MG Buccal Film [Belbuca]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1797655",
      "display" : "buprenorphine 74.2 MG Drug Implant [Probuphine]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1864414",
      "display" : "buprenorphine 0.7 MG / naloxone 0.18 MG Sublingual Tablet [Zubsolv]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2599851",
      "display" : "buprenorphine 20 MG/ML Topical Solution [Zorbium]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "904874",
      "display" : "168 HR buprenorphine 0.01 MG/HR Transdermal System [BuTrans]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "904878",
      "display" : "168 HR buprenorphine 0.02 MG/HR Transdermal System [BuTrans]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "904882",
      "display" : "168 HR buprenorphine 0.005 MG/HR Transdermal System [BuTrans]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1010600",
      "display" : "buprenorphine 2 MG / naloxone 0.5 MG Sublingual Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1010604",
      "display" : "buprenorphine 8 MG / naloxone 2 MG Sublingual Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1307056",
      "display" : "buprenorphine 4 MG / naloxone 1 MG Sublingual Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1307061",
      "display" : "buprenorphine 12 MG / naloxone 3 MG Sublingual Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1431076",
      "display" : "buprenorphine 1.4 MG / naloxone 0.36 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1431102",
      "display" : "buprenorphine 5.7 MG / naloxone 1.4 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1432969",
      "display" : "168 HR buprenorphine 0.015 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1542390",
      "display" : "buprenorphine 2.1 MG / naloxone 0.3 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1542997",
      "display" : "168 HR buprenorphine 0.0075 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1544851",
      "display" : "buprenorphine 4.2 MG / naloxone 0.7 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1544854",
      "display" : "buprenorphine 6.3 MG / naloxone 1 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1597568",
      "display" : "buprenorphine 11.4 MG / naloxone 2.9 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1597573",
      "display" : "buprenorphine 8.6 MG / naloxone 2.1 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1666338",
      "display" : "buprenorphine 2.9 MG / naloxone 0.71 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716057",
      "display" : "buprenorphine 0.15 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716065",
      "display" : "buprenorphine 0.3 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716069",
      "display" : "buprenorphine 0.45 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716073",
      "display" : "buprenorphine 0.6 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716077",
      "display" : "buprenorphine 0.075 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716081",
      "display" : "buprenorphine 0.75 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1716086",
      "display" : "buprenorphine 0.9 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1797650",
      "display" : "buprenorphine 74.2 MG Drug Implant"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1864412",
      "display" : "buprenorphine 0.7 MG / naloxone 0.18 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "246474",
      "display" : "buprenorphine 0.2 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "250426",
      "display" : "buprenorphine 0.4 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2599846",
      "display" : "buprenorphine 20 MG/ML Topical Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "351264",
      "display" : "buprenorphine 2 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "351265",
      "display" : "buprenorphine 8 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "351266",
      "display" : "buprenorphine 2 MG / naloxone 0.5 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "351267",
      "display" : "buprenorphine 8 MG / naloxone 2 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "904870",
      "display" : "168 HR buprenorphine 0.01 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "904876",
      "display" : "168 HR buprenorphine 0.02 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "904880",
      "display" : "168 HR buprenorphine 0.005 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "886634",
      "display" : "butorphanol tartrate 1 MG/ACTUAT Metered Dose Nasal Spray"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2001364",
      "display" : "acetaminophen 325 MG / benzhydrocodone 6.12 MG Oral Tablet [Apadaz]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2118730",
      "display" : "acetaminophen 325 MG / benzhydrocodone 4.08 MG Oral Tablet [Apadaz]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2118734",
      "display" : "acetaminophen 325 MG / benzhydrocodone 8.16 MG Oral Tablet [Apadaz]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2001358",
      "display" : "acetaminophen 325 MG / benzhydrocodone 6.12 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2118728",
      "display" : "acetaminophen 325 MG / benzhydrocodone 4.08 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2118732",
      "display" : "acetaminophen 325 MG / benzhydrocodone 8.16 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1190201",
      "display" : "acetaminophen 320.5 MG / caffeine 30 MG / dihydrocodeine bitartrate 16 MG Oral Capsule [Trezix]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2105929",
      "display" : "acetaminophen 325 MG / caffeine 30 MG / dihydrocodeine bitartrate 16 MG Oral Tablet [Dvorah]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1234871",
      "display" : "acetaminophen 356.4 MG / caffeine 30 MG / dihydrocodeine bitartrate 16 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1234872",
      "display" : "aspirin 356.4 MG / caffeine 30 MG / dihydrocodeine bitartrate 16 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1234978",
      "display" : "acetaminophen 712.8 MG / caffeine 60 MG / dihydrocodeine bitartrate 32 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1234999",
      "display" : "acetaminophen 500 MG / dihydrocodeine bitartrate 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1235009",
      "display" : "acetaminophen 500 MG / dihydrocodeine bitartrate 20 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1235011",
      "display" : "acetaminophen 500 MG / dihydrocodeine bitartrate 30 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1236179",
      "display" : "dihydrocodeine bitartrate 120 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1236182",
      "display" : "dihydrocodeine bitartrate 30 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1236184",
      "display" : "dihydrocodeine bitartrate 40 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1236188",
      "display" : "dihydrocodeine bitartrate 60 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1236190",
      "display" : "dihydrocodeine bitartrate 90 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1236214",
      "display" : "dihydrocodeine bitartrate 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1236218",
      "display" : "dihydrocodeine bitartrate 2.42 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1596108",
      "display" : "acetaminophen 320.5 MG / caffeine 30 MG / dihydrocodeine bitartrate 16 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1812164",
      "display" : "acetaminophen 325 MG / caffeine 30 MG / dihydrocodeine bitartrate 16 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "104972",
      "display" : "cyclizine 30 MG / dipipanone 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "311297",
      "display" : "levomethadyl 10 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1433802",
      "display" : "acetaminophen 300 MG / butalbital 50 MG / caffeine 40 MG / codeine phosphate 30 MG Oral Capsule [Fioricet with Codeine]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "993837",
      "display" : "acetaminophen 300 MG / codeine phosphate 30 MG Oral Tablet [Tylenol with Codeine]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "993892",
      "display" : "acetaminophen 300 MG / codeine phosphate 60 MG Oral Tablet [Tylenol with Codeine]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "994239",
      "display" : "aspirin 325 MG / butalbital 50 MG / caffeine 40 MG / codeine phosphate 30 MG Oral Capsule [Ascomp]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1431286",
      "display" : "acetaminophen 300 MG / butalbital 50 MG / caffeine 40 MG / codeine phosphate 30 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1536457",
      "display" : "acetaminophen 500 MG / codeine phosphate 8 MG Effervescent Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1536459",
      "display" : "acetaminophen 500 MG / codeine phosphate 30 MG Effervescent Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "993755",
      "display" : "acetaminophen 24 MG/ML / codeine phosphate 2.4 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "993770",
      "display" : "acetaminophen 300 MG / codeine phosphate 15 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "993781",
      "display" : "acetaminophen 300 MG / codeine phosphate 30 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "993890",
      "display" : "acetaminophen 300 MG / codeine phosphate 60 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "993943",
      "display" : "acetaminophen 325 MG / butalbital 50 MG / caffeine 40 MG / codeine phosphate 30 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "994043",
      "display" : "acetaminophen 500 MG / codeine phosphate 15 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "994046",
      "display" : "acetaminophen 500 MG / codeine phosphate 30 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "994226",
      "display" : "aspirin 325 MG / carisoprodol 200 MG / codeine phosphate 16 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "994237",
      "display" : "aspirin 325 MG / butalbital 50 MG / caffeine 40 MG / codeine phosphate 30 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "996734",
      "display" : "codeine phosphate 5 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "996976",
      "display" : "acetaminophen 500 MG / codeine phosphate 12.8 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "996978",
      "display" : "acetaminophen 500 MG / codeine phosphate 13.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "996979",
      "display" : "acetaminophen 500 MG / codeine phosphate 30 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "996981",
      "display" : "acetaminophen 500 MG / codeine phosphate 8 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "996982",
      "display" : "acetaminophen 500 MG / codeine phosphate 8 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "996988",
      "display" : "aspirin 300 MG / codeine phosphate 8 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "996991",
      "display" : "aspirin 325 MG / codeine phosphate 30 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "996994",
      "display" : "aspirin 325 MG / codeine phosphate 60 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "997019",
      "display" : "codeine phosphate 1 MG/ML / kaolin 300 MG/ML Oral Suspension"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "997164",
      "display" : "codeine phosphate 12.5 MG / ibuprofen 200 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "997165",
      "display" : "codeine phosphate 12.8 MG / ibuprofen 200 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "997169",
      "display" : "codeine phosphate 15 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "997170",
      "display" : "codeine sulfate 15 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "997280",
      "display" : "codeine phosphate 20 MG / ibuprofen 300 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "997284",
      "display" : "codeine phosphate 3 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "997285",
      "display" : "codeine phosphate 30 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "997287",
      "display" : "codeine sulfate 30 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "997296",
      "display" : "codeine sulfate 60 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "997301",
      "display" : "codeine phosphate 60 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "250879",
      "display" : "dextromoramide 5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "250880",
      "display" : "dextromoramide 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "250473",
      "display" : "heroin 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "250646",
      "display" : "pholcodine 2 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "250647",
      "display" : "pholcodine 1 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "897658",
      "display" : "hydromorphone hydrochloride 1 MG/ML Oral Solution [Dilaudid]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "897698",
      "display" : "hydromorphone hydrochloride 2 MG Oral Tablet [Dilaudid]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "897704",
      "display" : "hydromorphone hydrochloride 4 MG Oral Tablet [Dilaudid]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "897712",
      "display" : "hydromorphone hydrochloride 8 MG Oral Tablet [Dilaudid]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1306898",
      "display" : "24 HR hydromorphone hydrochloride 32 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "897657",
      "display" : "hydromorphone hydrochloride 1 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "897696",
      "display" : "hydromorphone hydrochloride 2 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "897702",
      "display" : "hydromorphone hydrochloride 4 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "897710",
      "display" : "hydromorphone hydrochloride 8 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "897749",
      "display" : "hydromorphone hydrochloride 3 MG Rectal Suppository"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "897771",
      "display" : "hydromorphone hydrochloride 1 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "898004",
      "display" : "hydromorphone hydrochloride 1.3 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "898138",
      "display" : "hydromorphone hydrochloride 2.6 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "898139",
      "display" : "hydromorphone hydrochloride 3 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "898611",
      "display" : "12 HR hydromorphone hydrochloride 2 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "898614",
      "display" : "12 HR hydromorphone hydrochloride 4 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "898618",
      "display" : "12 HR hydromorphone hydrochloride 8 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "902729",
      "display" : "24 HR hydromorphone hydrochloride 12 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "902736",
      "display" : "24 HR hydromorphone hydrochloride 16 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "902741",
      "display" : "24 HR hydromorphone hydrochloride 8 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1740008",
      "display" : "{2 (fentanyl 0.6 MG/ACTUAT Mucosal Spray [Subsys]) } Pack [Subsys 1200 MCG]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1740010",
      "display" : "{2 (fentanyl 0.8 MG/ACTUAT Mucosal Spray [Subsys]) } Pack [Subsys 1600 MCG]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1740007",
      "display" : "{2 (fentanyl 0.6 MG/ACTUAT Mucosal Spray) } Pack"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1740009",
      "display" : "{2 (fentanyl 0.8 MG/ACTUAT Mucosal Spray) } Pack"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1053651",
      "display" : "fentanyl 0.1 MG Sublingual Tablet [Abstral]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1053654",
      "display" : "fentanyl 0.2 MG Sublingual Tablet [Abstral]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1053657",
      "display" : "fentanyl 0.3 MG Sublingual Tablet [Abstral]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1053660",
      "display" : "fentanyl 0.4 MG Sublingual Tablet [Abstral]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1053663",
      "display" : "fentanyl 0.6 MG Sublingual Tablet [Abstral]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1053666",
      "display" : "fentanyl 0.8 MG Sublingual Tablet [Abstral]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1115575",
      "display" : "fentanyl 0.1 MG/ACTUAT Metered Dose Nasal Spray [Lazanda]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1115579",
      "display" : "fentanyl 0.4 MG/ACTUAT Metered Dose Nasal Spray [Lazanda]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1237055",
      "display" : "fentanyl 0.1 MG/ACTUAT Mucosal Spray [Subsys]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1237059",
      "display" : "fentanyl 0.2 MG/ACTUAT Mucosal Spray [Subsys]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1237062",
      "display" : "fentanyl 0.4 MG/ACTUAT Mucosal Spray [Subsys]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1237066",
      "display" : "fentanyl 0.6 MG/ACTUAT Mucosal Spray [Subsys]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1237070",
      "display" : "fentanyl 0.8 MG/ACTUAT Mucosal Spray [Subsys]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1666837",
      "display" : "80 ACTUAT fentanyl 0.04 MG/ACTUAT Transdermal System [Ionsys]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1729322",
      "display" : "fentanyl 0.3 MG/ACTUAT Metered Dose Nasal Spray [Lazanda]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "261106",
      "display" : "fentanyl 0.2 MG Oral Lozenge [Actiq]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "261107",
      "display" : "fentanyl 0.6 MG Oral Lozenge [Actiq]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "261108",
      "display" : "fentanyl 0.8 MG Oral Lozenge [Actiq]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "261109",
      "display" : "fentanyl 1.2 MG Oral Lozenge [Actiq]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "261110",
      "display" : "fentanyl 1.6 MG Oral Lozenge [Actiq]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "262219",
      "display" : "fentanyl 0.4 MG Oral Lozenge [Actiq]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "668622",
      "display" : "fentanyl 0.1 MG Buccal Tablet [Fentora]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "668624",
      "display" : "fentanyl 0.2 MG Buccal Tablet [Fentora]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "668626",
      "display" : "fentanyl 0.4 MG Buccal Tablet [Fentora]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "668628",
      "display" : "fentanyl 0.6 MG Buccal Tablet [Fentora]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "668630",
      "display" : "fentanyl 0.8 MG Buccal Tablet [Fentora]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1053647",
      "display" : "fentanyl 0.1 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1053652",
      "display" : "fentanyl 0.2 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1053655",
      "display" : "fentanyl 0.3 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1053658",
      "display" : "fentanyl 0.4 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1053661",
      "display" : "fentanyl 0.6 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1053664",
      "display" : "fentanyl 0.8 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1115573",
      "display" : "fentanyl 0.1 MG/ACTUAT Metered Dose Nasal Spray"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1115577",
      "display" : "fentanyl 0.4 MG/ACTUAT Metered Dose Nasal Spray"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1237050",
      "display" : "fentanyl 0.1 MG/ACTUAT Mucosal Spray"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1237057",
      "display" : "fentanyl 0.2 MG/ACTUAT Mucosal Spray"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1237060",
      "display" : "fentanyl 0.4 MG/ACTUAT Mucosal Spray"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1237064",
      "display" : "fentanyl 0.6 MG/ACTUAT Mucosal Spray"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1237068",
      "display" : "fentanyl 0.8 MG/ACTUAT Mucosal Spray"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1603495",
      "display" : "72 HR fentanyl 0.0375 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1603498",
      "display" : "72 HR fentanyl 0.0625 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1603501",
      "display" : "72 HR fentanyl 0.0875 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1666831",
      "display" : "80 ACTUAT fentanyl 0.04 MG/ACTUAT Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1729320",
      "display" : "fentanyl 0.3 MG/ACTUAT Metered Dose Nasal Spray"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "197696",
      "display" : "72 HR fentanyl 0.075 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "245134",
      "display" : "72 HR fentanyl 0.025 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "245135",
      "display" : "72 HR fentanyl 0.05 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "245136",
      "display" : "72 HR fentanyl 0.1 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "310293",
      "display" : "fentanyl 1.2 MG Oral Lozenge"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "310294",
      "display" : "fentanyl 1.6 MG Oral Lozenge"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "310295",
      "display" : "fentanyl 0.2 MG Oral Lozenge"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "310296",
      "display" : "fentanyl 0.3 MG Oral Lozenge"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "310297",
      "display" : "fentanyl 0.4 MG Oral Lozenge"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "313992",
      "display" : "fentanyl 0.6 MG Oral Lozenge"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "313993",
      "display" : "fentanyl 0.8 MG Oral Lozenge"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "577057",
      "display" : "72 HR fentanyl 0.012 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "668363",
      "display" : "fentanyl 0.1 MG Buccal Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "668364",
      "display" : "fentanyl 0.2 MG Buccal Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "668365",
      "display" : "fentanyl 0.4 MG Buccal Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "668366",
      "display" : "fentanyl 0.6 MG Buccal Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "668367",
      "display" : "fentanyl 0.8 MG Buccal Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "706898",
      "display" : "fentanyl 0.3 MG Buccal Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "858087",
      "display" : "fentanyl 1.2 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "858092",
      "display" : "fentanyl 0.2 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "858095",
      "display" : "fentanyl 0.4 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "858098",
      "display" : "fentanyl 0.6 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "858101",
      "display" : "fentanyl 0.8 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1442445",
      "display" : "acetaminophen 20 MG/ML / hydrocodone bitartrate 0.667 MG/ML Oral Solution [Lortab]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1492673",
      "display" : "acetaminophen 325 MG / hydrocodone bitartrate 5 MG Oral Tablet [Lorcet]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1495472",
      "display" : "acetaminophen 325 MG / hydrocodone bitartrate 10 MG Oral Tablet [Lortab]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1495474",
      "display" : "acetaminophen 325 MG / hydrocodone bitartrate 5 MG Oral Tablet [Lortab]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1495476",
      "display" : "acetaminophen 325 MG / hydrocodone bitartrate 7.5 MG Oral Tablet [Lortab]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1542981",
      "display" : "acetaminophen 325 MG / hydrocodone bitartrate 2.5 MG Oral Tablet [Verdrocet]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1542988",
      "display" : "hydrocodone bitartrate 10 MG / ibuprofen 200 MG Oral Tablet [Xylon]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1595736",
      "display" : "Abuse-Deterrent 24 HR hydrocodone bitartrate 20 MG Extended Release Oral Tablet [Hysingla]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1595742",
      "display" : "Abuse-Deterrent 24 HR hydrocodone bitartrate 30 MG Extended Release Oral Tablet [Hysingla]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1595748",
      "display" : "Abuse-Deterrent 24 HR hydrocodone bitartrate 40 MG Extended Release Oral Tablet [Hysingla]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1595754",
      "display" : "Abuse-Deterrent 24 HR hydrocodone bitartrate 60 MG Extended Release Oral Tablet [Hysingla]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1595760",
      "display" : "Abuse-Deterrent 24 HR hydrocodone bitartrate 80 MG Extended Release Oral Tablet [Hysingla]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1595766",
      "display" : "Abuse-Deterrent 24 HR hydrocodone bitartrate 100 MG Extended Release Oral Tablet [Hysingla]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1595772",
      "display" : "Abuse-Deterrent 24 HR hydrocodone bitartrate 120 MG Extended Release Oral Tablet [Hysingla]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1860492",
      "display" : "12 HR hydrocodone bitartrate 10 MG Extended Release Oral Capsule [Zohydro]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1860494",
      "display" : "12 HR hydrocodone bitartrate 15 MG Extended Release Oral Capsule [Zohydro]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1860496",
      "display" : "12 HR hydrocodone bitartrate 20 MG Extended Release Oral Capsule [Zohydro]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1860498",
      "display" : "12 HR hydrocodone bitartrate 30 MG Extended Release Oral Capsule [Zohydro]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1860500",
      "display" : "12 HR hydrocodone bitartrate 40 MG Extended Release Oral Capsule [Zohydro]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1860502",
      "display" : "12 HR hydrocodone bitartrate 50 MG Extended Release Oral Capsule [Zohydro]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "856942",
      "display" : "acetaminophen 21.7 MG/ML / hydrocodone bitartrate 0.5 MG/ML Oral Solution [Hycet]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "856946",
      "display" : "acetaminophen 21.7 MG/ML / hydrocodone bitartrate 0.67 MG/ML Oral Solution [Zamicet]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "857001",
      "display" : "acetaminophen 325 MG / hydrocodone bitartrate 10 MG Oral Tablet [Norco]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "857004",
      "display" : "acetaminophen 325 MG / hydrocodone bitartrate 5 MG Oral Tablet [Norco]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "857007",
      "display" : "acetaminophen 325 MG / hydrocodone bitartrate 7.5 MG Oral Tablet [Norco]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "858772",
      "display" : "hydrocodone bitartrate 2.5 MG / ibuprofen 200 MG Oral Tablet [Reprexain]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "858780",
      "display" : "hydrocodone bitartrate 5 MG / ibuprofen 200 MG Oral Tablet [Ibudone]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "858838",
      "display" : "hydrocodone bitartrate 7.5 MG / ibuprofen 200 MG Oral Tablet [Vicoprofen]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "859317",
      "display" : "hydrocodone bitartrate 10 MG / ibuprofen 200 MG Oral Tablet [Ibudone]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1044427",
      "display" : "acetaminophen 20 MG/ML / hydrocodone bitartrate 0.667 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1595730",
      "display" : "Abuse-Deterrent 24 HR hydrocodone bitartrate 20 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1595740",
      "display" : "Abuse-Deterrent 24 HR hydrocodone bitartrate 30 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1595746",
      "display" : "Abuse-Deterrent 24 HR hydrocodone bitartrate 40 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1595752",
      "display" : "Abuse-Deterrent 24 HR hydrocodone bitartrate 60 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1595758",
      "display" : "Abuse-Deterrent 24 HR hydrocodone bitartrate 80 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1595764",
      "display" : "Abuse-Deterrent 24 HR hydrocodone bitartrate 100 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1595770",
      "display" : "Abuse-Deterrent 24 HR hydrocodone bitartrate 120 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1860491",
      "display" : "12 HR hydrocodone bitartrate 10 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1860493",
      "display" : "12 HR hydrocodone bitartrate 15 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1860495",
      "display" : "12 HR hydrocodone bitartrate 20 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1860497",
      "display" : "12 HR hydrocodone bitartrate 30 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1860499",
      "display" : "12 HR hydrocodone bitartrate 40 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1860501",
      "display" : "12 HR hydrocodone bitartrate 50 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "833036",
      "display" : "acetaminophen 750 MG / hydrocodone bitartrate 7.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "856903",
      "display" : "acetaminophen 500 MG / hydrocodone bitartrate 5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "856908",
      "display" : "acetaminophen 660 MG / hydrocodone bitartrate 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "856940",
      "display" : "acetaminophen 21.7 MG/ML / hydrocodone bitartrate 0.5 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "856944",
      "display" : "acetaminophen 21.7 MG/ML / hydrocodone bitartrate 0.67 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "856962",
      "display" : "acetaminophen 500 MG / hydrocodone bitartrate 5 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "856980",
      "display" : "acetaminophen 300 MG / hydrocodone bitartrate 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "856987",
      "display" : "acetaminophen 300 MG / hydrocodone bitartrate 5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "856992",
      "display" : "acetaminophen 300 MG / hydrocodone bitartrate 7.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "856999",
      "display" : "acetaminophen 325 MG / hydrocodone bitartrate 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "857002",
      "display" : "acetaminophen 325 MG / hydrocodone bitartrate 5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "857005",
      "display" : "acetaminophen 325 MG / hydrocodone bitartrate 7.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "857076",
      "display" : "acetaminophen 33.3 MG/ML / hydrocodone bitartrate 0.333 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "857083",
      "display" : "acetaminophen 650 MG / hydrocodone bitartrate 7.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "857099",
      "display" : "acetaminophen 33.3 MG/ML / hydrocodone bitartrate 0.5 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "857107",
      "display" : "acetaminophen 500 MG / hydrocodone bitartrate 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "857111",
      "display" : "acetaminophen 500 MG / hydrocodone bitartrate 2.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "857118",
      "display" : "acetaminophen 500 MG / hydrocodone bitartrate 7.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "857121",
      "display" : "aspirin 500 MG / hydrocodone bitartrate 5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "857128",
      "display" : "acetaminophen 400 MG / hydrocodone bitartrate 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "857131",
      "display" : "acetaminophen 400 MG / hydrocodone bitartrate 5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "857134",
      "display" : "acetaminophen 400 MG / hydrocodone bitartrate 7.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "857383",
      "display" : "acetaminophen 650 MG / hydrocodone bitartrate 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "857391",
      "display" : "acetaminophen 325 MG / hydrocodone bitartrate 2.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "857501",
      "display" : "acetaminophen 556 MG / hydrocodone bitartrate 5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "858770",
      "display" : "hydrocodone bitartrate 2.5 MG / ibuprofen 200 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "858778",
      "display" : "hydrocodone bitartrate 5 MG / ibuprofen 200 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "858798",
      "display" : "hydrocodone bitartrate 7.5 MG / ibuprofen 200 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "859315",
      "display" : "hydrocodone bitartrate 10 MG / ibuprofen 200 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "860599",
      "display" : "hydrocodone bitartrate 7.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2103199",
      "display" : "sufentanil 0.03 MG Sublingual Tablet [Dsuvia]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2103192",
      "display" : "sufentanil 0.03 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "197873",
      "display" : "levorphanol tartrate 2 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2058845",
      "display" : "levorphanol tartrate 3 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "861517",
      "display" : "meperidine hydrochloride 100 MG Oral Tablet [Demerol]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "861525",
      "display" : "meperidine hydrochloride 50 MG Oral Tablet [Demerol]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "861455",
      "display" : "meperidine hydrochloride 100 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "861467",
      "display" : "meperidine hydrochloride 50 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "861479",
      "display" : "meperidine hydrochloride 10 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "106505",
      "display" : "meptazinol 200 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1990745",
      "display" : "methadone hydrochloride 40 MG Tablet for Oral Suspension [Diskets]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "864708",
      "display" : "methadone hydrochloride 10 MG Oral Tablet [Dolophine]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "864712",
      "display" : "methadone hydrochloride 10 MG Oral Tablet [Methadose]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "864720",
      "display" : "methadone hydrochloride 5 MG Oral Tablet [Dolophine]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "864737",
      "display" : "methadone hydrochloride 5 MG Oral Tablet [Methadose]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "864980",
      "display" : "methadone hydrochloride 40 MG Tablet for Oral Suspension [Methadose]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "991149",
      "display" : "methadone hydrochloride 10 MG/ML Oral Solution [Methadose]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "864706",
      "display" : "methadone hydrochloride 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "864718",
      "display" : "methadone hydrochloride 5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "864761",
      "display" : "methadone hydrochloride 1 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "864769",
      "display" : "methadone hydrochloride 2 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "864826",
      "display" : "methadone hydrochloride 5 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "864978",
      "display" : "methadone hydrochloride 40 MG Tablet for Oral Suspension"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "864984",
      "display" : "methadone hydrochloride 20 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "991147",
      "display" : "methadone hydrochloride 10 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1871440",
      "display" : "Abuse-Deterrent 12 HR morphine sulfate 15 MG Extended Release Oral Tablet [Arymo]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1871443",
      "display" : "Abuse-Deterrent 12 HR morphine sulfate 30 MG Extended Release Oral Tablet [Arymo]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1871446",
      "display" : "Abuse-Deterrent 12 HR morphine sulfate 60 MG Extended Release Oral Tablet [Arymo]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892496",
      "display" : "morphine sulfate 10 MG Extended Release Oral Capsule [Kadian]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892556",
      "display" : "morphine sulfate 100 MG Extended Release Oral Capsule [Kadian]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892560",
      "display" : "morphine sulfate 100 MG Extended Release Oral Tablet [MS Contin]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892574",
      "display" : "morphine sulfate 15 MG Extended Release Oral Tablet [MS Contin]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892598",
      "display" : "morphine sulfate 20 MG Extended Release Oral Capsule [Kadian]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892648",
      "display" : "morphine sulfate 200 MG Extended Release Oral Tablet [MS Contin]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892658",
      "display" : "morphine sulfate 30 MG Extended Release Oral Capsule [Kadian]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892660",
      "display" : "morphine sulfate 30 MG Extended Release Oral Tablet [MS Contin]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "894803",
      "display" : "morphine sulfate 50 MG Extended Release Oral Capsule [Kadian]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "894805",
      "display" : "morphine sulfate 60 MG Extended Release Oral Capsule [Kadian]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "894813",
      "display" : "morphine sulfate 60 MG Extended Release Oral Tablet [MS Contin]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1303736",
      "display" : "morphine sulfate 40 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1871434",
      "display" : "Abuse-Deterrent 12 HR morphine sulfate 15 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1871441",
      "display" : "Abuse-Deterrent 12 HR morphine sulfate 30 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1871444",
      "display" : "Abuse-Deterrent 12 HR morphine sulfate 60 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "863845",
      "display" : "Abuse-Deterrent morphine sulfate 100 MG / naltrexone hydrochloride 4 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "863848",
      "display" : "Abuse-Deterrent morphine sulfate 20 MG / naltrexone hydrochloride 0.8 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "863850",
      "display" : "Abuse-Deterrent morphine sulfate 30 MG / naltrexone hydrochloride 1.2 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "863852",
      "display" : "Abuse-Deterrent morphine sulfate 50 MG / naltrexone hydrochloride 2 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "863854",
      "display" : "Abuse-Deterrent morphine sulfate 60 MG / naltrexone hydrochloride 2.4 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "863856",
      "display" : "Abuse-Deterrent morphine sulfate 80 MG / naltrexone hydrochloride 3.2 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "891874",
      "display" : "morphine sulfate 100 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "891881",
      "display" : "morphine sulfate 15 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "891888",
      "display" : "morphine sulfate 30 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "891893",
      "display" : "morphine sulfate 60 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892297",
      "display" : "24 HR morphine sulfate 120 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892342",
      "display" : "24 HR morphine sulfate 30 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892345",
      "display" : "morphine sulfate 30 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892349",
      "display" : "24 HR morphine sulfate 60 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892352",
      "display" : "morphine sulfate 60 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892355",
      "display" : "24 HR morphine sulfate 90 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892494",
      "display" : "morphine sulfate 10 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892516",
      "display" : "morphine sulfate 10 MG Rectal Suppository"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892554",
      "display" : "morphine sulfate 100 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892579",
      "display" : "morphine sulfate 15 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892582",
      "display" : "morphine sulfate 15 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892589",
      "display" : "morphine sulfate 2 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892596",
      "display" : "morphine sulfate 20 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892603",
      "display" : "morphine sulfate 20 MG Rectal Suppository"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892625",
      "display" : "morphine sulfate 20 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892643",
      "display" : "morphine sulfate 200 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892646",
      "display" : "morphine sulfate 200 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892669",
      "display" : "morphine sulfate 30 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892672",
      "display" : "morphine sulfate 30 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "892678",
      "display" : "morphine sulfate 30 MG Rectal Suppository"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "894780",
      "display" : "morphine sulfate 4 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "894801",
      "display" : "morphine sulfate 50 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "894807",
      "display" : "morphine sulfate 5 MG Rectal Suppository"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "894814",
      "display" : "morphine sulfate 80 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "894942",
      "display" : "24 HR morphine sulfate 45 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "894970",
      "display" : "24 HR morphine sulfate 75 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "895014",
      "display" : "morphine sulfate 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "895016",
      "display" : "morphine sulfate 10 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "895022",
      "display" : "morphine sulfate 100 MG Rectal Suppository"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "895185",
      "display" : "morphine sulfate 15 MG Rectal Suppository"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "895199",
      "display" : "morphine sulfate 2 MG/ML Oral Suspension"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "895201",
      "display" : "morphine sulfate 20 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "895206",
      "display" : "morphine sulfate 200 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "895208",
      "display" : "morphine sulfate 3 MG/ML Oral Suspension"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "895215",
      "display" : "morphine sulfate 35 MG Rectal Suppository"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "895217",
      "display" : "morphine sulfate 5 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "895219",
      "display" : "morphine sulfate 5 MG/ML Oral Suspension"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "895221",
      "display" : "morphine sulfate 50 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "895227",
      "display" : "morphine sulfate 50 MG Rectal Suppository"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "895238",
      "display" : "morphine sulfate 6 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "895240",
      "display" : "morphine sulfate 6.67 MG/ML Oral Suspension"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "895247",
      "display" : "morphine sulfate 60 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "895248",
      "display" : "morphine sulfate 75 MG Rectal Suppository"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "312104",
      "display" : "belladonna alkaloids 16.2 MG / opium 30 MG Rectal Suppository"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "312107",
      "display" : "belladonna alkaloids 16.2 MG / opium 60 MG Rectal Suppository"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "830196",
      "display" : "opium tincture 100 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049216",
      "display" : "acetaminophen 325 MG / oxycodone hydrochloride 10 MG Oral Tablet [Endocet]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049223",
      "display" : "acetaminophen 325 MG / oxycodone hydrochloride 5 MG Oral Tablet [Endocet]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049227",
      "display" : "acetaminophen 325 MG / oxycodone hydrochloride 7.5 MG Oral Tablet [Endocet]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049504",
      "display" : "Abuse-Deterrent 12 HR oxycodone hydrochloride 10 MG Extended Release Oral Tablet [Oxycontin]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049545",
      "display" : "Abuse-Deterrent 12 HR oxycodone hydrochloride 15 MG Extended Release Oral Tablet [Oxycontin]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049565",
      "display" : "Abuse-Deterrent 12 HR oxycodone hydrochloride 20 MG Extended Release Oral Tablet [Oxycontin]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049576",
      "display" : "Abuse-Deterrent 12 HR oxycodone hydrochloride 30 MG Extended Release Oral Tablet [Oxycontin]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049586",
      "display" : "Abuse-Deterrent 12 HR oxycodone hydrochloride 40 MG Extended Release Oral Tablet [Oxycontin]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049595",
      "display" : "Abuse-Deterrent 12 HR oxycodone hydrochloride 60 MG Extended Release Oral Tablet [Oxycontin]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049601",
      "display" : "Abuse-Deterrent 12 HR oxycodone hydrochloride 80 MG Extended Release Oral Tablet [Oxycontin]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049613",
      "display" : "oxycodone hydrochloride 15 MG Oral Tablet [Roxicodone]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049620",
      "display" : "oxycodone hydrochloride 30 MG Oral Tablet [Roxicodone]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049623",
      "display" : "oxycodone hydrochloride 5 MG Oral Tablet [Roxicodone]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049625",
      "display" : "acetaminophen 325 MG / oxycodone hydrochloride 10 MG Oral Tablet [Percocet]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049637",
      "display" : "acetaminophen 325 MG / oxycodone hydrochloride 2.5 MG Oral Tablet [Percocet]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049640",
      "display" : "acetaminophen 325 MG / oxycodone hydrochloride 5 MG Oral Tablet [Percocet]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049642",
      "display" : "acetaminophen 325 MG / oxycodone hydrochloride 7.5 MG Oral Tablet [Percocet]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1487288",
      "display" : "acetaminophen 325 MG / oxycodone hydrochloride 2.5 MG Oral Tablet [Endocet]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1537116",
      "display" : "acetaminophen 300 MG / oxycodone hydrochloride 5 MG Oral Tablet [Primlev]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1537120",
      "display" : "acetaminophen 300 MG / oxycodone hydrochloride 10 MG Oral Tablet [Primlev]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1537122",
      "display" : "acetaminophen 300 MG / oxycodone hydrochloride 7.5 MG Oral Tablet [Primlev]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1664448",
      "display" : "oxycodone hydrochloride 5 MG Oral Tablet [Oxaydo]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1664634",
      "display" : "oxycodone hydrochloride 7.5 MG Oral Tablet [Oxaydo]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1790533",
      "display" : "Abuse-Deterrent 12 HR oxycodone 9 MG Extended Release Oral Capsule [Xtampza]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1791560",
      "display" : "Abuse-Deterrent 12 HR oxycodone 13.5 MG Extended Release Oral Capsule [Xtampza]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1791569",
      "display" : "Abuse-Deterrent 12 HR oxycodone 18 MG Extended Release Oral Capsule [Xtampza]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1791576",
      "display" : "Abuse-Deterrent 12 HR oxycodone 27 MG Extended Release Oral Capsule [Xtampza]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1791582",
      "display" : "Abuse-Deterrent 12 HR oxycodone 36 MG Extended Release Oral Capsule [Xtampza]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1944535",
      "display" : "Abuse-Deterrent oxycodone hydrochloride 15 MG Oral Tablet [Roxybond]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1944540",
      "display" : "Abuse-Deterrent oxycodone hydrochloride 30 MG Oral Tablet [Roxybond]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1944543",
      "display" : "Abuse-Deterrent oxycodone hydrochloride 5 MG Oral Tablet [Roxybond]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2045500",
      "display" : "acetaminophen 300 MG / oxycodone hydrochloride 2.5 MG Oral Tablet [Nalocet]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2279510",
      "display" : "acetaminophen 300 MG / oxycodone hydrochloride 10 MG Oral Tablet [Prolate]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2279512",
      "display" : "acetaminophen 300 MG / oxycodone hydrochloride 5 MG Oral Tablet [Prolate]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2279514",
      "display" : "acetaminophen 300 MG / oxycodone hydrochloride 7.5 MG Oral Tablet [Prolate]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2281851",
      "display" : "acetaminophen 60 MG/ML / oxycodone hydrochloride 2 MG/ML Oral Solution [Prolate]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2693196",
      "display" : "Abuse-Deterrent oxycodone hydrochloride 10 MG Oral Tablet [Roxybond]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "848928",
      "display" : "aspirin 325 MG / oxycodone hydrochloride 4.84 MG Oral Tablet [Endodan Reformulated May 2009]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1014599",
      "display" : "acetaminophen 300 MG / oxycodone hydrochloride 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1014615",
      "display" : "acetaminophen 300 MG / oxycodone hydrochloride 5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1014632",
      "display" : "acetaminophen 300 MG / oxycodone hydrochloride 7.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1037259",
      "display" : "acetaminophen 300 MG / oxycodone hydrochloride 2.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049214",
      "display" : "acetaminophen 325 MG / oxycodone hydrochloride 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049221",
      "display" : "acetaminophen 325 MG / oxycodone hydrochloride 5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049225",
      "display" : "acetaminophen 325 MG / oxycodone hydrochloride 7.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049233",
      "display" : "acetaminophen 500 MG / oxycodone hydrochloride 7.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049251",
      "display" : "acetaminophen 400 MG / oxycodone hydrochloride 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049260",
      "display" : "acetaminophen 400 MG / oxycodone hydrochloride 5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049267",
      "display" : "acetaminophen 400 MG / oxycodone hydrochloride 7.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049270",
      "display" : "acetaminophen 650 MG / oxycodone hydrochloride 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049502",
      "display" : "12 HR oxycodone hydrochloride 10 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049543",
      "display" : "12 HR oxycodone hydrochloride 15 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049563",
      "display" : "12 HR oxycodone hydrochloride 20 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049574",
      "display" : "12 HR oxycodone hydrochloride 30 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049580",
      "display" : "acetaminophen 65 MG/ML / oxycodone hydrochloride 1 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049584",
      "display" : "12 HR oxycodone hydrochloride 40 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049589",
      "display" : "ibuprofen 400 MG / oxycodone hydrochloride 5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049593",
      "display" : "12 HR oxycodone hydrochloride 60 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049599",
      "display" : "12 HR oxycodone hydrochloride 80 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049604",
      "display" : "oxycodone hydrochloride 1 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049611",
      "display" : "oxycodone hydrochloride 15 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049615",
      "display" : "oxycodone hydrochloride 20 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049618",
      "display" : "oxycodone hydrochloride 30 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049621",
      "display" : "oxycodone hydrochloride 5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049635",
      "display" : "acetaminophen 325 MG / oxycodone hydrochloride 2.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049651",
      "display" : "acetaminophen 500 MG / oxycodone hydrochloride 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049658",
      "display" : "acetaminophen 500 MG / oxycodone hydrochloride 5 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049683",
      "display" : "oxycodone hydrochloride 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049686",
      "display" : "oxycodone hydrochloride 20 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049696",
      "display" : "oxycodone hydrochloride 5 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049717",
      "display" : "oxycodone hydrochloride 10 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049720",
      "display" : "oxycodone hydrochloride 10 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049721",
      "display" : "oxycodone hydrochloride 20 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1049727",
      "display" : "oxycodone hydrochloride 5 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1113314",
      "display" : "oxycodone hydrochloride 7.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1790527",
      "display" : "Abuse-Deterrent 12 HR oxycodone 9 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1791558",
      "display" : "Abuse-Deterrent 12 HR oxycodone 13.5 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1791567",
      "display" : "Abuse-Deterrent 12 HR oxycodone 18 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1791574",
      "display" : "Abuse-Deterrent 12 HR oxycodone 27 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1791580",
      "display" : "Abuse-Deterrent 12 HR oxycodone 36 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1860127",
      "display" : "Abuse-Deterrent 12 HR oxycodone hydrochloride 60 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1860129",
      "display" : "Abuse-Deterrent 12 HR oxycodone hydrochloride 20 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1860137",
      "display" : "Abuse-Deterrent 12 HR oxycodone hydrochloride 40 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1860148",
      "display" : "Abuse-Deterrent 12 HR oxycodone hydrochloride 80 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1860151",
      "display" : "Abuse-Deterrent 12 HR oxycodone hydrochloride 30 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1860154",
      "display" : "Abuse-Deterrent 12 HR oxycodone hydrochloride 15 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1860157",
      "display" : "Abuse-Deterrent 12 HR oxycodone hydrochloride 10 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1944529",
      "display" : "Abuse-Deterrent oxycodone hydrochloride 15 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1944538",
      "display" : "Abuse-Deterrent oxycodone hydrochloride 30 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1944541",
      "display" : "Abuse-Deterrent oxycodone hydrochloride 5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2105822",
      "display" : "acetaminophen 60 MG/ML / oxycodone hydrochloride 2 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2693194",
      "display" : "Abuse-Deterrent oxycodone hydrochloride 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "637540",
      "display" : "aspirin 325 MG / oxycodone hydrochloride 4.5 MG / oxycodone terephthalate 0.38 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "724614",
      "display" : "aspirin 325 MG / oxycodone hydrochloride 2.25 MG / oxycodone terephthalate 0.19 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "848768",
      "display" : "aspirin 325 MG / oxycodone hydrochloride 4.84 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "977874",
      "display" : "12 HR oxymorphone hydrochloride 10 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "977894",
      "display" : "12 HR oxymorphone hydrochloride 15 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "977902",
      "display" : "12 HR oxymorphone hydrochloride 20 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "977909",
      "display" : "12 HR oxymorphone hydrochloride 30 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "977915",
      "display" : "12 HR oxymorphone hydrochloride 40 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "977923",
      "display" : "12 HR oxymorphone hydrochloride 5 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "977929",
      "display" : "12 HR oxymorphone hydrochloride 7.5 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "977939",
      "display" : "oxymorphone hydrochloride 5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "977942",
      "display" : "oxymorphone hydrochloride 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1149367",
      "display" : "12 HR tapentadol 100 MG Extended Release Oral Tablet [Nucynta]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1149370",
      "display" : "12 HR tapentadol 150 MG Extended Release Oral Tablet [Nucynta]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1149373",
      "display" : "12 HR tapentadol 200 MG Extended Release Oral Tablet [Nucynta]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1149376",
      "display" : "12 HR tapentadol 250 MG Extended Release Oral Tablet [Nucynta]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1149378",
      "display" : "12 HR tapentadol 50 MG Extended Release Oral Tablet [Nucynta]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "854140",
      "display" : "tapentadol 100 MG Oral Tablet [Nucynta]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "854142",
      "display" : "tapentadol 50 MG Oral Tablet [Nucynta]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "854144",
      "display" : "tapentadol 75 MG Oral Tablet [Nucynta]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1148797",
      "display" : "12 HR tapentadol 100 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1148800",
      "display" : "12 HR tapentadol 150 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1148803",
      "display" : "12 HR tapentadol 200 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1148807",
      "display" : "12 HR tapentadol 250 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1148809",
      "display" : "12 HR tapentadol 50 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1356315",
      "display" : "tapentadol 20 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "825409",
      "display" : "tapentadol 100 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "825411",
      "display" : "tapentadol 50 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "825413",
      "display" : "tapentadol 75 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "250485",
      "display" : "pentazocine 25 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "250486",
      "display" : "pentazocine 50 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "250877",
      "display" : "pentazocine 50 MG Rectal Suppository"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "312288",
      "display" : "acetaminophen 650 MG / pentazocine 25 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "312289",
      "display" : "naloxone 0.5 MG / pentazocine 50 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "827748",
      "display" : "propoxyphene napsylate 100 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "827751",
      "display" : "acetaminophen 325 MG / propoxyphene napsylate 100 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "828576",
      "display" : "acetaminophen 650 MG / propoxyphene napsylate 100 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "828585",
      "display" : "aspirin 389 MG / caffeine 32.4 MG / propoxyphene hydrochloride 32 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "828594",
      "display" : "aspirin 389 MG / caffeine 32.4 MG / propoxyphene hydrochloride 65 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "849279",
      "display" : "propoxyphene hydrochloride 65 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "849293",
      "display" : "acetaminophen 325 MG / propoxyphene hydrochloride 32.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "849295",
      "display" : "acetaminophen 325 MG / propoxyphene napsylate 50 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "849304",
      "display" : "acetaminophen 500 MG / propoxyphene napsylate 100 MG Oral Tablet"
    }]
  }
}

```
