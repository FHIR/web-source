# Benzodiazepine urine drug screening tests - 2022 CDC Clinical Practice Guideline for Prescribing Opioids Implementation Guide v2022.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Benzodiazepine urine drug screening tests**

## ValueSet: Benzodiazepine urine drug screening tests 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.org/guides/cdc/opioid-cds/ValueSet/benzodiazepine-urine-drug-screening-tests | *Version*:2022.1.0 |
| Active as of 2024-04-15 | *Computable Name*:BENZODIAZEPINE_URINE_DRUG_SCREENING_TESTS |
| **Copyright/Legal**: © CDC 2016+. | |

 
Presumed general urine tests for benzodiazepines that are not specific to a particular substance. 

 
Identification of urine drug tests where results can be used when considering pain management therapy 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

No formal definition provided for this value set

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "benzodiazepine-urine-drug-screening-tests",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-computablevalueset",
    "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-executablevalueset"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-rules-text",
    "valueMarkdown" : "Step 1: go to https://loinc.org/tree/\nStep 2: use query benzodiazepine AND system:urine\nStep 3: export the results to CSV\nStep 4: Filter results by properties defined in query"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-author",
    "valueContactDetail" : {
      "name" : "MD Partners, Inc.",
      "telecom" : [{
        "system" : "email",
        "value" : "info@mdpartners.com"
      }]
    }
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-clinical-focus",
    "valueString" : "Presumed general urine tests for benzodiazepines that are not specific to a particular substance."
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-dataelement-scope",
    "valueString" : "Urine test"
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-inclusion-criteria",
    "valueString" : "Codes"
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-exclusion-criteria",
    "valueString" : "None"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "computable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "executable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-usageWarning",
    "valueString" : "This value set contains a point-in-time expansion enumerating the codes that meet the value set intent. As new versions of the code systems used by the value set are released, the contents of this expansion will need to be updated to incorporate newly defined codes that meet the value set intent. Before, and periodically during production use, the value set expansion contents SHOULD be updated. The value set expansion specifies the timestamp when the expansion was produced, SHOULD contain the parameters used for the expansion, and SHALL contain the codes that are obtained by evaluating the value set definition. If this is ONLY an executable value set, a distributable definition of the value set must be obtained to compute the updated expansion."
  }],
  "url" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/benzodiazepine-urine-drug-screening-tests",
  "version" : "2022.1.0",
  "name" : "BENZODIAZEPINE_URINE_DRUG_SCREENING_TESTS",
  "title" : "Benzodiazepine urine drug screening tests",
  "status" : "active",
  "experimental" : false,
  "date" : "2024-04-15T12:22:34-06:00",
  "publisher" : "CDC / Security Risk Solutions, Inc. (SRS)",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.securityrisksolutions.com"
    }]
  }],
  "description" : "Presumed general urine tests for benzodiazepines that are not specific to a particular substance.",
  "purpose" : "Identification of urine drug tests where results can be used when considering pain management therapy",
  "copyright" : "© CDC 2016+.",
  "expansion" : {
    "timestamp" : "2024-04-15T12:22:36-06:00",
    "total" : 30,
    "contains" : [{
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "99262-8",
      "display" : "Designer benzodiazepines Ur Ql Cfm"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "99263-6",
      "display" : "Delorazepam Ur Cfm-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "99276-8",
      "display" : "3-OH-phenazepam Ur Cfm-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "42235-2",
      "display" : "Benzodiaz metab Ur Ql Scn"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3386-0",
      "display" : "Deprecated Benzodiaz Neg Ur"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3385-2",
      "display" : "Benzodiaz Neg Ur"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3388-6",
      "display" : "Deprecated Benzodiaz Pos Ur"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3387-8",
      "display" : "Benzodiaz Pos Ur"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19282-3",
      "display" : "Benzodiaz Pos Ur Cfm"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "9428-4",
      "display" : "Benzodiaz Ur-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "20412-3",
      "display" : "Benzodiaz Ur Cfm-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "70140-9",
      "display" : "Benzodiaz Ur Scn-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3390-2",
      "display" : "Benzodiaz Ur Ql"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "16195-0",
      "display" : "Benzodiaz Ur Ql Cfm"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "14316-4",
      "display" : "Benzodiaz Ur Ql Scn"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "70141-7",
      "display" : "Benzodiaz Ur Ql Scn>200 ng/mL"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "70142-5",
      "display" : "Benzodiaz Ur Ql Scn>300 ng/mL"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "52955-2",
      "display" : "Benzodiaz Ur-sCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19286-4",
      "display" : "Benzodiaz Cfm Meth Ur"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19064-5",
      "display" : "Benzodiaz CtO Ur-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19284-9",
      "display" : "Benzodiaz CtO Ur Cfm-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19283-1",
      "display" : "Benzodiaz CtO Ur Scn-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19285-6",
      "display" : "Benzodiaz Scn Meth Ur"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19280-7",
      "display" : "Benzodiaz Tested Ur Scn"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19279-9",
      "display" : "Benzodiaz Tested Ur Scn"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "41467-2",
      "display" : "Benzodiaz/Creat Ur"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "53736-5",
      "display" : "Benzodiaz.other Ur-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "53745-6",
      "display" : "Benzodiazepines Pnl Ur"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "90890-5",
      "display" : "Benzodiazepines Pnl Ur Cfm"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "94117-9",
      "display" : "Benzodiazepines Pnl Ur Scn"
    }]
  }
}

```
