# Barbiturate urine drug screening tests - 2022 CDC Clinical Practice Guideline for Prescribing Opioids Implementation Guide v2022.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Barbiturate urine drug screening tests**

## ValueSet: Barbiturate urine drug screening tests 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.org/guides/cdc/opioid-cds/ValueSet/barbiturate-urine-drug-screening-tests | *Version*:2022.1.0 |
| Active as of 2024-04-15 | *Computable Name*:BARBITURATE_URINE_DRUG_SCREENING_TESTS |
| **Copyright/Legal**: © CDC 2016+. | |

 
Presumed general urine tests for barbiturates that are not specific to a particular substance. 

 
Identification of urine drug tests where results can be used when considering pain management therapy 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

No formal definition provided for this value set

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "barbiturate-urine-drug-screening-tests",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-computablevalueset",
    "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-executablevalueset"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-rules-text",
    "valueMarkdown" : "Step 1: go to https://loinc.org/tree/\nStep 2: use query barbiturate AND system:urine\nStep 3: export the results to CSV\nStep 4: Filter results by properties defined in query"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-author",
    "valueContactDetail" : {
      "name" : "MD Partners, Inc.",
      "telecom" : [{
        "system" : "email",
        "value" : "info@mdpartners.com"
      }]
    }
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-clinical-focus",
    "valueString" : "Presumed general urine tests for barbiturates that are not specific to a particular substance."
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-dataelement-scope",
    "valueString" : "Urine test"
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-inclusion-criteria",
    "valueString" : "Codes"
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-exclusion-criteria",
    "valueString" : "None"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "computable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "executable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-usageWarning",
    "valueString" : "This value set contains a point-in-time expansion enumerating the codes that meet the value set intent. As new versions of the code systems used by the value set are released, the contents of this expansion will need to be updated to incorporate newly defined codes that meet the value set intent. Before, and periodically during production use, the value set expansion contents SHOULD be updated. The value set expansion specifies the timestamp when the expansion was produced, SHOULD contain the parameters used for the expansion, and SHALL contain the codes that are obtained by evaluating the value set definition. If this is ONLY an executable value set, a distributable definition of the value set must be obtained to compute the updated expansion."
  }],
  "url" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/barbiturate-urine-drug-screening-tests",
  "version" : "2022.1.0",
  "name" : "BARBITURATE_URINE_DRUG_SCREENING_TESTS",
  "title" : "Barbiturate urine drug screening tests",
  "status" : "active",
  "experimental" : false,
  "date" : "2024-04-15T12:22:34-06:00",
  "publisher" : "CDC / Security Risk Solutions, Inc. (SRS)",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.securityrisksolutions.com"
    }]
  }],
  "description" : "Presumed general urine tests for barbiturates that are not specific to a particular substance.",
  "purpose" : "Identification of urine drug tests where results can be used when considering pain management therapy",
  "copyright" : "© CDC 2016+.",
  "expansion" : {
    "timestamp" : "2024-04-15T12:22:34-06:00",
    "total" : 86,
    "contains" : [{
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3373-8",
      "display" : "Deprecated Barbiturate Scn Absent Ur"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3372-0",
      "display" : "Barbiturate Scn Absent Ur"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3375-3",
      "display" : "Deprecated Barbiturate Scn Present Ur"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3374-6",
      "display" : "Barbiturate Scn Present Ur"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19274-0",
      "display" : "Barbiturates Pos Ur Cfm"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3371-2",
      "display" : "Barbital Ur-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "20518-7",
      "display" : "Barbital Ur Cfm-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "12360-4",
      "display" : "Barbital Ur Ql"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19354-0",
      "display" : "Barbital Ur Ql Cfm"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19353-2",
      "display" : "Barbital Ur Ql Scn"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19356-5",
      "display" : "Barbital CtO Ur Cfm-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19355-7",
      "display" : "Barbital CtO Ur Scn-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "16430-1",
      "display" : "Barbiturates Ur-aCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "9426-8",
      "display" : "Barbiturates Ur-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "20411-5",
      "display" : "Barbiturates Ur Cfm-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "20664-9",
      "display" : "Barbiturates Ur Scn-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3377-9",
      "display" : "Barbiturates Ur Ql"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "16429-3",
      "display" : "Barbiturates Ur Ql Cfm"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19270-8",
      "display" : "Barbiturates Ur Ql Scn"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "70155-7",
      "display" : "Barbiturates Ur Ql Scn>200 ng/mL"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "70139-1",
      "display" : "Barbiturates Ur Ql Scn>300 ng/mL"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "52956-0",
      "display" : "Barbiturates Ur-sCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19278-1",
      "display" : "Barbiturates Cfm Meth Ur"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19276-5",
      "display" : "Barbiturates CtO Ur Cfm-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19275-7",
      "display" : "Barbiturates CtO Ur Scn-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19277-3",
      "display" : "Barbiturates Scn Meth Ur"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19272-4",
      "display" : "Barbiturates Tested Ur Scn"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19271-6",
      "display" : "Barbiturates Tested Ur Scn"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "41468-0",
      "display" : "Barbiturates/Creat Ur"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19370-6",
      "display" : "Butabarbital Ur-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "16236-2",
      "display" : "Butabarbital Ur Cfm-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3419-9",
      "display" : "Butabarbital Ur Ql"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "16191-9",
      "display" : "Butabarbital Ur Ql Cfm"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19368-0",
      "display" : "Butabarbital Ur Ql Scn"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19372-2",
      "display" : "Butabarbital CtO Ur Cfm-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19371-4",
      "display" : "Butabarbital CtO Ur Scn-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "11071-8",
      "display" : "Butalbital Ur-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "16237-0",
      "display" : "Butalbital Ur Cfm-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3421-5",
      "display" : "Butalbital Ur Ql"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "18385-5",
      "display" : "Butalbital Ur Ql Cfm"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19373-0",
      "display" : "Butalbital Ur Ql Scn"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "32056-4",
      "display" : "Butalbital Ur-sCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19376-3",
      "display" : "Butalbital CtO Ur Cfm-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19375-5",
      "display" : "Butalbital CtO Ur Scn-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "64139-9",
      "display" : "Butalbital/Creat Ur"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "27165-0",
      "display" : "Hexobarbital Ur-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19539-6",
      "display" : "Mephobarbital Ur-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "17250-2",
      "display" : "Mephobarbital Ur Cfm-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "12315-8",
      "display" : "Mephobarbital Ur Ql"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19537-0",
      "display" : "Mephobarbital Ur Ql Cfm"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19536-2",
      "display" : "Mephobarbital Ur Ql Scn"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19541-2",
      "display" : "Mephobarbital CtO Ur Cfm-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19540-4",
      "display" : "Mephobarbital CtO Ur Scn-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3922-2",
      "display" : "Pentetrazol 24h Ur-mRate"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3921-4",
      "display" : "Pentetrazol Ur-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3920-6",
      "display" : "Pentetrazol Ur Ql"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3926-3",
      "display" : "Pentobarb Ur-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "16240-4",
      "display" : "Pentobarb Ur Cfm-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3925-5",
      "display" : "Pentobarb Ur Ql"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "16193-5",
      "display" : "Pentobarb Ur Ql Cfm"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19655-0",
      "display" : "Pentobarb Ur Ql Scn"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19658-4",
      "display" : "Pentobarb CtO Ur Cfm-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19657-6",
      "display" : "Pentobarb CtO Ur Scn-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "64132-4",
      "display" : "Pentobarb/Creat Ur"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3950-3",
      "display" : "Phenobarb Ur-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "16241-2",
      "display" : "Phenobarb Ur Cfm-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3949-5",
      "display" : "Phenobarb Ur Ql"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "16192-7",
      "display" : "Phenobarb Ur Ql Cfm"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19666-7",
      "display" : "Phenobarb Ur Ql Scn"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "39487-4",
      "display" : "Phenobarb Ur-sCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19669-1",
      "display" : "Phenobarb CtO Ur Cfm-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19668-3",
      "display" : "Phenobarb CtO Ur Scn-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "64133-2",
      "display" : "Phenobarb/Creat Ur"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19695-6",
      "display" : "Secobarbital Ur-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "16238-8",
      "display" : "Secobarbital Ur Cfm-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "4029-5",
      "display" : "Secobarbital Ur Ql"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "16194-3",
      "display" : "Secobarbital Ur Ql Cfm"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19692-3",
      "display" : "Secobarbital Ur Ql Scn"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "72928-5",
      "display" : "Secobarbital Ur-sCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19697-2",
      "display" : "Secobarbital CtO Ur Cfm-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19696-4",
      "display" : "Secobarbital CtO Ur Scn-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "12370-3",
      "display" : "Thiopental Ur-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "16223-0",
      "display" : "Thiopental Ur Ql Cfm"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "53735-7",
      "display" : "Barbiturates.other Ur-mCnc"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "53746-4",
      "display" : "Barbiturates Pnl Ur"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "64135-7",
      "display" : "Secobarbital/Creat Ur"
    }]
  }
}

```
