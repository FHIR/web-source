# Opiate specific urine drug screening tests - 2022 CDC Clinical Practice Guideline for Prescribing Opioids Implementation Guide v2022.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Opiate specific urine drug screening tests**

## ValueSet: Opiate specific urine drug screening tests 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.org/guides/cdc/opioid-cds/ValueSet/opiate-specific-urine-drug-screening-tests | *Version*:2022.1.0 |
| Active as of 2023-05-25 | *Computable Name*:OPIATE_SPECIFIC_URINE_DRUG_SCREENING_TESTS |
| **Copyright/Legal**: © CDC 2016+. | |

 
Urine tests for naturally occurring opioids (i.e. opiates) that are specific to a particular naturally occurring opioid and therefore do not have the general word ‘opiates’ in the long name. 

 
Identification of urine drug tests where results can be used when considering pain management therapy 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

No formal definition provided for this value set

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "opiate-specific-urine-drug-screening-tests",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-computablevalueset",
    "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-executablevalueset"]
  },
  "extension" : [{
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-clinical-focus",
    "valueString" : "Presumed general urine tests for naturally occurring opioids (i.e. opiates) that are not specific to a particular substance based upon the inclusion of the word 'opiates' in the long name."
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-dataelement-scope",
    "valueString" : "Urine test"
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-inclusion-criteria",
    "valueString" : "Codes"
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-exclusion-criteria",
    "valueString" : "None"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-author",
    "valueContactDetail" : {
      "name" : "MD Partners, Inc.",
      "telecom" : [{
        "system" : "email",
        "value" : "info@mdpartners.com"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "computable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "executable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-usageWarning",
    "valueString" : "This value set contains a point-in-time expansion enumerating the codes that meet the value set intent. As new versions of the code systems used by the value set are released, the contents of this expansion will need to be updated to incorporate newly defined codes that meet the value set intent. Before, and periodically during production use, the value set expansion contents SHOULD be updated. The value set expansion specifies the timestamp when the expansion was produced, SHOULD contain the parameters used for the expansion, and SHALL contain the codes that are obtained by evaluating the value set definition. If this is ONLY an executable value set, a distributable definition of the value set must be obtained to compute the updated expansion."
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-rules-text",
    "valueMarkdown" : "Step 1. Add all codes found using the following LOINC query: (morphine AND NOT diamorphine AND NOT 6-Monoacetylmorphine) (=system:Urine)"
  }],
  "url" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/opiate-specific-urine-drug-screening-tests",
  "version" : "2022.1.0",
  "name" : "OPIATE_SPECIFIC_URINE_DRUG_SCREENING_TESTS",
  "title" : "Opiate specific urine drug screening tests",
  "status" : "active",
  "experimental" : false,
  "date" : "2023-05-25T18:08:12-06:00",
  "publisher" : "CDC / Security Risk Solutions, Inc. (SRS)",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.securityrisksolutions.com"
    }]
  }],
  "description" : "Urine tests for naturally occurring opioids (i.e. opiates) that are specific to a particular naturally occurring opioid and therefore do not have the general word 'opiates' in the long name.",
  "purpose" : "Identification of urine drug tests where results can be used when considering pain management therapy",
  "copyright" : "© CDC 2016+.",
  "expansion" : {
    "timestamp" : "2023-05-25T18:08:12-06:00",
    "total" : 33,
    "contains" : [{
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "89308-1",
      "display" : "Morphine-6-Glucuronide [Presence] in Urine by Screen method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "51739-1",
      "display" : "Codeine Free [Mass/volume] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "89310-7",
      "display" : "Codeine-6-glucuronide [Presence] in Urine by Screen method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3508-9",
      "display" : "Codeine [Mass/volume] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "16250-3",
      "display" : "Codeine [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3507-1",
      "display" : "Codeine [Presence] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "16197-6",
      "display" : "Codeine [Presence] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "13641-6",
      "display" : "Codeine [Presence] in Urine by SAMHSA confirm method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19411-8",
      "display" : "Codeine [Presence] in Urine by Screen method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "70206-8",
      "display" : "Codeine [Moles/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19414-2",
      "display" : "Codeine cutoff [Mass/volume] in Urine for Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19413-4",
      "display" : "Codeine cutoff [Mass/volume] in Urine for Screen method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "58391-4",
      "display" : "Codeine/Creatinine [Mass Ratio] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3829-9",
      "display" : "Morphine Free [Mass/volume] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "20550-0",
      "display" : "Morphine Free [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3828-1",
      "display" : "Morphine Free [Presence] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19602-2",
      "display" : "Morphine Free [Presence] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19601-4",
      "display" : "Morphine Free [Presence] in Urine by Screen method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19604-8",
      "display" : "Morphine Free cutoff [Mass/volume] in Urine for Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19603-0",
      "display" : "Morphine Free cutoff [Mass/volume] in Urine for Screen method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3832-3",
      "display" : "Morphine [Mass/time] in 24 hour Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3831-5",
      "display" : "Morphine [Mass/volume] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "16251-1",
      "display" : "Morphine [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3830-7",
      "display" : "Morphine [Presence] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "16196-8",
      "display" : "Morphine [Presence] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "13648-1",
      "display" : "Morphine [Presence] in Urine by SAMHSA confirm method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19597-4",
      "display" : "Morphine [Presence] in Urine by Screen method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "70210-0",
      "display" : "Morphine [Moles/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "78861-2",
      "display" : "Morphine [Z-score] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19600-6",
      "display" : "Morphine cutoff [Mass/volume] in Urine for Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "19599-0",
      "display" : "Morphine cutoff [Mass/volume] in Urine for Screen method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "58392-2",
      "display" : "Morphine/Creatinine [Mass Ratio] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "78768-9",
      "display" : "Morphine [Mass/volume] in Urine -- adjusted for lean body mass+urine creatinine"
    }]
  }
}

```
