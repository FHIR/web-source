# Synthetic opioid urine drug screening tests - 2022 CDC Clinical Practice Guideline for Prescribing Opioids Implementation Guide v2022.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Synthetic opioid urine drug screening tests**

## ValueSet: Synthetic opioid urine drug screening tests 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.org/guides/cdc/opioid-cds/ValueSet/synthetic-opioid-urine-drug-screening-tests | *Version*:2022.1.0 |
| Active as of 2023-05-25 | *Computable Name*:SYNTHETIC_OPIOID_URINE_DRUG_SCREENING_TESTS |
| **Copyright/Legal**: © CDC 2016+. | |

 
Urine tests for synthetic and semi-synthetic (non-opiate) substances 

 
Identification of urine drug tests where results can be used when considering pain management therapy 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

No formal definition provided for this value set

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "synthetic-opioid-urine-drug-screening-tests",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-computablevalueset",
    "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-executablevalueset"]
  },
  "extension" : [{
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-clinical-focus",
    "valueString" : "Urine tests for synthetic and semi-synthetic (non-opiate) substances"
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-dataelement-scope",
    "valueString" : "Urine test"
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-inclusion-criteria",
    "valueString" : "Urine tests for synthetic and semi-synthetic (non-opiate) substances"
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-exclusion-criteria",
    "valueString" : "Codes listed in the General opiate urine drug screening tests value set and the Opiate specific urine drug screening tests value set"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-author",
    "valueContactDetail" : {
      "name" : "MD Partners, Inc.",
      "telecom" : [{
        "system" : "email",
        "value" : "info@mdpartners.com"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "computable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "executable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-usageWarning",
    "valueString" : "This value set contains a point-in-time expansion enumerating the codes that meet the value set intent. As new versions of the code systems used by the value set are released, the contents of this expansion will need to be updated to incorporate newly defined codes that meet the value set intent. Before, and periodically during production use, the value set expansion contents SHOULD be updated. The value set expansion specifies the timestamp when the expansion was produced, SHOULD contain the parameters used for the expansion, and SHALL contain the codes that are obtained by evaluating the value set definition. If this is ONLY an executable value set, a distributable definition of the value set must be obtained to compute the updated expansion."
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-rules-text",
    "valueMarkdown" : "Step 1. Add all codes found using the following LOINC query: (opiate OR opioid AND NOT morphine AND NOT diamorphine AND NOT 6-Monoacetylmorphine AND NOT opiates) (=system:Urine)"
  }],
  "url" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/synthetic-opioid-urine-drug-screening-tests",
  "version" : "2022.1.0",
  "name" : "SYNTHETIC_OPIOID_URINE_DRUG_SCREENING_TESTS",
  "title" : "Synthetic opioid urine drug screening tests",
  "status" : "active",
  "experimental" : false,
  "date" : "2023-05-25T18:08:12-06:00",
  "publisher" : "CDC / Security Risk Solutions, Inc. (SRS)",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.securityrisksolutions.com"
    }]
  }],
  "description" : "Urine tests for synthetic and semi-synthetic (non-opiate) substances",
  "purpose" : "Identification of urine drug tests where results can be used when considering pain management therapy",
  "copyright" : "© CDC 2016+.",
  "expansion" : {
    "timestamp" : "2023-05-25T18:08:12-06:00",
    "total" : 28,
    "contains" : [{
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "93471-1",
      "display" : "Acetyl norfentanyl [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "93473-7",
      "display" : "Beta hydroxythiofentanyl [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "93465-3",
      "display" : "3-Methylfentanyl [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "93469-5",
      "display" : "4-Fluorobutyrylfentanyl [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "93464-6",
      "display" : "p-Fluorofentanyl [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "101162-6",
      "display" : "p-Fluorofentanyl [Presence] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "101161-8",
      "display" : "p-Fluorofentanyl/Creatinine [Mass Ratio] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "93461-2",
      "display" : "4-Methoxybutyrylfentanyl [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "93468-7",
      "display" : "Acrylfentanyl [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "99079-6",
      "display" : "Acrylfentanyl [Presence] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "93467-9",
      "display" : "Butyrylfentanyl [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "93470-3",
      "display" : "Furanylfentanyl [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "99081-2",
      "display" : "Furanylfentanyl [Presence] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "93466-1",
      "display" : "Valerylfentanyl [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "93472-9",
      "display" : "4-Methylphenethylacetylfentanyl [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "93462-0",
      "display" : "Norcarfentanil [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "93463-8",
      "display" : "Ocfentanil [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "93455-4",
      "display" : "IC-26 [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "93456-2",
      "display" : "MT-45 [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "93459-6",
      "display" : "U-47700 [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "93460-4",
      "display" : "AH-7921 [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "93457-0",
      "display" : "AH-8529 [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "93458-8",
      "display" : "AH-8533 [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "93451-3",
      "display" : "Nor-W-18+Nor-W-15 [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "93453-9",
      "display" : "W-15 [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "93454-7",
      "display" : "W-18 [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "93452-1",
      "display" : "W-19 [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "93474-5",
      "display" : "Synthetic opioids panel - Urine by Confirmatory method"
    }]
  }
}

```
