# CNS depressant medications - 2022 CDC Clinical Practice Guideline for Prescribing Opioids Implementation Guide v2022.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CNS depressant medications**

## ValueSet: CNS depressant medications 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.org/guides/cdc/opioid-cds/ValueSet/cns-depressant-medications | *Version*:2022.1.0 |
| Active as of 2025-02-24 | *Computable Name*:CNS_DEPRESSANT_MEDICATIONS |
| **Copyright/Legal**: © CDC 2016+. | |

 
Medications considered to have an ingredient considered to be a CNS depressant, some of which may be mild. Removed from this set are cough medications and bowl transit modifiers. 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

No formal definition provided for this value set

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "cns-depressant-medications",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-computablevalueset",
    "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-executablevalueset"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-author",
    "valueContactDetail" : {
      "name" : "MD Partners, Inc.",
      "telecom" : [{
        "system" : "email",
        "value" : "info@mdpartners.com"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "computable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "executable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-usageWarning",
    "valueString" : "This value set contains a point-in-time expansion enumerating the codes that meet the value set intent. As new versions of the code systems used by the value set are released, the contents of this expansion will need to be updated to incorporate newly defined codes that meet the value set intent. Before, and periodically during production use, the value set expansion contents SHOULD be updated. The value set expansion specifies the timestamp when the expansion was produced, SHOULD contain the parameters used for the expansion, and SHALL contain the codes that are obtained by evaluating the value set definition. If this is ONLY an executable value set, a distributable definition of the value set must be obtained to compute the updated expansion."
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-rules-text",
    "valueMarkdown" : "https://mor.nlm.nih.gov/RxMix/ Script:\r\nStep 1a \r\nCreate Batch text input file (CNSD.txt) with following DailyMed identifier (for the concept \"Central Nervous System Depressants\") as an input within the file: \r\nN0000175728       \r\n\r\nStep 1b\r\nSubmit batch job using the above CNSD.txt file to following workflow by uploading file (CNSD-wf.config) with the following in the file:  <WFE><filteredOutputs>RXCUI|name|term_type</filteredOutputs><input>NOINPUT</input><FS><service>NOINPUT</service><function>getClassMembers</function><level>0</level><paramSize>5</paramSize><param order ='0'>?</param><param order ='1'>DAILYMED</param><param order ='2'>N/A</param><param order ='3'>0</param><param order ='4'>IN,MIN,PIN</param></FS><FS><service>NOINPUT</service><function>getRelatedByType</function><level>1</level><paramSize>2</paramSize><param order ='0'>?</param><param order ='1'>BPCK,GPCK,SBD,SCD</param></FS></WFE>\r\nStep 2\r\nTo remove all cough and bowel transit formulation codes and to remove the injectable codes filter out all codes with the following strings:\r\nIngredient strings: \r\nGuaifenesin, Chlorpheniramine, Pseudoephedrine, Brompheniramine, Phenylephrine, Phenylpropanolamine, Promethazine, Bromodiphenhydramine, guaiacolsulfonate, homatropine\r\nForm strings:\r\ninject, cartridge, syringe"
  }],
  "url" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/cns-depressant-medications",
  "version" : "2022.1.0",
  "name" : "CNS_DEPRESSANT_MEDICATIONS",
  "title" : "CNS depressant medications",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-02-24T13:06:43-07:00",
  "publisher" : "CDC / Security Risk Solutions, Inc. (SRS)",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.securityrisksolutions.com"
    }]
  }],
  "description" : "Medications considered to have an ingredient considered to be a CNS depressant, some of which may be mild. Removed from this set are cough medications and bowl transit modifiers.",
  "copyright" : "© CDC 2016+.",
  "expansion" : {
    "timestamp" : "2025-02-24T13:06:43-07:00",
    "total" : 116,
    "contains" : [{
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "904368",
      "display" : "benzphetamine hydrochloride 50 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "904372",
      "display" : "benzphetamine hydrochloride 25 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2698136",
      "display" : "{7 (sodium oxybate 4500 MG Granules for Oral Suspension [Lumryz]) / 14 (sodium oxybate 6000 MG Granules for Oral Suspension [Lumryz]) / 7 (sodium oxybate 7500 MG Granules for Oral Suspension [Lumryz]) } Pack [Lumryz 28-Day Starter Pack]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2698135",
      "display" : "{7 (sodium oxybate 4500 MG Granules for Oral Suspension) / 14 (sodium oxybate 6000 MG Granules for Oral Suspension) / 7 (sodium oxybate 7500 MG Granules for Oral Suspension) } Pack"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2393794",
      "display" : "calcium oxybate 234 MG/ML / magnesium oxybate 96 MG/ML / potassium oxybate 130 MG/ML / sodium oxybate 40 MG/ML Oral Solution [Xywav]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2636828",
      "display" : "sodium oxybate 4500 MG Granules for Oral Suspension [Lumryz]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2636832",
      "display" : "sodium oxybate 6000 MG Granules for Oral Suspension [Lumryz]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2636836",
      "display" : "sodium oxybate 7500 MG Granules for Oral Suspension [Lumryz]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2636840",
      "display" : "sodium oxybate 9000 MG Granules for Oral Suspension [Lumryz]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "352257",
      "display" : "sodium oxybate 500 MG/ML Oral Solution [Xyrem]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2393795",
      "display" : "calcium oxybate 234 MG/ML / magnesium oxybate 96 MG/ML / potassium oxybate 130 MG/ML / sodium oxybate 40 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2636822",
      "display" : "sodium oxybate 4500 MG Granules for Oral Suspension"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2636830",
      "display" : "sodium oxybate 6000 MG Granules for Oral Suspension"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2636834",
      "display" : "sodium oxybate 7500 MG Granules for Oral Suspension"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2636838",
      "display" : "sodium oxybate 9000 MG Granules for Oral Suspension"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "349482",
      "display" : "sodium oxybate 500 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "208919",
      "display" : "desflurane 1000 MG/ML Inhalation Solution [Suprane]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "562366",
      "display" : "desflurane 1000 MG/ML Inhalation Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "994071",
      "display" : "24 HR phendimetrazine tartrate 105 MG Extended Release Oral Capsule [Melfiat]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "979543",
      "display" : "24 HR phendimetrazine tartrate 105 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "979549",
      "display" : "phendimetrazine tartrate 35 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "978662",
      "display" : "diethylpropion hydrochloride 25 MG Oral Tablet [Tenuate]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "978686",
      "display" : "24 HR diethylpropion hydrochloride 75 MG Extended Release Oral Tablet [Tenuate]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "978654",
      "display" : "diethylpropion hydrochloride 25 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "978668",
      "display" : "24 HR diethylpropion hydrochloride 75 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1245044",
      "display" : "sevoflurane 1000 MG/ML Inhalation Solution [SevoFlo]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2697457",
      "display" : "sevoflurane 1000 MG/ML Inhalation Solution [Sevospire]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "541963",
      "display" : "sevoflurane 1000 MG/ML Inhalation Solution [Ultane]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "997618",
      "display" : "sevoflurane 1000 MG/ML Inhalation Solution [Petrem]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "997625",
      "display" : "sevoflurane 1000 MG/ML Inhalation Solution [Sojourn]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "200243",
      "display" : "sevoflurane 1000 MG/ML Inhalation Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "313489",
      "display" : "trimethobenzamide 100 MG Rectal Suppository"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "313492",
      "display" : "trimethobenzamide 200 MG Rectal Suppository"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "860745",
      "display" : "benzocaine 0.02 MG/MG / trimethobenzamide hydrochloride 200 MG Rectal Suppository"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "860752",
      "display" : "trimethobenzamide hydrochloride 100 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "860767",
      "display" : "trimethobenzamide hydrochloride 250 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "860771",
      "display" : "trimethobenzamide hydrochloride 300 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "828696",
      "display" : "zolpidem tartrate 5 MG/ACTUAT Oral Spray [Zolpimist]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "836645",
      "display" : "zolpidem tartrate 10 MG Sublingual Tablet [Edluar]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "836649",
      "display" : "zolpidem tartrate 5 MG Sublingual Tablet [Edluar]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "854875",
      "display" : "zolpidem tartrate 10 MG Oral Tablet [Ambien]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "854878",
      "display" : "zolpidem tartrate 5 MG Oral Tablet [Ambien]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "854882",
      "display" : "zolpidem tartrate 12.5 MG Extended Release Oral Tablet [Ambien]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "854896",
      "display" : "zolpidem tartrate 6.25 MG Extended Release Oral Tablet [Ambien]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1232194",
      "display" : "zolpidem tartrate 1.75 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1232202",
      "display" : "zolpidem tartrate 3.5 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2637353",
      "display" : "zolpidem tartrate 7.5 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "828692",
      "display" : "zolpidem tartrate 5 MG/ACTUAT Oral Spray"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "836641",
      "display" : "zolpidem tartrate 10 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "836647",
      "display" : "zolpidem tartrate 5 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "854873",
      "display" : "zolpidem tartrate 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "854876",
      "display" : "zolpidem tartrate 5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "854880",
      "display" : "zolpidem tartrate 12.5 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "854885",
      "display" : "zolpidem tartrate 5 MG Disintegrating Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "854886",
      "display" : "zolpidem tartrate 10 MG Disintegrating Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "854894",
      "display" : "zolpidem tartrate 6.25 MG Extended Release Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1732674",
      "display" : "dexmedetomidine 0.00009 MG/MG Oral Gel [Sileo]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2601126",
      "display" : "dexmedetomidine 0.12 MG Sublingual Film [Igalmi]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2601131",
      "display" : "dexmedetomidine 0.18 MG Sublingual Film [Igalmi]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1732668",
      "display" : "dexmedetomidine 0.00009 MG/MG Oral Gel"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2601119",
      "display" : "dexmedetomidine 0.12 MG Sublingual Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2601129",
      "display" : "dexmedetomidine 0.18 MG Sublingual Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1540984",
      "display" : "isoflurane 999 MG/ML Inhalation Solution [Fluriso]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1549863",
      "display" : "isoflurane 999 MG/ML Inhalation Solution [IsoSol]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2628931",
      "display" : "isoflurane 999 MG/ML Inhalation Solution [Isospire]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "542355",
      "display" : "isoflurane 999 MG/ML Inhalation Solution [Terrell]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "542358",
      "display" : "isoflurane 999 MG/ML Inhalation Solution [Forane]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "542347",
      "display" : "isoflurane 999 MG/ML Inhalation Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1251685",
      "display" : "meclizine hydrochloride 25 MG Oral Tablet [Verticalm]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1673797",
      "display" : "meclizine hydrochloride 25 MG Oral Tablet [Wal-Dram 2]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1800794",
      "display" : "meclizine hydrochloride 25 MG Disintegrating Oral Tablet [Wal-Dram 2]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2110527",
      "display" : "meclizine hydrochloride 25 MG Oral Tablet [Dramamine Nausea Relief]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2176732",
      "display" : "meclizine hydrochloride 25 MG Chewable Tablet [Dramamine Less Drowsy]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2273509",
      "display" : "meclizine hydrochloride 25 MG Chewable Tablet [Antivert]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2540687",
      "display" : "meclizine hydrochloride 25 MG Disintegrating Oral Tablet [Zentrip]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "995626",
      "display" : "meclizine hydrochloride 12.5 MG Oral Tablet [Antivert]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "995634",
      "display" : "meclizine hydrochloride 25 MG Chewable Tablet [Bonine]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "995668",
      "display" : "meclizine hydrochloride 25 MG Oral Tablet [Antivert]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "995688",
      "display" : "meclizine hydrochloride 50 MG Oral Tablet [Antivert]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "995726",
      "display" : "meclizine hydrochloride 25 MG Oral Tablet [Dramamine Less Drowsy]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1663815",
      "display" : "meclizine hydrochloride 25 MG Disintegrating Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2632643",
      "display" : "meclizine hydrochloride 50 MG Chewable Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "995624",
      "display" : "meclizine hydrochloride 12.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "995632",
      "display" : "meclizine hydrochloride 25 MG Chewable Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "995666",
      "display" : "meclizine hydrochloride 25 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "995682",
      "display" : "meclizine hydrochloride 30 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "995686",
      "display" : "meclizine hydrochloride 50 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "995753",
      "display" : "meclizine hydrochloride 12.5 MG Oral Lozenge"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "977861",
      "display" : "methamphetamine hydrochloride 5 MG Oral Tablet [Desoxyn]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "977860",
      "display" : "methamphetamine hydrochloride 5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "313761",
      "display" : "zaleplon 10 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "313762",
      "display" : "zaleplon 5 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1302833",
      "display" : "24 HR phentermine 7.5 MG / topiramate 46 MG Extended Release Oral Capsule [Qsymia]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1302845",
      "display" : "24 HR phentermine 3.75 MG / topiramate 23 MG Extended Release Oral Capsule [Qsymia]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1302856",
      "display" : "24 HR phentermine 15 MG / topiramate 92 MG Extended Release Oral Capsule [Qsymia]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1313061",
      "display" : "24 HR phentermine 11.25 MG / topiramate 69 MG Extended Release Oral Capsule [Qsymia]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1810304",
      "display" : "phentermine hydrochloride 8 MG Oral Tablet [Lomaira]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "803350",
      "display" : "phentermine hydrochloride 37.5 MG Oral Capsule [Adipex-P]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "803354",
      "display" : "phentermine hydrochloride 37.5 MG Oral Tablet [Adipex-P]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1112982",
      "display" : "phentermine hydrochloride 15 MG Disintegrating Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1112987",
      "display" : "phentermine hydrochloride 30 MG Disintegrating Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1249083",
      "display" : "phentermine hydrochloride 37.5 MG Disintegrating Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1302827",
      "display" : "24 HR phentermine 7.5 MG / topiramate 46 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1302839",
      "display" : "24 HR phentermine 3.75 MG / topiramate 23 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1302850",
      "display" : "24 HR phentermine 15 MG / topiramate 92 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1313059",
      "display" : "24 HR phentermine 11.25 MG / topiramate 69 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "803348",
      "display" : "phentermine hydrochloride 37.5 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "803353",
      "display" : "phentermine hydrochloride 37.5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "826131",
      "display" : "phentermine hydrochloride 18.8 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "826586",
      "display" : "phentermine resin 15 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "826600",
      "display" : "phentermine resin 15 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "826832",
      "display" : "phentermine resin 30 MG Extended Release Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "826910",
      "display" : "phentermine resin 30 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "826919",
      "display" : "phentermine hydrochloride 8 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "900038",
      "display" : "phentermine hydrochloride 30 MG Oral Capsule"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "968766",
      "display" : "phentermine hydrochloride 15 MG Oral Capsule"
    }]
  }
}

```
