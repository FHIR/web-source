# Buprenorphine and Methadone medications - 2022 CDC Clinical Practice Guideline for Prescribing Opioids Implementation Guide v2022.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Buprenorphine and Methadone medications**

## ValueSet: Buprenorphine and Methadone medications 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.org/guides/cdc/opioid-cds/ValueSet/buprenorphine-and-methadone-medications | *Version*:2022.1.0 |
| Active as of 2023-05-25 | *Computable Name*:BUPRENORPHINE_AND_METHADONE_MEDICATIONS |
| **Copyright/Legal**: © CDC 2016+. | |

 
All Buprenorphine and Methadone medications 

 
Buprenorphine and Methadone medications for opioid management 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

No formal definition provided for this value set

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "buprenorphine-and-methadone-medications",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-computablevalueset",
    "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-executablevalueset"]
  },
  "extension" : [{
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-clinical-focus",
    "valueString" : "Buprenorphine and Methadone medications"
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-dataelement-scope",
    "valueString" : "Medication"
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-inclusion-criteria",
    "valueString" : "All Buprenorphine and Methadone medications"
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-exclusion-criteria",
    "valueString" : "None"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-author",
    "valueContactDetail" : {
      "name" : "MD Partners, Inc.",
      "telecom" : [{
        "system" : "email",
        "value" : "info@mdpartners.com"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "computable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "executable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeRepresentationLevel",
    "valueCode" : "structured"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeRepresentationLevel",
    "valueCode" : "executable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-usageWarning",
    "valueString" : "This value set contains a point-in-time expansion enumerating the codes that meet the value set intent. As new versions of the code systems used by the value set are released, the contents of this expansion will need to be updated to incorporate newly defined codes that meet the value set intent. Before, and periodically during production use, the value set expansion contents SHOULD be updated. The value set expansion specifies the timestamp when the expansion was produced, SHOULD contain the parameters used for the expansion, and SHALL contain the codes that are obtained by evaluating the value set definition. If this is ONLY an executable value set, a distributable definition of the value set must be obtained to compute the updated expansion."
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-rules-text",
    "valueMarkdown" : "https://mor.nlm.nih.gov/RxMix/ Script: \r\nStep 1 Upload to RxMix a workflow config file  named GetRelatedByType.config containing the following workflow text: <WFE><filteredOutputs>RXCUI|name|term_type</filteredOutputs><input>NOINPUT</input><FS><service>NOINPUT</service><function>getRelatedByType</function><level>0</level><paramSize>2</paramSize><param order ='0'>?</param><param order ='1'>BPCK,GPCK,SBD,SCD</param></FS></WFE> \r\n\r\nStep 2 Create Batch text input file (Ingredients.txt) with following RxNorm Buprenorphine and Methadone as an input within the file:\r\n1819\r\n6813\r\n\r\nStep 3 Upload the batch text input file Ingredients.txt created in step 2. \r\n\r\nStep 4 Submit the batch which will run the workflow using the input codes to generate a combined set of all the concepts needed..\r\n"
  }],
  "url" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/buprenorphine-and-methadone-medications",
  "version" : "2022.1.0",
  "name" : "BUPRENORPHINE_AND_METHADONE_MEDICATIONS",
  "title" : "Buprenorphine and Methadone medications",
  "status" : "active",
  "experimental" : false,
  "date" : "2023-05-25T18:08:12-06:00",
  "publisher" : "CDC / Security Risk Solutions, Inc. (SRS)",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.securityrisksolutions.com"
    }]
  }],
  "description" : "All Buprenorphine and Methadone medications",
  "purpose" : "Buprenorphine and Methadone medications for opioid management",
  "copyright" : "© CDC 2016+.",
  "expansion" : {
    "timestamp" : "2023-05-25T18:08:12-06:00",
    "total" : 85,
    "parameter" : [{
      "name" : "version",
      "valueString" : "2023-03"
    }],
    "contains" : [{
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1996189",
      "display" : "0.5 ML buprenorphine 200 MG/ML Prefilled Syringe [Sublocade]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "205533",
      "display" : "1 ML buprenorphine 0.3 MG/ML Injection [Buprenex]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1996193",
      "display" : "1.5 ML buprenorphine 200 MG/ML Prefilled Syringe [Sublocade]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "904882",
      "display" : "168 HR buprenorphine 0.005 MG/HR Transdermal System [BuTrans]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1542999",
      "display" : "168 HR buprenorphine 0.0075 MG/HR Transdermal System [BuTrans]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "904874",
      "display" : "168 HR buprenorphine 0.01 MG/HR Transdermal System [BuTrans]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1432971",
      "display" : "168 HR buprenorphine 0.015 MG/HR Transdermal System [BuTrans]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "904878",
      "display" : "168 HR buprenorphine 0.02 MG/HR Transdermal System [BuTrans]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1716079",
      "display" : "buprenorphine 0.075 MG Buccal Film [Belbuca]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1716063",
      "display" : "buprenorphine 0.15 MG Buccal Film [Belbuca]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1716067",
      "display" : "buprenorphine 0.3 MG Buccal Film [Belbuca]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1716071",
      "display" : "buprenorphine 0.45 MG Buccal Film [Belbuca]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1716075",
      "display" : "buprenorphine 0.6 MG Buccal Film [Belbuca]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1864414",
      "display" : "buprenorphine 0.7 MG / naloxone 0.18 MG Sublingual Tablet [Zubsolv]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1716083",
      "display" : "buprenorphine 0.75 MG Buccal Film [Belbuca]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1716090",
      "display" : "buprenorphine 0.9 MG Buccal Film [Belbuca]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1431083",
      "display" : "buprenorphine 1.4 MG / naloxone 0.36 MG Sublingual Tablet [Zubsolv]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1594655",
      "display" : "buprenorphine 1.8 MG/ML Injectable Solution [Simbadol]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1597570",
      "display" : "buprenorphine 11.4 MG / naloxone 2.9 MG Sublingual Tablet [Zubsolv]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1307063",
      "display" : "buprenorphine 12 MG / naloxone 3 MG Sublingual Film [Suboxone]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1010603",
      "display" : "buprenorphine 2 MG / naloxone 0.5 MG Sublingual Film [Suboxone]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1542396",
      "display" : "buprenorphine 2.1 MG / naloxone 0.3 MG Buccal Film [Bunavail]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1666385",
      "display" : "buprenorphine 2.9 MG / naloxone 0.71 MG Sublingual Tablet [Zubsolv]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "2599851",
      "display" : "buprenorphine 20 MG/ML Topical Solution [Zorbium]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1307058",
      "display" : "buprenorphine 4 MG / naloxone 1 MG Sublingual Film [Suboxone]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1544853",
      "display" : "buprenorphine 4.2 MG / naloxone 0.7 MG Buccal Film [Bunavail]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1431104",
      "display" : "buprenorphine 5.7 MG / naloxone 1.4 MG Sublingual Tablet [Zubsolv]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1544856",
      "display" : "buprenorphine 6.3 MG / naloxone 1 MG Buccal Film [Bunavail]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1797655",
      "display" : "buprenorphine 74.2 MG Drug Implant [Probuphine]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1010606",
      "display" : "buprenorphine 8 MG / naloxone 2 MG Sublingual Film [Suboxone]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1597575",
      "display" : "buprenorphine 8.6 MG / naloxone 2.1 MG Sublingual Tablet [Zubsolv]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1996184",
      "display" : "0.5 ML buprenorphine 200 MG/ML Prefilled Syringe"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1655032",
      "display" : "1 ML buprenorphine 0.3 MG/ML Cartridge"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "238129",
      "display" : "1 ML buprenorphine 0.3 MG/ML Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1996192",
      "display" : "1.5 ML buprenorphine 200 MG/ML Prefilled Syringe"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "904880",
      "display" : "168 HR buprenorphine 0.005 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1542997",
      "display" : "168 HR buprenorphine 0.0075 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "904870",
      "display" : "168 HR buprenorphine 0.01 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1432969",
      "display" : "168 HR buprenorphine 0.015 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "904876",
      "display" : "168 HR buprenorphine 0.02 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1716077",
      "display" : "buprenorphine 0.075 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1716057",
      "display" : "buprenorphine 0.15 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "246474",
      "display" : "buprenorphine 0.2 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1716065",
      "display" : "buprenorphine 0.3 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "250426",
      "display" : "buprenorphine 0.4 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1716069",
      "display" : "buprenorphine 0.45 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1716073",
      "display" : "buprenorphine 0.6 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1864412",
      "display" : "buprenorphine 0.7 MG / naloxone 0.18 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1716081",
      "display" : "buprenorphine 0.75 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1716086",
      "display" : "buprenorphine 0.9 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1431076",
      "display" : "buprenorphine 1.4 MG / naloxone 0.36 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1594650",
      "display" : "buprenorphine 1.8 MG/ML Injectable Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1597568",
      "display" : "buprenorphine 11.4 MG / naloxone 2.9 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1307061",
      "display" : "buprenorphine 12 MG / naloxone 3 MG Sublingual Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1010600",
      "display" : "buprenorphine 2 MG / naloxone 0.5 MG Sublingual Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "351266",
      "display" : "buprenorphine 2 MG / naloxone 0.5 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "351264",
      "display" : "buprenorphine 2 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1542390",
      "display" : "buprenorphine 2.1 MG / naloxone 0.3 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1666338",
      "display" : "buprenorphine 2.9 MG / naloxone 0.71 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "2599846",
      "display" : "buprenorphine 20 MG/ML Topical Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1307056",
      "display" : "buprenorphine 4 MG / naloxone 1 MG Sublingual Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1544851",
      "display" : "buprenorphine 4.2 MG / naloxone 0.7 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1431102",
      "display" : "buprenorphine 5.7 MG / naloxone 1.4 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1544854",
      "display" : "buprenorphine 6.3 MG / naloxone 1 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1797650",
      "display" : "buprenorphine 74.2 MG Drug Implant"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1010604",
      "display" : "buprenorphine 8 MG / naloxone 2 MG Sublingual Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "351267",
      "display" : "buprenorphine 8 MG / naloxone 2 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "351265",
      "display" : "buprenorphine 8 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1597573",
      "display" : "buprenorphine 8.6 MG / naloxone 2.1 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "864708",
      "display" : "methadone hydrochloride 10 MG Oral Tablet [Dolophine]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "864712",
      "display" : "methadone hydrochloride 10 MG Oral Tablet [Methadose]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "991149",
      "display" : "methadone hydrochloride 10 MG/ML Oral Solution [Methadose]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "1990745",
      "display" : "methadone hydrochloride 40 MG Tablet for Oral Suspension [Diskets]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "864980",
      "display" : "methadone hydrochloride 40 MG Tablet for Oral Suspension [Methadose]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "864720",
      "display" : "methadone hydrochloride 5 MG Oral Tablet [Dolophine]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "864737",
      "display" : "methadone hydrochloride 5 MG Oral Tablet [Methadose]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "864761",
      "display" : "methadone hydrochloride 1 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "864706",
      "display" : "methadone hydrochloride 10 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "864714",
      "display" : "methadone hydrochloride 10 MG/ML Injectable Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "991147",
      "display" : "methadone hydrochloride 10 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "864769",
      "display" : "methadone hydrochloride 2 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "864984",
      "display" : "methadone hydrochloride 20 MG/ML Oral Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "864978",
      "display" : "methadone hydrochloride 40 MG Tablet for Oral Suspension"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "864718",
      "display" : "methadone hydrochloride 5 MG Oral Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "version" : "2023-03",
      "code" : "864826",
      "display" : "methadone hydrochloride 5 MG/ML Oral Solution"
    }]
  }
}

```
