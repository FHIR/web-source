# Recommendations #4 and #5 - Lowest Effective Dose - 2022 CDC Clinical Practice Guideline for Prescribing Opioids Implementation Guide v2022.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Recommendations #4 and #5 - Lowest Effective Dose**

## PlanDefinition: Recommendations #4 and #5 - Lowest Effective Dose 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.org/guides/cdc/opioid-cds/PlanDefinition/opioidcds-04-05 | *Version*:2022.1.0 |
| Active as of 2025-08-06 | *Computable Name*:PlanDefinition_Recommendation_04_05_Order_Sign |
| *Other Identifiers:*cdc-opioid-guidance (use: official, ) | |
| **Usage:**Clinical Focus: Medication requested (situation), Clinical Focus: Chronic pain (finding), Clinical Focus: Acute pain (finding), Clinical Focus:  | |
| **Copyright/Legal**: © CDC 2016+. | |

 
Recommendation 4: When opioids are initiated for opioid-naïve patients with acute, subacute, or chronic pain, clinicians should prescribe the lowest effective dosage. If opioids are continued for subacute or chronic pain, clinicians should use caution when prescribing opioids at any dosage, should carefully evaluate individual benefits and risks when considering increasing dosage, and should avoid increasing dosage above levels likely to yield diminishing returns in benefits relative to risks to patients. Recommendation 5: For patients already receiving opioid therapy, clinicians should carefully weigh benefits and risks and exercise care when changing opioid dosage. If benefits outweigh risks of continued opioid therapy, clinicians should work closely with patients to optimize nonopioid therapies while continuing opioid therapy. If benefits do not outweigh risks of continued opioid therapy, clinicians should optimize other therapies and work closely with patients to gradually taper to lower dosages or, if warranted based on the individual circumstances of the patient, appropriately taper and discontinue opioids. Unless there are indications of a life-threatening issue such as warning signs of impending overdose (e.g., confusion, sedation, or slurred speech), opioid therapy should not be discontinued abruptly, and clinicians should not rapidly reduce opioid dosages from higher dosages. 

 
The 2022 CDC Clinical Practice Guideline for Prescribing Opioids for Pain is intended to improve communication between clinicians and patients about the benefits and risks of pain treatments, including opioid therapy; improve the effectiveness and safety of pain treatment; mitigate pain; improve function and quality of life for patients with pain; and reduce risks associated with opioid pain therapy, including opioid use disorder, overdose, and death. The recommendations do not apply to pain related to sickle cell disease or cancer or to patients receiving palliative or end-of-life care. 

* **Actions: **: **Url: **
  * : [Recommendations #4 and #5 - Lowest Effective Dose](PlanDefinition-opioidcds-04-05.md)
* **Actions: **: **Version: **
  * : 2022.1.0
* **Actions: **: **Name: **
  * : PlanDefinition_Recommendation_04_05_Order_Sign
* **Actions: **: **Title: **
  * : Recommendations #4 and #5 - Lowest Effective Dose
* **Actions: **: **Status: **
  * : active
* **Actions: **: **Experimental: **
  * : false
* **Actions: **: **Date: **
  * : 2025-08-06
* **Actions: **: **Publisher: **
  * : CDC / Security Risk Solutions, Inc. (SRS)
* **Actions: **: **Description: **
  * : Recommendation 4: When opioids are initiated for opioid-naïve patients with acute, subacute, or chronic pain, clinicians should prescribe the lowest effective dosage. If opioids are continued for subacute or chronic pain, clinicians should use caution when prescribing opioids at any dosage, should carefully evaluate individual benefits and risks when considering increasing dosage, and should avoid increasing dosage above levels likely to yield diminishing returns in benefits relative to risks to patients. Recommendation 5: For patients already receiving opioid therapy, clinicians should carefully weigh benefits and risks and exercise care when changing opioid dosage. If benefits outweigh risks of continued opioid therapy, clinicians should work closely with patients to optimize nonopioid therapies while continuing opioid therapy. If benefits do not outweigh risks of continued opioid therapy, clinicians should optimize other therapies and work closely with patients to gradually taper to lower dosages or, if warranted based on the individual circumstances of the patient, appropriately taper and discontinue opioids. Unless there are indications of a life-threatening issue such as warning signs of impending overdose (e.g., confusion, sedation, or slurred speech), opioid therapy should not be discontinued abruptly, and clinicians should not rapidly reduce opioid dosages from higher dosages.
* **Actions: **: **Knowledge Capability: **
  * : shareable computable executable publishable
* **Actions: **: **Purpose: **
  * : The 2022 CDC Clinical Practice Guideline for Prescribing Opioids for Pain is intended to improve communication between clinicians and patients about the benefits and risks of pain treatments, including opioid therapy; improve the effectiveness and safety of pain treatment; mitigate pain; improve function and quality of life for patients with pain; and reduce risks associated with opioid pain therapy, including opioid use disorder, overdose, and death. The recommendations do not apply to pain related to sickle cell disease or cancer or to patients receiving palliative or end-of-life care.
* **Actions: **: **Usage: **
  * : The recommendations related to opioid dosages are not intended to be used as an inflexible, rigid standard of care; rather, they are intended to be guideposts to help inform clinician-patient decision-making. Risks of opioid use, including risk for overdose and overdose death, increase continuously with dosage, and there is no single dosage threshold below which risks are eliminated. Therefore, the recommendation language emphasizes that clinicians should avoid increasing dosage above levels likely to yield diminishing returns in benefits relative to risks to patients rather than emphasizing a single specific numeric threshold. Further, these recommendations apply specifically to starting opioids or to increasing opioid dosages, and a different set of benefits and risks applies to reducing opioid dosages.
* **Actions: **: **Copyright: **
  * : © CDC 2016+.
* **Actions: **: **Libraries: **
  * : 
| |
| :--- |
| [Library - Recommendations #4 and #5 - Lowest Effective Dose](Library-OpioidCDSREC04And05.md) |




## Resource Content

```json
{
  "resourceType" : "PlanDefinition",
  "id" : "opioidcds-04-05",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-recommendationdefinition",
    "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-publishableplandefinition"]
  },
  "contained" : [{
    "resourceType" : "Library",
    "id" : "effective-data-requirements",
    "name" : "EffectiveDataRequirements",
    "status" : "active",
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/library-type",
        "code" : "module-definition"
      }]
    },
    "relatedArtifact" : [{
      "type" : "depends-on",
      "display" : "Library Common",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/Library/OpioidCDSCommon|2022.1.0"
    },
    {
      "type" : "depends-on",
      "display" : "Library FHIRHelpers",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/Library/FHIRHelpers|4.0.1"
    },
    {
      "type" : "depends-on",
      "display" : "Library Routines",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/Library/OpioidCDSRoutines|2022.1.0"
    },
    {
      "type" : "depends-on",
      "display" : "Library Config",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/Library/OpioidCDSCommonConfig|2022.1.0"
    },
    {
      "type" : "depends-on",
      "display" : "Library MMECalculator",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/Library/MMECalculator|3.0.0"
    },
    {
      "type" : "depends-on",
      "display" : "Library OMTKLogic",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/Library/OMTKLogic|3.0.0"
    },
    {
      "type" : "depends-on",
      "display" : "Library OMTKData",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/Library/OMTKData|3.0.0"
    },
    {
      "type" : "depends-on",
      "display" : "Library ConversionFactors",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/Library/ConversionFactors|3.0.0"
    },
    {
      "type" : "depends-on",
      "display" : "Library CDCMMEClinicalConversionFactors",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/Library/CDCMMEClinicalConversionFactors|3.0.0"
    },
    {
      "type" : "depends-on",
      "display" : "Code system Usage Context Type",
      "resource" : "http://terminology.hl7.org/CodeSystem/usage-context-type"
    },
    {
      "type" : "depends-on",
      "display" : "Code system CDC MME Usage Context Codes",
      "resource" : "http://fhir.org/guides/cdc/opioid-mme-r4/CodeSystem/CDCMMEUsageContextCodes"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Opioid analgesics with ambulatory misuse potential",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/opioid-analgesics-with-ambulatory-misuse-potential"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Community",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/medicationrequest-category-community"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Encounter Diagnosis Condition Category",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/condition-encounter-diagnosis-category"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Problem List Condition Category",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/condition-problem-list-category"
    },
    {
      "type" : "depends-on",
      "display" : "Value set US Core Health Concern Condition Category",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/condition-us-core-health-concern-category"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Sickle Cell Diseases",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/sickle-cell-diseases"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Active Condition",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/condition-clinical-status-active"
    },
    {
      "type" : "depends-on",
      "display" : "Value set CDC malignant cancer conditions",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/cdc-malignant-cancer-conditions"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Conditions likely terminal for opioid prescribing",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/conditions-likely-terminal-for-opioid-prescribing"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Limited life expectancy conditions",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/limited-life-expectancy-conditions"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Hospice Finding Codes",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/hospice-finding"
    },
    {
      "type" : "depends-on",
      "display" : "Value set Hospice Disposition",
      "resource" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/hospice-disposition"
    }],
    "parameter" : [{
      "name" : "ContextPrescriptions",
      "use" : "in",
      "min" : 0,
      "max" : "*",
      "type" : "MedicationRequest"
    },
    {
      "name" : "ErrorLevel",
      "use" : "in",
      "min" : 0,
      "max" : "1",
      "type" : "string"
    },
    {
      "name" : "ConversionFactorSupplementName",
      "use" : "in",
      "min" : 0,
      "max" : "1",
      "type" : "string"
    },
    {
      "name" : "Is Recommendation Applicable?",
      "use" : "out",
      "min" : 0,
      "max" : "1",
      "type" : "boolean"
    }],
    "dataRequirement" : [{
      "type" : "Medication",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Medication"],
      "mustSupport" : ["id", "code"]
    },
    {
      "type" : "Patient",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
    },
    {
      "type" : "Condition",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Condition"],
      "mustSupport" : ["category", "code", "clinicalStatus"],
      "codeFilter" : [{
        "path" : "category",
        "valueSet" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/condition-us-core-health-concern-category"
      }]
    },
    {
      "type" : "Condition",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Condition"],
      "mustSupport" : ["category",
      "code",
      "clinicalStatus",
      "encounter",
      "encounter.reference"],
      "codeFilter" : [{
        "path" : "category",
        "valueSet" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/condition-encounter-diagnosis-category"
      }]
    },
    {
      "type" : "Condition",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Condition"],
      "mustSupport" : ["category", "code", "clinicalStatus", "clinicalStatus.coding"],
      "codeFilter" : [{
        "path" : "category",
        "valueSet" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/condition-problem-list-category"
      }]
    },
    {
      "type" : "Encounter",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Encounter"],
      "mustSupport" : ["period",
      "period.start",
      "id",
      "hospitalization",
      "hospitalization.dischargeDisposition",
      "hospitalization.dischargeDisposition.coding",
      "status",
      "status.value"]
    },
    {
      "type" : "MedicationRequest",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/MedicationRequest"],
      "mustSupport" : ["authoredOn",
      "medication",
      "medication.reference",
      "id",
      "status",
      "intent",
      "category",
      "subject",
      "recorder",
      "dosageInstruction",
      "dispenseRequest",
      "status.value",
      "rxNormCode",
      "dose",
      "dosesPerDay",
      "isDraft",
      "isPRN",
      "prescription",
      "mme",
      "mme.value"]
    },
    {
      "type" : "Observation",
      "profile" : ["http://hl7.org/fhir/StructureDefinition/Observation"],
      "mustSupport" : ["code", "status", "status.value"],
      "codeFilter" : [{
        "path" : "code",
        "valueSet" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/hospice-finding"
      }]
    }]
  }],
  "extension" : [{
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "shareable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "computable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "executable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "publishable"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-directReferenceCode",
    "valueCoding" : {
      "system" : "http://terminology.hl7.org/CodeSystem/usage-context-type",
      "code" : "task"
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-directReferenceCode",
    "valueCoding" : {
      "system" : "http://fhir.org/guides/cdc/opioid-mme-r4/CodeSystem/CDCMMEUsageContextCodes",
      "code" : "mme-calculation"
    }
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC04And05"
    },
    {
      "url" : "name",
      "valueString" : "Chronic Pain Opioid Analgesic with Ambulatory Misuse Potential Prescriptions"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Chronic Pain Opioid Analgesic with Ambulatory Misuse Potential Prescriptions\":\n  ( Common.\"Is Opioid Analgesic with Ambulatory Misuse Potential?\"( ContextPrescriptions ) ) AmbulatoryOpioidPrescription\n    where Routines.\"Is Subacute or Chronic Pain Prescription?\"( AmbulatoryOpioidPrescription )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 0
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC04And05"
    },
    {
      "url" : "name",
      "valueString" : "Patient Is Being Prescribed Opioid Analgesic with Ambulatory Misuse Potential"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Patient Is Being Prescribed Opioid Analgesic with Ambulatory Misuse Potential\":\n  exists( \"Chronic Pain Opioid Analgesic with Ambulatory Misuse Potential Prescriptions\" )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 1
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "Age Less than 18 Years Is Enabled"
    },
    {
      "url" : "statement",
      "valueString" : "// CDC 2022 General Inclusion Criteria\ndefine \"Age Less than 18 Years Is Enabled\":\n  true"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 2
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Patient Age Less Than 18"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Patient Age Less Than 18\":\n  if (Config.\"Age Less than 18 Years Is Enabled\") then\n    AgeInYearsAt(Today()) < 18\n  else false"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 3
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "Sickle Cell Check Enabled"
    },
    {
      "url" : "statement",
      "valueString" : "// Sickle Cell\ndefine \"Sickle Cell Check Enabled\":\n  true"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 4
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "Sickle Cell Assumed Active"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Sickle Cell Assumed Active\":\n  true"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 5
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "US Core-Categorized Conditions"
    },
    {
      "url" : "statement",
      "valueString" : "// 3. Medications indicating end of life\n    /* or exists (\n      \"Medications Indicating End of Life\"\n    ) */\n\ndefine \"US Core-Categorized Conditions\":\n  [Condition: category in \"Encounter Diagnosis Condition Category\"]\n    union [Condition: category in \"Problem List Condition Category\"]\n    union [Condition: category in \"US Core Health Concern Condition Category\"]"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 6
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "Positive Sickle Cell Condition"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Positive Sickle Cell Condition\":\n  if Config.\"Sickle Cell Check Enabled\" and not Config.\"Sickle Cell Assumed Active\"\n    then (\n      \"US Core-Categorized Conditions\" C\n        where C.code in \"Sickle Cell Diseases\"\n          and C.clinicalStatus in \"Active Condition\"\n    ) else if Config.\"Sickle Cell Check Enabled\" and Config.\"Sickle Cell Assumed Active\"\n        then (\n          \"US Core-Categorized Conditions\" C\n            where C.code in \"Sickle Cell Diseases\"\n        )\n      else null"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 7
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Condition Positive for Sickle Cell"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Condition Positive for Sickle Cell\":\n  if (Config.\"Sickle Cell Check Enabled\") then\n    exists(\n      Common.\"Positive Sickle Cell Condition\"\n    ) \n  else false"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 8
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "Active Cancer Treatment Encounters Condition Is Enabled"
    },
    {
      "url" : "statement",
      "valueString" : "// Active Cancer Treatment\ndefine \"Active Cancer Treatment Encounters Condition Is Enabled\":\n  true"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 9
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Encounter Period"
    },
    {
      "url" : "statement",
      "valueString" : "// End of Opioid Naive Routine\n\n/*\n**  Routine #3\n**  Active Cancer Treatment Routine\n**\n**  Definition                    | Answer to Proceed   | Details                                    | Data (Terminology) Requirement\n**  ---------------------------------------------------------------------------------------------------------------------------------\n**  Two office visits within the  | No                  | Look for a minimum of two distinct         | Office Visit\n**  past 12 months                |                     | encounters within 12 months of the date    |\n**                                |                     | of the current visit for which each of the |\n**                                |                     | following is true:                         |\n**                                |                     |   - the encounter diagnosis (primary or    |\n**                                |                     |     secondary or co-morbidity diagnosis)   |\n**                                |                     |     is listed in the CDC Malignant Cancer  |\n**                                |                     |     Conditions value set                   |\n**  ---------------------------------------------------------------------------------------------------------------------------------\n**  Office visits with an         | No                  | The encounter is performed by an           | Oncology specialty\n**  oncology specialist           |                     | oncologist as defined in the oncology      | designations (NUCC)\n**  present                       |                     | specialty designations using the           |\n**                                |                     | National Uniform Claim Committee           |\n**                                |                     | (NUCC) classifications                     |\n**  ---------------------------------------------------------------------------------------------------------------------------------\n**  Office visits including CDC   | No                  | The encounter diagnosis (primary or        | CDC malignant cancer\n**  malignant cancer              |                     | secondary or co-morbidity diagnosis)       | conditions\n**  condition                     |                     | is listed in the CDC Malignant Cancer      |\n**                                |                     | Conditions value set                       |\n**  ----------------------------------------------------------------------------------------------------------------------------------\n**\n*/\n\ndefine \"Encounter Period\":\n  Interval[Today() - 12 months, Today())"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 10
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "USCore Encounter Cancer Diagnoses"
    },
    {
      "url" : "statement",
      "valueString" : "define \"USCore Encounter Cancer Diagnoses\":\n  [Condition: category in \"Encounter Diagnosis Condition Category\"] CancerDiagnoses\n    where CancerDiagnoses.code in \"CDC malignant cancer conditions\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 11
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Encounters with Cancer Diagnosis During Encounter Period"
    },
    {
      "url" : "statement",
      "valueString" : "// encounter-diagnosis, problem-list and health-concern Conditions\n// define \"US Core-Categorized Cancer Diagnoses\":\n//   Common.\"US Core-Categorized Conditions\" C\n//     where C.code in Common.\"CDC malignant cancer conditions\"\n\n// define \"Encounters with Cancer Diagnosis During Encounter Period\":\n//   [Encounter] Encounter\n//     with \"US Core-Categorized Cancer Diagnoses\" CancerDiagnosis\n//     such that date from Encounter.period.\"start\".value in day of \"Encounter Period\"\n//       and EndsWith(CancerDiagnosis.encounter.reference, Encounter.id)\n\ndefine \"Encounters with Cancer Diagnosis During Encounter Period\":\n  [Encounter] Encounters\n    where date from Encounters.period.\"start\" in day of \"Encounter Period\"\n      and exists (\n        Common.\"USCore Encounter Cancer Diagnoses\" CancerDiagnoses\n          where EndsWith(CancerDiagnoses.encounter.reference, Encounters.id)\n      )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 12
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Number of Encounters with Cancer Diagnosis During Encounter Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Number of Encounters with Cancer Diagnosis During Encounter Period\":\n  Count (\"Encounters with Cancer Diagnosis During Encounter Period\")"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 13
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Has Two or More Encounters with Cancer Diagnosis During Encounter Period"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Has Two or More Encounters with Cancer Diagnosis During Encounter Period\":\n  \"Number of Encounters with Cancer Diagnosis During Encounter Period\" >= 2"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 14
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "USCore Problem List Cancer Diagnoses"
    },
    {
      "url" : "statement",
      "valueString" : "define \"USCore Problem List Cancer Diagnoses\":\n  [Condition: category in \"Problem List Condition Category\"] CancerDiagnoses\n    where CancerDiagnoses.code in \"CDC malignant cancer conditions\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 15
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Has Active Cancer Diagnosis on Problem List"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Has Active Cancer Diagnosis on Problem List\":\n  exists (\n    Common.\"USCore Problem List Cancer Diagnoses\" CancerDiagnoses\n      where CancerDiagnoses.category in Common.\"Problem List Condition Category\"\n        and exists(\n          CancerDiagnoses.clinicalStatus.coding ClinicalStatus\n            where ClinicalStatus.code ~ 'active'\n        )\n  )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 16
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Is Active Cancer Treatment?"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Is Active Cancer Treatment?\":\n  if (Config.\"Active Cancer Treatment Encounters Condition Is Enabled\") \n    then \"Has Two or More Encounters with Cancer Diagnosis During Encounter Period\"\n      or \"Has Active Cancer Diagnosis on Problem List\"\n  else false"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 17
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "End-Stage Disease Criteria Enabled"
    },
    {
      "url" : "statement",
      "valueString" : "// CDC 2022 General Inclusion Criteria\ndefine \"End-Stage Disease Criteria Enabled\":\n  true"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 18
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Conditions Likely Terminal for Opioid Prescribing"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Conditions Likely Terminal for Opioid Prescribing\":\n  if (Config.\"End-Stage Disease Criteria Enabled\") then\n    exists (\n      Common.\"US Core-Categorized Conditions\" EOLC\n        where EOLC.code in Common.\"Conditions likely terminal for opioid prescribing\"\n          // and EOLC.clinicalStatus in Common.\"Active Condition\"\n    )\n  else false"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 19
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "CDC 2022 Guideline General Inclusion Criteria"
    },
    {
      "url" : "statement",
      "valueString" : "define \"CDC 2022 Guideline General Inclusion Criteria\":\n  not \"Patient Age Less Than 18\"\n    and not \"Condition Positive for Sickle Cell\"\n    and not \"Is Active Cancer Treatment?\"\n    and not \"Conditions Likely Terminal for Opioid Prescribing\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 20
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OMTKData"
    },
    {
      "url" : "name",
      "valueString" : "DrugIngredients"
    },
    {
      "url" : "statement",
      "valueString" : "/*\nThis library contains drug ingredient data for opioid ingredients of combinations drugs as determined using the [RxNav](https://rxnav.nlm.nih.gov/) API.\nThe content was produced using the process described [here](http://build.fhir.org/ig/cqframework/opioid-cds-r4/service-documentation.html#solution-component-1-medication-and-terminology-knowledge-base).\n\nThis version of the content was generated on 2020-10-20\n\nThis product uses publicly available data courtesy of the U.S. National Library of Medicine (NLM),\nNational Institutes of Health, Department of Health and Human Services; NLM is not responsible for\nthe product and does not endorse or recommend this or any other product.\n\nNelson SJ, Zeng K, Kilbourne J, Powell T, Moore R. Normalized names for clinical drugs: RxNorm at 6 years.\nJ Am Med Inform Assoc. 2011 Jul-Aug;18(4)441-8. doi: 10.1136/amiajnl-2011-000116.\nEpub 2011 Apr 21. PubMed PMID: 21515544; PubMed Central PMCID: PMC3128404.\n[Full text](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3128404/)\n*/\n\n/*\nDrugIngredients:\n  List<{\n    drugCode Integer,\n    drugName String,\n    doseFormCode Integer,\n    doseFormName String,\n    ingredientCode Integer,\n    ingredientName String,\n    strength String,\n    strengthValue Decimal,\n    strengthUnit String\n  }>\n*/\n\n// Generated from LocalDataStore_RxNav_OpioidCds-2020-10-20.sqlite\ndefine DrugIngredients:\n{\n  { drugCode: 197696, drugName: '72 HR fentanyl 0.075 MG/HR Transdermal System', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.075 MG/HR', strengthValue: 0.075, strengthUnit: 'MG/HR' },\n  { drugCode: 197873, drugName: 'levorphanol tartrate 2 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 6378, ingredientName: 'Levorphanol', strength: '2 MG', strengthValue: 2.0, strengthUnit: 'MG' },\n  { drugCode: 205533, drugName: '1 ML buprenorphine 0.3 MG/ML Injection [Buprenex]', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.3 MG/ML', strengthValue: 0.3, strengthUnit: 'MG/ML' },\n  { drugCode: 238129, drugName: '1 ML buprenorphine 0.3 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.3 MG/ML', strengthValue: 0.3, strengthUnit: 'MG/ML' },\n  { drugCode: 238133, drugName: 'pentazocine 30 MG/ML Injectable Solution', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 8001, ingredientName: 'Pentazocine', strength: '30 MG/ML', strengthValue: 30.0, strengthUnit: 'MG/ML' },\n  { drugCode: 245134, drugName: '72 HR fentanyl 0.025 MG/HR Transdermal System', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.025 MG/HR', strengthValue: 0.025, strengthUnit: 'MG/HR' },\n  { drugCode: 245135, drugName: '72 HR fentanyl 0.05 MG/HR Transdermal System', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.05 MG/HR', strengthValue: 0.05, strengthUnit: 'MG/HR' },\n  { drugCode: 245136, drugName: '72 HR fentanyl 0.1 MG/HR Transdermal System', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.1 MG/HR', strengthValue: 0.1, strengthUnit: 'MG/HR' },\n  { drugCode: 246474, drugName: 'buprenorphine 0.2 MG Sublingual Tablet', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.2 MG', strengthValue: 0.2, strengthUnit: 'MG' },\n  { drugCode: 250426, drugName: 'buprenorphine 0.4 MG Sublingual Tablet', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.4 MG', strengthValue: 0.4, strengthUnit: 'MG' },\n  { drugCode: 250485, drugName: 'pentazocine 25 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 8001, ingredientName: 'Pentazocine', strength: '25 MG', strengthValue: 25.0, strengthUnit: 'MG' },\n  { drugCode: 250486, drugName: 'pentazocine 50 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 8001, ingredientName: 'Pentazocine', strength: '50 MG', strengthValue: 50.0, strengthUnit: 'MG' },\n  { drugCode: 250877, drugName: 'pentazocine 50 MG Rectal Suppository', doseFormCode: 316978, doseFormName: 'Rectal Suppository', ingredientCode: 8001, ingredientName: 'Pentazocine', strength: '50 MG', strengthValue: 50.0, strengthUnit: 'MG' },\n  { drugCode: 261106, drugName: 'fentanyl 0.2 MG Oral Lozenge [Actiq]', doseFormCode: 316992, doseFormName: 'Oral Lozenge', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.2 MG', strengthValue: 0.2, strengthUnit: 'MG' },\n  { drugCode: 261107, drugName: 'fentanyl 0.6 MG Oral Lozenge [Actiq]', doseFormCode: 316992, doseFormName: 'Oral Lozenge', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.6 MG', strengthValue: 0.6, strengthUnit: 'MG' },\n  { drugCode: 261108, drugName: 'fentanyl 0.8 MG Oral Lozenge [Actiq]', doseFormCode: 316992, doseFormName: 'Oral Lozenge', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.8 MG', strengthValue: 0.8, strengthUnit: 'MG' },\n  { drugCode: 261109, drugName: 'fentanyl 1.2 MG Oral Lozenge [Actiq]', doseFormCode: 316992, doseFormName: 'Oral Lozenge', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '1.2 MG', strengthValue: 1.2, strengthUnit: 'MG' },\n  { drugCode: 261110, drugName: 'fentanyl 1.6 MG Oral Lozenge [Actiq]', doseFormCode: 316992, doseFormName: 'Oral Lozenge', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '1.6 MG', strengthValue: 1.6, strengthUnit: 'MG' },\n  { drugCode: 261184, drugName: '72 HR fentanyl 0.025 MG/HR Transdermal System [Duragesic]', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.025 MG/HR', strengthValue: 0.025, strengthUnit: 'MG/HR' },\n  { drugCode: 261185, drugName: '72 HR fentanyl 0.05 MG/HR Transdermal System [Duragesic]', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.05 MG/HR', strengthValue: 0.05, strengthUnit: 'MG/HR' },\n  { drugCode: 261186, drugName: '72 HR fentanyl 0.075 MG/HR Transdermal System [Duragesic]', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.075 MG/HR', strengthValue: 0.075, strengthUnit: 'MG/HR' },\n  { drugCode: 262071, drugName: '72 HR fentanyl 0.1 MG/HR Transdermal System [Duragesic]', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.1 MG/HR', strengthValue: 0.1, strengthUnit: 'MG/HR' },\n  { drugCode: 262219, drugName: 'fentanyl 0.4 MG Oral Lozenge [Actiq]', doseFormCode: 316992, doseFormName: 'Oral Lozenge', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.4 MG', strengthValue: 0.4, strengthUnit: 'MG' },\n  { drugCode: 310293, drugName: 'fentanyl 1.2 MG Oral Lozenge', doseFormCode: 316992, doseFormName: 'Oral Lozenge', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '1.2 MG', strengthValue: 1.2, strengthUnit: 'MG' },\n  { drugCode: 310294, drugName: 'fentanyl 1.6 MG Oral Lozenge', doseFormCode: 316992, doseFormName: 'Oral Lozenge', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '1.6 MG', strengthValue: 1.6, strengthUnit: 'MG' },\n  { drugCode: 310295, drugName: 'fentanyl 0.2 MG Oral Lozenge', doseFormCode: 316992, doseFormName: 'Oral Lozenge', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.2 MG', strengthValue: 0.2, strengthUnit: 'MG' },\n  { drugCode: 310296, drugName: 'fentanyl 0.3 MG Oral Lozenge', doseFormCode: 316992, doseFormName: 'Oral Lozenge', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.3 MG', strengthValue: 0.3, strengthUnit: 'MG' },\n  { drugCode: 310297, drugName: 'fentanyl 0.4 MG Oral Lozenge', doseFormCode: 316992, doseFormName: 'Oral Lozenge', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.4 MG', strengthValue: 0.4, strengthUnit: 'MG' },\n  { drugCode: 311297, drugName: 'levomethadyl 10 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 237005, ingredientName: 'Levomethadyl', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 312104, drugName: 'belladonna alkaloids 16.2 MG / opium 30 MG Rectal Suppository', doseFormCode: 316978, doseFormName: 'Rectal Suppository', ingredientCode: 7676, ingredientName: 'Opium', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 312107, drugName: 'belladonna alkaloids 16.2 MG / opium 60 MG Rectal Suppository', doseFormCode: 316978, doseFormName: 'Rectal Suppository', ingredientCode: 7676, ingredientName: 'Opium', strength: '60 MG', strengthValue: 60.0, strengthUnit: 'MG' },\n  { drugCode: 312288, drugName: 'acetaminophen 650 MG / pentazocine 25 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 8001, ingredientName: 'Pentazocine', strength: '25 MG', strengthValue: 25.0, strengthUnit: 'MG' },\n  { drugCode: 312289, drugName: 'naloxone 0.5 MG / pentazocine 50 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 8001, ingredientName: 'Pentazocine', strength: '50 MG', strengthValue: 50.0, strengthUnit: 'MG' },\n  { drugCode: 313992, drugName: 'fentanyl 0.6 MG Oral Lozenge', doseFormCode: 316992, doseFormName: 'Oral Lozenge', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.6 MG', strengthValue: 0.6, strengthUnit: 'MG' },\n  { drugCode: 313993, drugName: 'fentanyl 0.8 MG Oral Lozenge', doseFormCode: 316992, doseFormName: 'Oral Lozenge', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.8 MG', strengthValue: 0.8, strengthUnit: 'MG' },\n  { drugCode: 351264, drugName: 'buprenorphine 2 MG Sublingual Tablet', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '2 MG', strengthValue: 2.0, strengthUnit: 'MG' },\n  { drugCode: 351265, drugName: 'buprenorphine 8 MG Sublingual Tablet', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '8 MG', strengthValue: 8.0, strengthUnit: 'MG' },\n  { drugCode: 351266, drugName: 'buprenorphine 2 MG / naloxone 0.5 MG Sublingual Tablet', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '2 MG', strengthValue: 2.0, strengthUnit: 'MG' },\n  { drugCode: 351267, drugName: 'buprenorphine 8 MG / naloxone 2 MG Sublingual Tablet', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '8 MG', strengthValue: 8.0, strengthUnit: 'MG' },\n  { drugCode: 577057, drugName: '72 HR fentanyl 0.012 MG/HR Transdermal System', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.012 MG/HR', strengthValue: 0.012, strengthUnit: 'MG/HR' },\n  { drugCode: 583490, drugName: '72 HR fentanyl 0.012 MG/HR Transdermal System [Duragesic]', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.012 MG/HR', strengthValue: 0.012, strengthUnit: 'MG/HR' },\n  { drugCode: 637540, drugName: 'aspirin 325 MG / oxycodone hydrochloride 4.5 MG / oxycodone terephthalate 0.38 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '4.5 MG', strengthValue: 4.5, strengthUnit: 'MG' },\n  { drugCode: 637540, drugName: 'aspirin 325 MG / oxycodone hydrochloride 4.5 MG / oxycodone terephthalate 0.38 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '0.38 MG', strengthValue: 0.38, strengthUnit: 'MG' },\n  { drugCode: 668363, drugName: 'fentanyl 0.1 MG Buccal Tablet', doseFormCode: 970789, doseFormName: 'Buccal Tablet', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.1 MG', strengthValue: 0.1, strengthUnit: 'MG' },\n  { drugCode: 668364, drugName: 'fentanyl 0.2 MG Buccal Tablet', doseFormCode: 970789, doseFormName: 'Buccal Tablet', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.2 MG', strengthValue: 0.2, strengthUnit: 'MG' },\n  { drugCode: 668365, drugName: 'fentanyl 0.4 MG Buccal Tablet', doseFormCode: 970789, doseFormName: 'Buccal Tablet', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.4 MG', strengthValue: 0.4, strengthUnit: 'MG' },\n  { drugCode: 668366, drugName: 'fentanyl 0.6 MG Buccal Tablet', doseFormCode: 970789, doseFormName: 'Buccal Tablet', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.6 MG', strengthValue: 0.6, strengthUnit: 'MG' },\n  { drugCode: 668367, drugName: 'fentanyl 0.8 MG Buccal Tablet', doseFormCode: 970789, doseFormName: 'Buccal Tablet', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.8 MG', strengthValue: 0.8, strengthUnit: 'MG' },\n  { drugCode: 668622, drugName: 'fentanyl 0.1 MG Buccal Tablet [Fentora]', doseFormCode: 970789, doseFormName: 'Buccal Tablet', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.1 MG', strengthValue: 0.1, strengthUnit: 'MG' },\n  { drugCode: 668624, drugName: 'fentanyl 0.2 MG Buccal Tablet [Fentora]', doseFormCode: 970789, doseFormName: 'Buccal Tablet', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.2 MG', strengthValue: 0.2, strengthUnit: 'MG' },\n  { drugCode: 668626, drugName: 'fentanyl 0.4 MG Buccal Tablet [Fentora]', doseFormCode: 970789, doseFormName: 'Buccal Tablet', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.4 MG', strengthValue: 0.4, strengthUnit: 'MG' },\n  { drugCode: 668628, drugName: 'fentanyl 0.6 MG Buccal Tablet [Fentora]', doseFormCode: 970789, doseFormName: 'Buccal Tablet', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.6 MG', strengthValue: 0.6, strengthUnit: 'MG' },\n  { drugCode: 668630, drugName: 'fentanyl 0.8 MG Buccal Tablet [Fentora]', doseFormCode: 970789, doseFormName: 'Buccal Tablet', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.8 MG', strengthValue: 0.8, strengthUnit: 'MG' },\n  { drugCode: 706898, drugName: 'fentanyl 0.3 MG Buccal Tablet', doseFormCode: 970789, doseFormName: 'Buccal Tablet', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.3 MG', strengthValue: 0.3, strengthUnit: 'MG' },\n  { drugCode: 724614, drugName: 'aspirin 325 MG / oxycodone hydrochloride 2.25 MG / oxycodone terephthalate 0.19 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '0.19 MG', strengthValue: 0.19, strengthUnit: 'MG' },\n  { drugCode: 724614, drugName: 'aspirin 325 MG / oxycodone hydrochloride 2.25 MG / oxycodone terephthalate 0.19 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '2.25 MG', strengthValue: 2.25, strengthUnit: 'MG' },\n  { drugCode: 727759, drugName: '2 ML fentanyl 0.05 MG/ML Cartridge', doseFormCode: 1649572, doseFormName: 'Cartridge', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.05 MG/ML', strengthValue: 0.05, strengthUnit: 'MG/ML' },\n  { drugCode: 825409, drugName: 'tapentadol 100 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 787390, ingredientName: 'tapentadol', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 825411, drugName: 'tapentadol 50 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 787390, ingredientName: 'tapentadol', strength: '50 MG', strengthValue: 50.0, strengthUnit: 'MG' },\n  { drugCode: 825413, drugName: 'tapentadol 75 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 787390, ingredientName: 'tapentadol', strength: '75 MG', strengthValue: 75.0, strengthUnit: 'MG' },\n  { drugCode: 827748, drugName: 'propoxyphene napsylate 100 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 8785, ingredientName: 'Propoxyphene', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 827751, drugName: 'acetaminophen 325 MG / propoxyphene napsylate 100 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 8785, ingredientName: 'Propoxyphene', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 828576, drugName: 'acetaminophen 650 MG / propoxyphene napsylate 100 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 8785, ingredientName: 'Propoxyphene', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 828585, drugName: 'aspirin 389 MG / caffeine 32.4 MG / propoxyphene hydrochloride 32 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 8785, ingredientName: 'Propoxyphene', strength: '32 MG', strengthValue: 32.0, strengthUnit: 'MG' },\n  { drugCode: 828594, drugName: 'aspirin 389 MG / caffeine 32.4 MG / propoxyphene hydrochloride 65 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 8785, ingredientName: 'Propoxyphene', strength: '65 MG', strengthValue: 65.0, strengthUnit: 'MG' },\n  { drugCode: 830196, drugName: 'opium tincture 100 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 7676, ingredientName: 'Opium', strength: '100 MG/ML', strengthValue: 100.0, strengthUnit: 'MG/ML' },\n  { drugCode: 833036, drugName: 'acetaminophen 750 MG / hydrocodone bitartrate 7.5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 833709, drugName: '24 HR tramadol hydrochloride 100 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 833711, drugName: '24 HR tramadol hydrochloride 200 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '200 MG', strengthValue: 200.0, strengthUnit: 'MG' },\n  { drugCode: 833713, drugName: '24 HR tramadol hydrochloride 300 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '300 MG', strengthValue: 300.0, strengthUnit: 'MG' },\n  { drugCode: 835603, drugName: 'tramadol hydrochloride 50 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '50 MG', strengthValue: 50.0, strengthUnit: 'MG' },\n  { drugCode: 835605, drugName: 'tramadol hydrochloride 50 MG Oral Tablet [Ultram]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '50 MG', strengthValue: 50.0, strengthUnit: 'MG' },\n  { drugCode: 836395, drugName: 'acetaminophen 325 MG / tramadol hydrochloride 37.5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '37.5 MG', strengthValue: 37.5, strengthUnit: 'MG' },\n  { drugCode: 836397, drugName: 'acetaminophen 325 MG / tramadol hydrochloride 37.5 MG Oral Tablet [Ultracet]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '37.5 MG', strengthValue: 37.5, strengthUnit: 'MG' },\n  { drugCode: 836408, drugName: 'tramadol hydrochloride 50 MG Disintegrating Oral Tablet', doseFormCode: 316942, doseFormName: 'Disintegrating Oral Tablet', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '50 MG', strengthValue: 50.0, strengthUnit: 'MG' },\n  { drugCode: 836466, drugName: 'tramadol hydrochloride 50 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '50 MG', strengthValue: 50.0, strengthUnit: 'MG' },\n  { drugCode: 836485, drugName: 'tramadol hydrochloride 1 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 845315, drugName: '24 HR tramadol hydrochloride 200 MG Extended Release Oral Tablet [Ultram]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '200 MG', strengthValue: 200.0, strengthUnit: 'MG' },\n  { drugCode: 845316, drugName: '24 HR tramadol hydrochloride 300 MG Extended Release Oral Tablet [Ultram]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '300 MG', strengthValue: 300.0, strengthUnit: 'MG' },\n  { drugCode: 848768, drugName: 'aspirin 325 MG / oxycodone hydrochloride 4.84 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '4.84 MG', strengthValue: 4.84, strengthUnit: 'MG' },\n  { drugCode: 848928, drugName: 'aspirin 325 MG / oxycodone hydrochloride 4.84 MG Oral Tablet [Endodan Reformulated May 2009]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '4.84 MG', strengthValue: 4.84, strengthUnit: 'MG' },\n  { drugCode: 849279, drugName: 'propoxyphene hydrochloride 65 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 8785, ingredientName: 'Propoxyphene', strength: '65 MG', strengthValue: 65.0, strengthUnit: 'MG' },\n  { drugCode: 849293, drugName: 'acetaminophen 325 MG / propoxyphene hydrochloride 32.5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 8785, ingredientName: 'Propoxyphene', strength: '32.5 MG', strengthValue: 32.5, strengthUnit: 'MG' },\n  { drugCode: 849295, drugName: 'acetaminophen 325 MG / propoxyphene napsylate 50 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 8785, ingredientName: 'Propoxyphene', strength: '50 MG', strengthValue: 50.0, strengthUnit: 'MG' },\n  { drugCode: 849304, drugName: 'acetaminophen 500 MG / propoxyphene napsylate 100 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 8785, ingredientName: 'Propoxyphene', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 849329, drugName: 'tramadol hydrochloride 50 MG/ML Injectable Solution', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '50 MG/ML', strengthValue: 50.0, strengthUnit: 'MG/ML' },\n  { drugCode: 849331, drugName: 'tramadol hydrochloride 75 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '75 MG', strengthValue: 75.0, strengthUnit: 'MG' },\n  { drugCode: 849561, drugName: '12 HR tramadol hydrochloride 150 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '150 MG', strengthValue: 150.0, strengthUnit: 'MG' },\n  { drugCode: 849903, drugName: 'tramadol hydrochloride 50 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '50 MG', strengthValue: 50.0, strengthUnit: 'MG' },\n  { drugCode: 854140, drugName: 'tapentadol 100 MG Oral Tablet [Nucynta]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 787390, ingredientName: 'tapentadol', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 854142, drugName: 'tapentadol 50 MG Oral Tablet [Nucynta]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 787390, ingredientName: 'tapentadol', strength: '50 MG', strengthValue: 50.0, strengthUnit: 'MG' },\n  { drugCode: 854144, drugName: 'tapentadol 75 MG Oral Tablet [Nucynta]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 787390, ingredientName: 'tapentadol', strength: '75 MG', strengthValue: 75.0, strengthUnit: 'MG' },\n  { drugCode: 856903, drugName: 'acetaminophen 500 MG / hydrocodone bitartrate 5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 856908, drugName: 'acetaminophen 660 MG / hydrocodone bitartrate 10 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 856940, drugName: 'acetaminophen 21.7 MG/ML / hydrocodone bitartrate 0.5 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 856942, drugName: 'acetaminophen 21.7 MG/ML / hydrocodone bitartrate 0.5 MG/ML Oral Solution [Hycet]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 856944, drugName: 'acetaminophen 21.7 MG/ML / hydrocodone bitartrate 0.67 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.67 MG/ML', strengthValue: 0.67, strengthUnit: 'MG/ML' },\n  { drugCode: 856946, drugName: 'acetaminophen 21.7 MG/ML / hydrocodone bitartrate 0.67 MG/ML Oral Solution [Zamicet]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.67 MG/ML', strengthValue: 0.67, strengthUnit: 'MG/ML' },\n  { drugCode: 856962, drugName: 'acetaminophen 500 MG / hydrocodone bitartrate 5 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 856980, drugName: 'acetaminophen 300 MG / hydrocodone bitartrate 10 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 856984, drugName: 'acetaminophen 300 MG / hydrocodone bitartrate 10 MG Oral Tablet [Xodol]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 856987, drugName: 'acetaminophen 300 MG / hydrocodone bitartrate 5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 856991, drugName: 'acetaminophen 300 MG / hydrocodone bitartrate 5 MG Oral Tablet [Xodol]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 856992, drugName: 'acetaminophen 300 MG / hydrocodone bitartrate 7.5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 856996, drugName: 'acetaminophen 300 MG / hydrocodone bitartrate 7.5 MG Oral Tablet [Xodol]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 856999, drugName: 'acetaminophen 325 MG / hydrocodone bitartrate 10 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 857001, drugName: 'acetaminophen 325 MG / hydrocodone bitartrate 10 MG Oral Tablet [Norco]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 857002, drugName: 'acetaminophen 325 MG / hydrocodone bitartrate 5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 857004, drugName: 'acetaminophen 325 MG / hydrocodone bitartrate 5 MG Oral Tablet [Norco]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 857005, drugName: 'acetaminophen 325 MG / hydrocodone bitartrate 7.5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 857007, drugName: 'acetaminophen 325 MG / hydrocodone bitartrate 7.5 MG Oral Tablet [Norco]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 857076, drugName: 'acetaminophen 33.3 MG/ML / hydrocodone bitartrate 0.333 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.333 MG/ML', strengthValue: 0.333, strengthUnit: 'MG/ML' },\n  { drugCode: 857083, drugName: 'acetaminophen 650 MG / hydrocodone bitartrate 7.5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 857099, drugName: 'acetaminophen 33.3 MG/ML / hydrocodone bitartrate 0.5 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 857107, drugName: 'acetaminophen 500 MG / hydrocodone bitartrate 10 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 857111, drugName: 'acetaminophen 500 MG / hydrocodone bitartrate 2.5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '2.5 MG', strengthValue: 2.5, strengthUnit: 'MG' },\n  { drugCode: 857118, drugName: 'acetaminophen 500 MG / hydrocodone bitartrate 7.5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 857121, drugName: 'aspirin 500 MG / hydrocodone bitartrate 5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 857128, drugName: 'acetaminophen 400 MG / hydrocodone bitartrate 10 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 857131, drugName: 'acetaminophen 400 MG / hydrocodone bitartrate 5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 857134, drugName: 'acetaminophen 400 MG / hydrocodone bitartrate 7.5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 857237, drugName: 'pentazocine 30 MG/ML Injectable Solution [Talwin]', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 8001, ingredientName: 'Pentazocine', strength: '30 MG/ML', strengthValue: 30.0, strengthUnit: 'MG/ML' },\n  { drugCode: 857383, drugName: 'acetaminophen 650 MG / hydrocodone bitartrate 10 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 857391, drugName: 'acetaminophen 325 MG / hydrocodone bitartrate 2.5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '2.5 MG', strengthValue: 2.5, strengthUnit: 'MG' },\n  { drugCode: 857501, drugName: 'acetaminophen 556 MG / hydrocodone bitartrate 5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 857510, drugName: '12 HR chlorpheniramine polistirex 4 MG / hydrocodone polistirex 5 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 857512, drugName: '12 HR chlorpheniramine polistirex 8 MG / hydrocodone polistirex 10 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 857556, drugName: 'brompheniramine maleate 0.4 MG/ML / hydrocodone bitartrate 0.34 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.34 MG/ML', strengthValue: 0.34, strengthUnit: 'MG/ML' },\n  { drugCode: 857575, drugName: 'brompheniramine maleate 0.4 MG/ML / hydrocodone bitartrate 0.34 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Solution [Bromplex HD]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.34 MG/ML', strengthValue: 0.34, strengthUnit: 'MG/ML' },\n  { drugCode: 857734, drugName: 'chlorpheniramine maleate 0.4 MG/ML / hydrocodone bitartrate 0.334 MG/ML / phenylephrine hydrochloride 1 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.334 MG/ML', strengthValue: 0.334, strengthUnit: 'MG/ML' },\n  { drugCode: 857830, drugName: 'chlorpheniramine maleate 0.4 MG/ML / hydrocodone bitartrate 0.334 MG/ML / phenylephrine hydrochloride 1 MG/ML Oral Solution [Triant-HC]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.334 MG/ML', strengthValue: 0.334, strengthUnit: 'MG/ML' },\n  { drugCode: 857839, drugName: 'chlorpheniramine maleate 0.4 MG/ML / hydrocodone bitartrate 0.4 MG/ML / phenylephrine hydrochloride 1.5 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.4 MG/ML', strengthValue: 0.4, strengthUnit: 'MG/ML' },\n  { drugCode: 857845, drugName: 'chlorpheniramine maleate 0.4 MG/ML / hydrocodone bitartrate 0.4 MG/ML / phenylephrine hydrochloride 1.5 MG/ML Oral Solution [Hydro-PC II]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.4 MG/ML', strengthValue: 0.4, strengthUnit: 'MG/ML' },\n  { drugCode: 858087, drugName: 'fentanyl 1.2 MG Buccal Film', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '1.2 MG', strengthValue: 1.2, strengthUnit: 'MG' },\n  { drugCode: 858092, drugName: 'fentanyl 0.2 MG Buccal Film', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.2 MG', strengthValue: 0.2, strengthUnit: 'MG' },\n  { drugCode: 858095, drugName: 'fentanyl 0.4 MG Buccal Film', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.4 MG', strengthValue: 0.4, strengthUnit: 'MG' },\n  { drugCode: 858098, drugName: 'fentanyl 0.6 MG Buccal Film', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.6 MG', strengthValue: 0.6, strengthUnit: 'MG' },\n  { drugCode: 858101, drugName: 'fentanyl 0.8 MG Buccal Film', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.8 MG', strengthValue: 0.8, strengthUnit: 'MG' },\n  { drugCode: 858770, drugName: 'hydrocodone bitartrate 2.5 MG / ibuprofen 200 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '2.5 MG', strengthValue: 2.5, strengthUnit: 'MG' },\n  { drugCode: 858772, drugName: 'hydrocodone bitartrate 2.5 MG / ibuprofen 200 MG Oral Tablet [Reprexain]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '2.5 MG', strengthValue: 2.5, strengthUnit: 'MG' },\n  { drugCode: 858778, drugName: 'hydrocodone bitartrate 5 MG / ibuprofen 200 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 858780, drugName: 'hydrocodone bitartrate 5 MG / ibuprofen 200 MG Oral Tablet [Ibudone]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 858798, drugName: 'hydrocodone bitartrate 7.5 MG / ibuprofen 200 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 858838, drugName: 'hydrocodone bitartrate 7.5 MG / ibuprofen 200 MG Oral Tablet [Vicoprofen]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 858939, drugName: 'guaiacolsulfonate 24 MG/ML / hydrocodone bitartrate 0.5 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 858945, drugName: 'guaiacolsulfonate 24 MG/ML / hydrocodone bitartrate 0.5 MG/ML Oral Solution [Hydron EX]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 858953, drugName: 'guaiacolsulfonate 30 MG/ML / hydrocodone bitartrate 0.6 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.6 MG/ML', strengthValue: 0.6, strengthUnit: 'MG/ML' },\n  { drugCode: 858967, drugName: 'guaiacolsulfonate 60 MG/ML / hydrocodone bitartrate 0.9 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.9 MG/ML', strengthValue: 0.9, strengthUnit: 'MG/ML' },\n  { drugCode: 858969, drugName: 'guaiacolsulfonate 60 MG/ML / hydrocodone bitartrate 0.9 MG/ML Oral Solution [Hy-KXP]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.9 MG/ML', strengthValue: 0.9, strengthUnit: 'MG/ML' },\n  { drugCode: 858976, drugName: 'guaiacolsulfonate 60 MG/ML / hydrocodone bitartrate 0.9 MG/ML Oral Solution [Prolex DH]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.9 MG/ML', strengthValue: 0.9, strengthUnit: 'MG/ML' },\n  { drugCode: 858991, drugName: 'guaiacolsulfonate 60 MG/ML / hydrocodone bitartrate 1 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 859019, drugName: 'guaiacolsulfonate 60 MG/ML / hydrocodone bitartrate 1 MG/ML Oral Solution [Hydron KGS]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 859027, drugName: 'chlorpheniramine maleate 0.4 MG/ML / hydrocodone bitartrate 0.7 MG/ML / phenylephrine hydrochloride 1.5 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.7 MG/ML', strengthValue: 0.7, strengthUnit: 'MG/ML' },\n  { drugCode: 859029, drugName: 'chlorpheniramine maleate 0.4 MG/ML / hydrocodone bitartrate 0.7 MG/ML / phenylephrine hydrochloride 1.5 MG/ML Oral Solution [Hydro-PC II]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.7 MG/ML', strengthValue: 0.7, strengthUnit: 'MG/ML' },\n  { drugCode: 859097, drugName: 'guaiacolsulfonate 70 MG/ML / hydrocodone bitartrate 1 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 859099, drugName: 'guaiacolsulfonate 70 MG/ML / hydrocodone bitartrate 1 MG/ML Oral Solution [KGS HC]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 859137, drugName: 'chlorpheniramine maleate 0.4 MG/ML / hydrocodone bitartrate 1 MG/ML / phenylephrine hydrochloride 1 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 859141, drugName: 'chlorpheniramine maleate 0.4 MG/ML / hydrocodone bitartrate 1 MG/ML / phenylephrine hydrochloride 1 MG/ML Oral Solution [B-Tuss]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 859146, drugName: 'chlorpheniramine maleate 0.4 MG/ML / hydrocodone bitartrate 1 MG/ML / phenylephrine hydrochloride 2 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 859150, drugName: 'chlorpheniramine maleate 0.4 MG/ML / hydrocodone bitartrate 1 MG/ML / phenylephrine hydrochloride 2 MG/ML Oral Solution [Hydron CP]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 859156, drugName: 'chlorpheniramine maleate 0.4 MG/ML / hydrocodone bitartrate 1 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 859315, drugName: 'hydrocodone bitartrate 10 MG / ibuprofen 200 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 859317, drugName: 'hydrocodone bitartrate 10 MG / ibuprofen 200 MG Oral Tablet [Ibudone]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 859366, drugName: 'guaifenesin 40 MG/ML / hydrocodone bitartrate 0.5 MG/ML / phenylephrine hydrochloride 1.5 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 859368, drugName: 'guaifenesin 40 MG/ML / hydrocodone bitartrate 0.5 MG/ML / phenylephrine hydrochloride 1.5 MG/ML Oral Solution [Nariz HC]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 859376, drugName: 'guaifenesin 40 MG/ML / hydrocodone bitartrate 0.5 MG/ML / phenylephrine hydrochloride 1.5 MG/ML Oral Solution [Nazarin HC]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 859383, drugName: 'guaifenesin 40 MG/ML / hydrocodone bitartrate 0.5 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 859939, drugName: 'guaifenesin 45 MG/ML / hydrocodone bitartrate 0.5 MG/ML / phenylephrine hydrochloride 2 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 859943, drugName: 'guaifenesin 45 MG/ML / hydrocodone bitartrate 0.5 MG/ML / phenylephrine hydrochloride 2 MG/ML Oral Solution [Simuc-HD]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 860138, drugName: 'guaiacolsulfonate 30 MG/ML / hydrocodone bitartrate 0.6 MG/ML Oral Solution [De-Chlor NX]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.6 MG/ML', strengthValue: 0.6, strengthUnit: 'MG/ML' },\n  { drugCode: 860151, drugName: 'hydrocodone bitartrate 1 MG/ML / phenylephrine hydrochloride 1 MG/ML / pyrilamine maleate 1 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 860159, drugName: 'hydrocodone bitartrate 1 MG/ML / phenylephrine hydrochloride 1 MG/ML / pyrilamine maleate 1 MG/ML Oral Solution [De-Chlor MR]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 860239, drugName: 'guaifenesin 10 MG/ML / hydrocodone bitartrate 0.5 MG/ML / phenylephrine hydrochloride 1.5 MG/ML Oral Solution [Hydro GP]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 860426, drugName: 'guaifenesin 20 MG/ML / hydrocodone bitartrate 0.4 MG/ML / phenylephrine hydrochloride 2 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.4 MG/ML', strengthValue: 0.4, strengthUnit: 'MG/ML' },\n  { drugCode: 860530, drugName: 'guaifenesin 20 MG/ML / hydrocodone bitartrate 0.5 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Solution [Su-Tuss HD]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 860579, drugName: 'guaifenesin 10 MG/ML / hydrocodone bitartrate 0.75 MG/ML / pseudoephedrine hydrochloride 4.5 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.75 MG/ML', strengthValue: 0.75, strengthUnit: 'MG/ML' },\n  { drugCode: 860599, drugName: 'hydrocodone bitartrate 7.5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 860792, drugName: '1 ML meperidine hydrochloride 75 MG/ML Cartridge', doseFormCode: 1649572, doseFormName: 'Cartridge', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '75 MG/ML', strengthValue: 75.0, strengthUnit: 'MG/ML' },\n  { drugCode: 861447, drugName: 'meperidine hydrochloride 10 MG/ML Injectable Solution', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 861455, drugName: 'meperidine hydrochloride 100 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 861459, drugName: 'meperidine hydrochloride 100 MG/ML Injectable Solution', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '100 MG/ML', strengthValue: 100.0, strengthUnit: 'MG/ML' },\n  { drugCode: 861463, drugName: 'meperidine hydrochloride 50 MG/ML Injectable Solution', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '50 MG/ML', strengthValue: 50.0, strengthUnit: 'MG/ML' },\n  { drugCode: 861467, drugName: 'meperidine hydrochloride 50 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '50 MG', strengthValue: 50.0, strengthUnit: 'MG' },\n  { drugCode: 861473, drugName: '1 ML meperidine hydrochloride 50 MG/ML Cartridge', doseFormCode: 1649572, doseFormName: 'Cartridge', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '50 MG/ML', strengthValue: 50.0, strengthUnit: 'MG/ML' },\n  { drugCode: 861476, drugName: '1 ML meperidine hydrochloride 25 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '25 MG/ML', strengthValue: 25.0, strengthUnit: 'MG/ML' },\n  { drugCode: 861479, drugName: 'meperidine hydrochloride 10 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 861482, drugName: '1 ML meperidine hydrochloride 75 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '75 MG/ML', strengthValue: 75.0, strengthUnit: 'MG/ML' },\n  { drugCode: 861493, drugName: '1 ML meperidine hydrochloride 100 MG/ML Cartridge', doseFormCode: 1649572, doseFormName: 'Cartridge', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '100 MG/ML', strengthValue: 100.0, strengthUnit: 'MG/ML' },\n  { drugCode: 861494, drugName: '1 ML meperidine hydrochloride 25 MG/ML Cartridge', doseFormCode: 1649572, doseFormName: 'Cartridge', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '25 MG/ML', strengthValue: 25.0, strengthUnit: 'MG/ML' },\n  { drugCode: 861517, drugName: 'meperidine hydrochloride 100 MG Oral Tablet [Demerol]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 861520, drugName: 'meperidine hydrochloride 100 MG/ML Injectable Solution [Demerol]', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '100 MG/ML', strengthValue: 100.0, strengthUnit: 'MG/ML' },\n  { drugCode: 861522, drugName: 'meperidine hydrochloride 50 MG/ML Injectable Solution [Demerol]', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '50 MG/ML', strengthValue: 50.0, strengthUnit: 'MG/ML' },\n  { drugCode: 861525, drugName: 'meperidine hydrochloride 50 MG Oral Tablet [Demerol]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '50 MG', strengthValue: 50.0, strengthUnit: 'MG' },\n  { drugCode: 861529, drugName: '1 ML meperidine hydrochloride 50 MG/ML Cartridge [Demerol]', doseFormCode: 1649572, doseFormName: 'Cartridge', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '50 MG/ML', strengthValue: 50.0, strengthUnit: 'MG/ML' },\n  { drugCode: 861578, drugName: 'meperidine hydrochloride 50 MG / promethazine hydrochloride 25 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '50 MG', strengthValue: 50.0, strengthUnit: 'MG' },\n  { drugCode: 861617, drugName: '1 ML meperidine hydrochloride 75 MG/ML Cartridge [Demerol]', doseFormCode: 1649572, doseFormName: 'Cartridge', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '75 MG/ML', strengthValue: 75.0, strengthUnit: 'MG/ML' },\n  { drugCode: 863845, drugName: 'Abuse-Deterrent morphine sulfate 100 MG / naltrexone hydrochloride 4 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 863847, drugName: 'Abuse-Deterrent morphine sulfate 100 MG / naltrexone hydrochloride 4 MG Extended Release Oral Capsule [Embeda]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 863848, drugName: 'Abuse-Deterrent morphine sulfate 20 MG / naltrexone hydrochloride 0.8 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 863849, drugName: 'Abuse-Deterrent morphine sulfate 20 MG / naltrexone hydrochloride 0.8 MG Extended Release Oral Capsule [Embeda]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 863850, drugName: 'Abuse-Deterrent morphine sulfate 30 MG / naltrexone hydrochloride 1.2 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 863851, drugName: 'Abuse-Deterrent morphine sulfate 30 MG / naltrexone hydrochloride 1.2 MG Extended Release Oral Capsule [Embeda]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 863852, drugName: 'Abuse-Deterrent morphine sulfate 50 MG / naltrexone hydrochloride 2 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '50 MG', strengthValue: 50.0, strengthUnit: 'MG' },\n  { drugCode: 863853, drugName: 'Abuse-Deterrent morphine sulfate 50 MG / naltrexone hydrochloride 2 MG Extended Release Oral Capsule [Embeda]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '50 MG', strengthValue: 50.0, strengthUnit: 'MG' },\n  { drugCode: 863854, drugName: 'Abuse-Deterrent morphine sulfate 60 MG / naltrexone hydrochloride 2.4 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '60 MG', strengthValue: 60.0, strengthUnit: 'MG' },\n  { drugCode: 863855, drugName: 'Abuse-Deterrent morphine sulfate 60 MG / naltrexone hydrochloride 2.4 MG Extended Release Oral Capsule [Embeda]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '60 MG', strengthValue: 60.0, strengthUnit: 'MG' },\n  { drugCode: 863856, drugName: 'Abuse-Deterrent morphine sulfate 80 MG / naltrexone hydrochloride 3.2 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '80 MG', strengthValue: 80.0, strengthUnit: 'MG' },\n  { drugCode: 863857, drugName: 'Abuse-Deterrent morphine sulfate 80 MG / naltrexone hydrochloride 3.2 MG Extended Release Oral Capsule [Embeda]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '80 MG', strengthValue: 80.0, strengthUnit: 'MG' },\n  { drugCode: 864706, drugName: 'methadone hydrochloride 10 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 6813, ingredientName: 'Methadone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 864708, drugName: 'methadone hydrochloride 10 MG Oral Tablet [Dolophine]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 6813, ingredientName: 'Methadone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 864712, drugName: 'methadone hydrochloride 10 MG Oral Tablet [Methadose]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 6813, ingredientName: 'Methadone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 864714, drugName: 'methadone hydrochloride 10 MG/ML Injectable Solution', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 6813, ingredientName: 'Methadone', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 864718, drugName: 'methadone hydrochloride 5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 6813, ingredientName: 'Methadone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 864720, drugName: 'methadone hydrochloride 5 MG Oral Tablet [Dolophine]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 6813, ingredientName: 'Methadone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 864737, drugName: 'methadone hydrochloride 5 MG Oral Tablet [Methadose]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 6813, ingredientName: 'Methadone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 864761, drugName: 'methadone hydrochloride 1 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 6813, ingredientName: 'Methadone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 864769, drugName: 'methadone hydrochloride 2 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 6813, ingredientName: 'Methadone', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 864978, drugName: 'methadone hydrochloride 40 MG Tablet for Oral Suspension', doseFormCode: 1861409, doseFormName: 'Tablet for Oral Suspension', ingredientCode: 6813, ingredientName: 'Methadone', strength: '40 MG', strengthValue: 40.0, strengthUnit: 'MG' },\n  { drugCode: 864980, drugName: 'methadone hydrochloride 40 MG Tablet for Oral Suspension [Methadose]', doseFormCode: 1861409, doseFormName: 'Tablet for Oral Suspension', ingredientCode: 6813, ingredientName: 'Methadone', strength: '40 MG', strengthValue: 40.0, strengthUnit: 'MG' },\n  { drugCode: 864984, drugName: 'methadone hydrochloride 20 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 6813, ingredientName: 'Methadone', strength: '20 MG/ML', strengthValue: 20.0, strengthUnit: 'MG/ML' },\n  { drugCode: 886622, drugName: 'butorphanol tartrate 2 MG/ML Injectable Solution', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 1841, ingredientName: 'Butorphanol', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 886627, drugName: '1 ML butorphanol tartrate 1 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 1841, ingredientName: 'Butorphanol', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 886634, drugName: 'butorphanol tartrate 1 MG/ACTUAT Metered Dose Nasal Spray', doseFormCode: 1797831, doseFormName: 'Metered Dose Nasal Spray', ingredientCode: 1841, ingredientName: 'Butorphanol', strength: '1 MG/ACTUAT', strengthValue: 1.0, strengthUnit: 'MG/ACTUAT' },\n  { drugCode: 891172, drugName: 'guaifenesin 20 MG/ML / hydrocodone bitartrate 0.4 MG/ML / phenylephrine hydrochloride 2 MG/ML Oral Solution [De-Chlor G]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.4 MG/ML', strengthValue: 0.4, strengthUnit: 'MG/ML' },\n  { drugCode: 891874, drugName: 'morphine sulfate 100 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 891878, drugName: '12 HR morphine sulfate 15 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '15 MG', strengthValue: 15.0, strengthUnit: 'MG' },\n  { drugCode: 891881, drugName: 'morphine sulfate 15 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '15 MG', strengthValue: 15.0, strengthUnit: 'MG' },\n  { drugCode: 891883, drugName: '12 HR morphine sulfate 100 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 891885, drugName: '12 HR morphine sulfate 30 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 891888, drugName: 'morphine sulfate 30 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 891890, drugName: '12 HR morphine sulfate 60 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '60 MG', strengthValue: 60.0, strengthUnit: 'MG' },\n  { drugCode: 891893, drugName: 'morphine sulfate 60 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '60 MG', strengthValue: 60.0, strengthUnit: 'MG' },\n  { drugCode: 892297, drugName: '24 HR morphine sulfate 120 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '120 MG', strengthValue: 120.0, strengthUnit: 'MG' },\n  { drugCode: 892342, drugName: '24 HR morphine sulfate 30 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 892345, drugName: 'morphine sulfate 30 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 892349, drugName: '24 HR morphine sulfate 60 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '60 MG', strengthValue: 60.0, strengthUnit: 'MG' },\n  { drugCode: 892352, drugName: 'morphine sulfate 60 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '60 MG', strengthValue: 60.0, strengthUnit: 'MG' },\n  { drugCode: 892355, drugName: '24 HR morphine sulfate 90 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '90 MG', strengthValue: 90.0, strengthUnit: 'MG' },\n  { drugCode: 892473, drugName: '10 ML morphine sulfate 0.5 MG/ML Injection [Duramorph]', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 892489, drugName: '10 ML morphine sulfate 1 MG/ML Injection [Duramorph]', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 892494, drugName: 'morphine sulfate 10 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 892496, drugName: 'morphine sulfate 10 MG Extended Release Oral Capsule [Kadian]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 892516, drugName: 'morphine sulfate 10 MG Rectal Suppository', doseFormCode: 316978, doseFormName: 'Rectal Suppository', ingredientCode: 7052, ingredientName: 'Morphine', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 892531, drugName: 'morphine sulfate 10 MG/ML Injectable Solution', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 7052, ingredientName: 'Morphine', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 892554, drugName: 'morphine sulfate 100 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 892556, drugName: 'morphine sulfate 100 MG Extended Release Oral Capsule [Kadian]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 892560, drugName: 'morphine sulfate 100 MG Extended Release Oral Tablet [MS Contin]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 892574, drugName: 'morphine sulfate 15 MG Extended Release Oral Tablet [MS Contin]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '15 MG', strengthValue: 15.0, strengthUnit: 'MG' },\n  { drugCode: 892579, drugName: 'morphine sulfate 15 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '15 MG', strengthValue: 15.0, strengthUnit: 'MG' },\n  { drugCode: 892582, drugName: 'morphine sulfate 15 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '15 MG', strengthValue: 15.0, strengthUnit: 'MG' },\n  { drugCode: 892589, drugName: 'morphine sulfate 2 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 7052, ingredientName: 'Morphine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 892596, drugName: 'morphine sulfate 20 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 892598, drugName: 'morphine sulfate 20 MG Extended Release Oral Capsule [Kadian]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 892603, drugName: 'morphine sulfate 20 MG Rectal Suppository', doseFormCode: 316978, doseFormName: 'Rectal Suppository', ingredientCode: 7052, ingredientName: 'Morphine', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 892625, drugName: 'morphine sulfate 20 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 7052, ingredientName: 'Morphine', strength: '20 MG/ML', strengthValue: 20.0, strengthUnit: 'MG/ML' },\n  { drugCode: 892643, drugName: 'morphine sulfate 200 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '200 MG', strengthValue: 200.0, strengthUnit: 'MG' },\n  { drugCode: 892645, drugName: 'morphine sulfate 200 MG Extended Release Oral Capsule [Kadian]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '200 MG', strengthValue: 200.0, strengthUnit: 'MG' },\n  { drugCode: 892646, drugName: 'morphine sulfate 200 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '200 MG', strengthValue: 200.0, strengthUnit: 'MG' },\n  { drugCode: 892648, drugName: 'morphine sulfate 200 MG Extended Release Oral Tablet [MS Contin]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '200 MG', strengthValue: 200.0, strengthUnit: 'MG' },\n  { drugCode: 892652, drugName: '20 ML morphine sulfate 25 MG/ML Injection [Infumorph]', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '25 MG/ML', strengthValue: 25.0, strengthUnit: 'MG/ML' },\n  { drugCode: 892658, drugName: 'morphine sulfate 30 MG Extended Release Oral Capsule [Kadian]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 892660, drugName: 'morphine sulfate 30 MG Extended Release Oral Tablet [MS Contin]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 892669, drugName: 'morphine sulfate 30 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 892672, drugName: 'morphine sulfate 30 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 892678, drugName: 'morphine sulfate 30 MG Rectal Suppository', doseFormCode: 316978, doseFormName: 'Rectal Suppository', ingredientCode: 7052, ingredientName: 'Morphine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 894780, drugName: 'morphine sulfate 4 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 7052, ingredientName: 'Morphine', strength: '4 MG/ML', strengthValue: 4.0, strengthUnit: 'MG/ML' },\n  { drugCode: 894801, drugName: 'morphine sulfate 50 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '50 MG', strengthValue: 50.0, strengthUnit: 'MG' },\n  { drugCode: 894803, drugName: 'morphine sulfate 50 MG Extended Release Oral Capsule [Kadian]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '50 MG', strengthValue: 50.0, strengthUnit: 'MG' },\n  { drugCode: 894805, drugName: 'morphine sulfate 60 MG Extended Release Oral Capsule [Kadian]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '60 MG', strengthValue: 60.0, strengthUnit: 'MG' },\n  { drugCode: 894807, drugName: 'morphine sulfate 5 MG Rectal Suppository', doseFormCode: 316978, doseFormName: 'Rectal Suppository', ingredientCode: 7052, ingredientName: 'Morphine', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 894813, drugName: 'morphine sulfate 60 MG Extended Release Oral Tablet [MS Contin]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '60 MG', strengthValue: 60.0, strengthUnit: 'MG' },\n  { drugCode: 894814, drugName: 'morphine sulfate 80 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '80 MG', strengthValue: 80.0, strengthUnit: 'MG' },\n  { drugCode: 894816, drugName: 'morphine sulfate 80 MG Extended Release Oral Capsule [Kadian]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '80 MG', strengthValue: 80.0, strengthUnit: 'MG' },\n  { drugCode: 894911, drugName: '0.7 ML morphine sulfate 14.3 MG/ML Auto-Injector', doseFormCode: 1649570, doseFormName: 'Auto-Injector', ingredientCode: 7052, ingredientName: 'Morphine', strength: '14.3 MG/ML', strengthValue: 14.3, strengthUnit: 'MG/ML' },\n  { drugCode: 894912, drugName: '1 ML morphine sulfate 10 MG/ML Prefilled Syringe', doseFormCode: 721656, doseFormName: 'Prefilled Syringe', ingredientCode: 7052, ingredientName: 'Morphine', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 894914, drugName: '1 ML morphine sulfate 8 MG/ML Prefilled Syringe', doseFormCode: 721656, doseFormName: 'Prefilled Syringe', ingredientCode: 7052, ingredientName: 'Morphine', strength: '8 MG/ML', strengthValue: 8.0, strengthUnit: 'MG/ML' },\n  { drugCode: 894918, drugName: '12 HR morphine sulfate 200 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '200 MG', strengthValue: 200.0, strengthUnit: 'MG' },\n  { drugCode: 894942, drugName: '24 HR morphine sulfate 45 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '45 MG', strengthValue: 45.0, strengthUnit: 'MG' },\n  { drugCode: 894970, drugName: '24 HR morphine sulfate 75 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '75 MG', strengthValue: 75.0, strengthUnit: 'MG' },\n  { drugCode: 894986, drugName: 'morphine sulfate 0.4 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 7052, ingredientName: 'Morphine', strength: '0.4 MG/ML', strengthValue: 0.4, strengthUnit: 'MG/ML' },\n  { drugCode: 895014, drugName: 'morphine sulfate 10 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 895016, drugName: 'morphine sulfate 10 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 7052, ingredientName: 'Morphine', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 895022, drugName: 'morphine sulfate 100 MG Rectal Suppository', doseFormCode: 316978, doseFormName: 'Rectal Suppository', ingredientCode: 7052, ingredientName: 'Morphine', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 895185, drugName: 'morphine sulfate 15 MG Rectal Suppository', doseFormCode: 316978, doseFormName: 'Rectal Suppository', ingredientCode: 7052, ingredientName: 'Morphine', strength: '15 MG', strengthValue: 15.0, strengthUnit: 'MG' },\n  { drugCode: 895194, drugName: 'morphine sulfate 15 MG/ML Injectable Solution', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 7052, ingredientName: 'Morphine', strength: '15 MG/ML', strengthValue: 15.0, strengthUnit: 'MG/ML' },\n  { drugCode: 895199, drugName: 'morphine sulfate 2 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 7052, ingredientName: 'Morphine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 895201, drugName: 'morphine sulfate 20 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 895202, drugName: 'morphine sulfate 20 MG/ML Injectable Solution', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 7052, ingredientName: 'Morphine', strength: '20 MG/ML', strengthValue: 20.0, strengthUnit: 'MG/ML' },\n  { drugCode: 895206, drugName: 'morphine sulfate 200 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '200 MG', strengthValue: 200.0, strengthUnit: 'MG' },\n  { drugCode: 895208, drugName: 'morphine sulfate 3 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 7052, ingredientName: 'Morphine', strength: '3 MG/ML', strengthValue: 3.0, strengthUnit: 'MG/ML' },\n  { drugCode: 895213, drugName: 'morphine sulfate 30 MG/ML Injectable Solution', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 7052, ingredientName: 'Morphine', strength: '30 MG/ML', strengthValue: 30.0, strengthUnit: 'MG/ML' },\n  { drugCode: 895215, drugName: 'morphine sulfate 35 MG Rectal Suppository', doseFormCode: 316978, doseFormName: 'Rectal Suppository', ingredientCode: 7052, ingredientName: 'Morphine', strength: '35 MG', strengthValue: 35.0, strengthUnit: 'MG' },\n  { drugCode: 895217, drugName: 'morphine sulfate 5 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 895219, drugName: 'morphine sulfate 5 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 7052, ingredientName: 'Morphine', strength: '5 MG/ML', strengthValue: 5.0, strengthUnit: 'MG/ML' },\n  { drugCode: 895221, drugName: 'morphine sulfate 50 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '50 MG', strengthValue: 50.0, strengthUnit: 'MG' },\n  { drugCode: 895227, drugName: 'morphine sulfate 50 MG Rectal Suppository', doseFormCode: 316978, doseFormName: 'Rectal Suppository', ingredientCode: 7052, ingredientName: 'Morphine', strength: '50 MG', strengthValue: 50.0, strengthUnit: 'MG' },\n  { drugCode: 895238, drugName: 'morphine sulfate 6 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 7052, ingredientName: 'Morphine', strength: '6 MG/ML', strengthValue: 6.0, strengthUnit: 'MG/ML' },\n  { drugCode: 895240, drugName: 'morphine sulfate 6.67 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 7052, ingredientName: 'Morphine', strength: '6.67 MG/ML', strengthValue: 6.67, strengthUnit: 'MG/ML' },\n  { drugCode: 895247, drugName: 'morphine sulfate 60 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '60 MG', strengthValue: 60.0, strengthUnit: 'MG' },\n  { drugCode: 895248, drugName: 'morphine sulfate 75 MG Rectal Suppository', doseFormCode: 316978, doseFormName: 'Rectal Suppository', ingredientCode: 7052, ingredientName: 'Morphine', strength: '75 MG', strengthValue: 75.0, strengthUnit: 'MG' },\n  { drugCode: 895975, drugName: 'morphine sulfate liposomal 10 MG/ML Injectable Solution', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 7052, ingredientName: 'Morphine', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 897653, drugName: '1 ML hydromorphone hydrochloride 1 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 897657, drugName: 'hydromorphone hydrochloride 1 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 897658, drugName: 'hydromorphone hydrochloride 1 MG/ML Oral Solution [Dilaudid]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 897696, drugName: 'hydromorphone hydrochloride 2 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '2 MG', strengthValue: 2.0, strengthUnit: 'MG' },\n  { drugCode: 897698, drugName: 'hydromorphone hydrochloride 2 MG Oral Tablet [Dilaudid]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '2 MG', strengthValue: 2.0, strengthUnit: 'MG' },\n  { drugCode: 897702, drugName: 'hydromorphone hydrochloride 4 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '4 MG', strengthValue: 4.0, strengthUnit: 'MG' },\n  { drugCode: 897704, drugName: 'hydromorphone hydrochloride 4 MG Oral Tablet [Dilaudid]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '4 MG', strengthValue: 4.0, strengthUnit: 'MG' },\n  { drugCode: 897710, drugName: 'hydromorphone hydrochloride 8 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '8 MG', strengthValue: 8.0, strengthUnit: 'MG' },\n  { drugCode: 897712, drugName: 'hydromorphone hydrochloride 8 MG Oral Tablet [Dilaudid]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '8 MG', strengthValue: 8.0, strengthUnit: 'MG' },\n  { drugCode: 897745, drugName: 'hydromorphone hydrochloride 2 MG/ML Injectable Solution', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 897749, drugName: 'hydromorphone hydrochloride 3 MG Rectal Suppository', doseFormCode: 316978, doseFormName: 'Rectal Suppository', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '3 MG', strengthValue: 3.0, strengthUnit: 'MG' },\n  { drugCode: 897753, drugName: '1 ML hydromorphone hydrochloride 4 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '4 MG/ML', strengthValue: 4.0, strengthUnit: 'MG/ML' },\n  { drugCode: 897756, drugName: '1 ML hydromorphone hydrochloride 1 MG/ML Prefilled Syringe', doseFormCode: 721656, doseFormName: 'Prefilled Syringe', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 897757, drugName: '1 ML hydromorphone hydrochloride 2 MG/ML Prefilled Syringe', doseFormCode: 721656, doseFormName: 'Prefilled Syringe', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 897758, drugName: '1 ML hydromorphone hydrochloride 4 MG/ML Cartridge', doseFormCode: 1649572, doseFormName: 'Cartridge', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '4 MG/ML', strengthValue: 4.0, strengthUnit: 'MG/ML' },\n  { drugCode: 897771, drugName: 'hydromorphone hydrochloride 1 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '1 MG', strengthValue: 1.0, strengthUnit: 'MG' },\n  { drugCode: 898004, drugName: 'hydromorphone hydrochloride 1.3 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '1.3 MG', strengthValue: 1.3, strengthUnit: 'MG' },\n  { drugCode: 898138, drugName: 'hydromorphone hydrochloride 2.6 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '2.6 MG', strengthValue: 2.6, strengthUnit: 'MG' },\n  { drugCode: 898139, drugName: 'hydromorphone hydrochloride 3 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '3 MG', strengthValue: 3.0, strengthUnit: 'MG' },\n  { drugCode: 898611, drugName: '12 HR hydromorphone hydrochloride 2 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '2 MG', strengthValue: 2.0, strengthUnit: 'MG' },\n  { drugCode: 898614, drugName: '12 HR hydromorphone hydrochloride 4 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '4 MG', strengthValue: 4.0, strengthUnit: 'MG' },\n  { drugCode: 898618, drugName: '12 HR hydromorphone hydrochloride 8 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '8 MG', strengthValue: 8.0, strengthUnit: 'MG' },\n  { drugCode: 902729, drugName: '24 HR hydromorphone hydrochloride 12 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '12 MG', strengthValue: 12.0, strengthUnit: 'MG' },\n  { drugCode: 902733, drugName: '24 HR hydromorphone hydrochloride 12 MG Extended Release Oral Tablet [Exalgo]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '12 MG', strengthValue: 12.0, strengthUnit: 'MG' },\n  { drugCode: 902736, drugName: '24 HR hydromorphone hydrochloride 16 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '16 MG', strengthValue: 16.0, strengthUnit: 'MG' },\n  { drugCode: 902738, drugName: '24 HR hydromorphone hydrochloride 16 MG Extended Release Oral Tablet [Exalgo]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '16 MG', strengthValue: 16.0, strengthUnit: 'MG' },\n  { drugCode: 902741, drugName: '24 HR hydromorphone hydrochloride 8 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '8 MG', strengthValue: 8.0, strengthUnit: 'MG' },\n  { drugCode: 902743, drugName: '24 HR hydromorphone hydrochloride 8 MG Extended Release Oral Tablet [Exalgo]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '8 MG', strengthValue: 8.0, strengthUnit: 'MG' },\n  { drugCode: 904415, drugName: 'nalbuphine hydrochloride 10 MG/ML Injectable Solution', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 7238, ingredientName: 'Nalbuphine', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 904440, drugName: 'nalbuphine hydrochloride 20 MG/ML Injectable Solution', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 7238, ingredientName: 'Nalbuphine', strength: '20 MG/ML', strengthValue: 20.0, strengthUnit: 'MG/ML' },\n  { drugCode: 904870, drugName: '168 HR buprenorphine 0.01 MG/HR Transdermal System', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.01 MG/HR', strengthValue: 0.01, strengthUnit: 'MG/HR' },\n  { drugCode: 904874, drugName: '168 HR buprenorphine 0.01 MG/HR Transdermal System [BuTrans]', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.01 MG/HR', strengthValue: 0.01, strengthUnit: 'MG/HR' },\n  { drugCode: 904876, drugName: '168 HR buprenorphine 0.02 MG/HR Transdermal System', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.02 MG/HR', strengthValue: 0.02, strengthUnit: 'MG/HR' },\n  { drugCode: 904878, drugName: '168 HR buprenorphine 0.02 MG/HR Transdermal System [BuTrans]', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.02 MG/HR', strengthValue: 0.02, strengthUnit: 'MG/HR' },\n  { drugCode: 904880, drugName: '168 HR buprenorphine 0.005 MG/HR Transdermal System', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.005 MG/HR', strengthValue: 0.005, strengthUnit: 'MG/HR' },\n  { drugCode: 904882, drugName: '168 HR buprenorphine 0.005 MG/HR Transdermal System [BuTrans]', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.005 MG/HR', strengthValue: 0.005, strengthUnit: 'MG/HR' },\n  { drugCode: 977874, drugName: '12 HR oxymorphone hydrochloride 10 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7814, ingredientName: 'Oxymorphone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 977894, drugName: '12 HR oxymorphone hydrochloride 15 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7814, ingredientName: 'Oxymorphone', strength: '15 MG', strengthValue: 15.0, strengthUnit: 'MG' },\n  { drugCode: 977902, drugName: '12 HR oxymorphone hydrochloride 20 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7814, ingredientName: 'Oxymorphone', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 977909, drugName: '12 HR oxymorphone hydrochloride 30 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7814, ingredientName: 'Oxymorphone', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 977915, drugName: '12 HR oxymorphone hydrochloride 40 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7814, ingredientName: 'Oxymorphone', strength: '40 MG', strengthValue: 40.0, strengthUnit: 'MG' },\n  { drugCode: 977923, drugName: '12 HR oxymorphone hydrochloride 5 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7814, ingredientName: 'Oxymorphone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 977929, drugName: '12 HR oxymorphone hydrochloride 7.5 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7814, ingredientName: 'Oxymorphone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 977935, drugName: '1 ML oxymorphone hydrochloride 1 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7814, ingredientName: 'Oxymorphone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 977937, drugName: '1 ML oxymorphone hydrochloride 1 MG/ML Injection [Opana]', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7814, ingredientName: 'Oxymorphone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 977939, drugName: 'oxymorphone hydrochloride 5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7814, ingredientName: 'Oxymorphone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 977940, drugName: 'oxymorphone hydrochloride 5 MG Oral Tablet [Opana]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7814, ingredientName: 'Oxymorphone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 977942, drugName: 'oxymorphone hydrochloride 10 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7814, ingredientName: 'Oxymorphone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 977943, drugName: 'oxymorphone hydrochloride 10 MG Oral Tablet [Opana]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7814, ingredientName: 'Oxymorphone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 991147, drugName: 'methadone hydrochloride 10 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 6813, ingredientName: 'Methadone', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 991149, drugName: 'methadone hydrochloride 10 MG/ML Oral Solution [Methadose]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 6813, ingredientName: 'Methadone', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 991486, drugName: 'codeine phosphate 2 MG/ML / promethazine hydrochloride 1.25 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 992656, drugName: 'homatropine methylbromide 1.5 MG / hydrocodone bitartrate 5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 992668, drugName: 'homatropine methylbromide 0.3 MG/ML / hydrocodone bitartrate 1 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 992671, drugName: 'homatropine methylbromide 0.3 MG/ML / hydrocodone bitartrate 1 MG/ML Oral Solution [Hycodan]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 992675, drugName: 'homatropine methylbromide 0.3 MG/ML / hydrocodone bitartrate 1 MG/ML Oral Solution [Hydromet]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 992733, drugName: 'homatropine methylbromide 1.5 MG / hydrocodone bitartrate 5 MG Oral Tablet [Tussigon]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 993755, drugName: 'acetaminophen 24 MG/ML / codeine phosphate 2.4 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2.4 MG/ML', strengthValue: 2.4, strengthUnit: 'MG/ML' },\n  { drugCode: 993763, drugName: 'acetaminophen 24 MG/ML / codeine phosphate 2.4 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2.4 MG/ML', strengthValue: 2.4, strengthUnit: 'MG/ML' },\n  { drugCode: 993767, drugName: 'acetaminophen 24 MG/ML / codeine phosphate 2.4 MG/ML Oral Suspension [Capital and Codeine]', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2.4 MG/ML', strengthValue: 2.4, strengthUnit: 'MG/ML' },\n  { drugCode: 993770, drugName: 'acetaminophen 300 MG / codeine phosphate 15 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '15 MG', strengthValue: 15.0, strengthUnit: 'MG' },\n  { drugCode: 993781, drugName: 'acetaminophen 300 MG / codeine phosphate 30 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 993837, drugName: 'acetaminophen 300 MG / codeine phosphate 30 MG Oral Tablet [Tylenol with Codeine]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 993890, drugName: 'acetaminophen 300 MG / codeine phosphate 60 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '60 MG', strengthValue: 60.0, strengthUnit: 'MG' },\n  { drugCode: 993892, drugName: 'acetaminophen 300 MG / codeine phosphate 60 MG Oral Tablet [Tylenol with Codeine]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '60 MG', strengthValue: 60.0, strengthUnit: 'MG' },\n  { drugCode: 993943, drugName: 'acetaminophen 325 MG / butalbital 50 MG / caffeine 40 MG / codeine phosphate 30 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 2670, ingredientName: 'Codeine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 994043, drugName: 'acetaminophen 500 MG / codeine phosphate 15 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '15 MG', strengthValue: 15.0, strengthUnit: 'MG' },\n  { drugCode: 994046, drugName: 'acetaminophen 500 MG / codeine phosphate 30 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 994226, drugName: 'aspirin 325 MG / carisoprodol 200 MG / codeine phosphate 16 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '16 MG', strengthValue: 16.0, strengthUnit: 'MG' },\n  { drugCode: 994237, drugName: 'aspirin 325 MG / butalbital 50 MG / caffeine 40 MG / codeine phosphate 30 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 2670, ingredientName: 'Codeine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 994239, drugName: 'aspirin 325 MG / butalbital 50 MG / caffeine 40 MG / codeine phosphate 30 MG Oral Capsule [Ascomp]', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 2670, ingredientName: 'Codeine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 994277, drugName: 'aspirin 325 MG / butalbital 50 MG / caffeine 40 MG / codeine phosphate 30 MG Oral Capsule [Fiorinal with Codeine]', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 2670, ingredientName: 'Codeine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 994289, drugName: 'brompheniramine maleate 0.27 MG/ML / codeine phosphate 1.27 MG/ML / pseudoephedrine hydrochloride 2 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.27 MG/ML', strengthValue: 1.27, strengthUnit: 'MG/ML' },\n  { drugCode: 994402, drugName: 'brompheniramine maleate 0.4 MG/ML / codeine phosphate 1.5 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.5 MG/ML', strengthValue: 1.5, strengthUnit: 'MG/ML' },\n  { drugCode: 994404, drugName: 'brompheniramine maleate 0.4 MG/ML / codeine phosphate 1.5 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Solution [Mar-cof BP]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.5 MG/ML', strengthValue: 1.5, strengthUnit: 'MG/ML' },\n  { drugCode: 995041, drugName: 'chlorpheniramine maleate 0.2 MG/ML / codeine phosphate 1 MG/ML / pseudoephedrine hydrochloride 3 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995043, drugName: 'chlorpheniramine maleate 0.2 MG/ML / codeine phosphate 1 MG/ML / pseudoephedrine hydrochloride 3 MG/ML Oral Suspension [Zodryl DAC]', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995062, drugName: 'chlorpheniramine maleate 0.2 MG/ML / codeine phosphate 1 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995064, drugName: 'chlorpheniramine maleate 0.2 MG/ML / codeine phosphate 1 MG/ML Oral Suspension [Zodryl AC]', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995065, drugName: 'chlorpheniramine maleate 0.222 MG/ML / codeine phosphate 1 MG/ML / pseudoephedrine hydrochloride 3.33 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995067, drugName: 'chlorpheniramine maleate 0.222 MG/ML / codeine phosphate 1 MG/ML / pseudoephedrine hydrochloride 3.33 MG/ML Oral Suspension [Zodryl DAC]', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995068, drugName: 'chlorpheniramine maleate 0.222 MG/ML / codeine phosphate 1 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995070, drugName: 'chlorpheniramine maleate 0.222 MG/ML / codeine phosphate 1 MG/ML Oral Suspension [Zodryl AC]', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995071, drugName: 'chlorpheniramine maleate 0.25 MG/ML / codeine phosphate 1 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995073, drugName: 'chlorpheniramine maleate 0.25 MG/ML / codeine phosphate 1 MG/ML Oral Suspension [Zodryl AC]', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995075, drugName: 'chlorpheniramine maleate 0.25 MG/ML / codeine phosphate 1 MG/ML / pseudoephedrine hydrochloride 0.375 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995077, drugName: 'chlorpheniramine maleate 0.25 MG/ML / codeine phosphate 1 MG/ML / pseudoephedrine hydrochloride 0.375 MG/ML Oral Suspension [Zodryl DAC]', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995079, drugName: 'chlorpheniramine maleate 0.266 MG/ML / codeine phosphate 1 MG/ML / pseudoephedrine hydrochloride 4 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995081, drugName: 'chlorpheniramine maleate 0.266 MG/ML / codeine phosphate 1 MG/ML / pseudoephedrine hydrochloride 4 MG/ML Oral Suspension [Zodryl DAC]', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995082, drugName: 'chlorpheniramine maleate 0.267 MG/ML / codeine phosphate 1 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995084, drugName: 'chlorpheniramine maleate 0.267 MG/ML / codeine phosphate 1 MG/ML Oral Suspension [Zodryl AC]', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995086, drugName: 'chlorpheniramine maleate 0.286 MG/ML / codeine phosphate 1 MG/ML / pseudoephedrine hydrochloride 4.29 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995088, drugName: 'chlorpheniramine maleate 0.286 MG/ML / codeine phosphate 1 MG/ML / pseudoephedrine hydrochloride 4.29 MG/ML Oral Suspension [Zodryl DAC]', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995093, drugName: 'chlorpheniramine maleate 0.286 MG/ML / codeine phosphate 1 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995095, drugName: 'chlorpheniramine maleate 0.286 MG/ML / codeine phosphate 1 MG/ML Oral Suspension [Zodryl AC]', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995108, drugName: 'chlorpheniramine maleate 0.333 MG/ML / codeine phosphate 1 MG/ML / pseudoephedrine hydrochloride 5 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995110, drugName: 'chlorpheniramine maleate 0.333 MG/ML / codeine phosphate 1 MG/ML / pseudoephedrine hydrochloride 5 MG/ML Oral Suspension [Zodryl DAC]', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995116, drugName: 'chlorpheniramine maleate 0.333 MG/ML / codeine phosphate 1 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995118, drugName: 'chlorpheniramine maleate 0.333 MG/ML / codeine phosphate 1 MG/ML Oral Suspension [Zodryl AC]', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995120, drugName: 'chlorpheniramine maleate 0.4 MG/ML / codeine phosphate 1 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995122, drugName: 'chlorpheniramine maleate 0.4 MG/ML / codeine phosphate 1 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Suspension [Zodryl DAC]', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995123, drugName: 'chlorpheniramine maleate 0.4 MG/ML / codeine phosphate 1 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995125, drugName: 'chlorpheniramine maleate 0.4 MG/ML / codeine phosphate 1 MG/ML Oral Suspension [Zodryl AC]', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995128, drugName: 'chlorpheniramine maleate 0.4 MG/ML / codeine phosphate 1.8 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.8 MG/ML', strengthValue: 1.8, strengthUnit: 'MG/ML' },\n  { drugCode: 995132, drugName: 'chlorpheniramine maleate 0.4 MG/ML / codeine phosphate 1.8 MG/ML Oral Solution [Z Tuss AC]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.8 MG/ML', strengthValue: 1.8, strengthUnit: 'MG/ML' },\n  { drugCode: 995226, drugName: 'codeine phosphate 0.5 MG/ML / guaifenesin 15 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 995438, drugName: 'codeine phosphate 1.26 MG/ML / guaifenesin 20 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.26 MG/ML', strengthValue: 1.26, strengthUnit: 'MG/ML' },\n  { drugCode: 995440, drugName: 'codeine phosphate 1.26 MG/ML / guaifenesin 20 MG/ML Oral Solution [M-Clear WC]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.26 MG/ML', strengthValue: 1.26, strengthUnit: 'MG/ML' },\n  { drugCode: 995441, drugName: 'codeine phosphate 1.5 MG/ML / guaifenesin 45 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.5 MG/ML', strengthValue: 1.5, strengthUnit: 'MG/ML' },\n  { drugCode: 995443, drugName: 'codeine phosphate 1.5 MG/ML / guaifenesin 45 MG/ML Oral Solution [Mar-cof CG]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.5 MG/ML', strengthValue: 1.5, strengthUnit: 'MG/ML' },\n  { drugCode: 995447, drugName: 'codeine phosphate 1.8 MG/ML / pyrilamine maleate 1.67 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.8 MG/ML', strengthValue: 1.8, strengthUnit: 'MG/ML' },\n  { drugCode: 995450, drugName: 'codeine phosphate 10 MG / guaifenesin 300 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 995483, drugName: 'codeine phosphate 2 MG/ML / guaifenesin 40 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995868, drugName: 'codeine phosphate 2 MG/ML / guaifenesin 20 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995872, drugName: 'codeine phosphate 2 MG/ML / guaifenesin 20 MG/ML Oral Solution [Cheratussin]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995936, drugName: 'codeine phosphate 10 MG / guaifenesin 300 MG Oral Tablet [Brontex]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 995940, drugName: 'codeine phosphate 0.5 MG/ML / guaifenesin 15 MG/ML Oral Solution [Brontex]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 995956, drugName: 'codeine phosphate 2 MG/ML / guaifenesin 20 MG/ML Oral Solution [Cheracol with Codeine]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995983, drugName: 'codeine phosphate 2 MG/ML / guaifenesin 20 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995985, drugName: 'codeine phosphate 2 MG/ML / guaifenesin 20 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Solution [Biotussin]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 995993, drugName: 'codeine phosphate 2 MG/ML / guaifenesin 20 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Solution [Cheratussin DAC]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 996462, drugName: 'codeine phosphate 2 MG/ML / guaifenesin 20 MG/ML Oral Solution [Guiatuss AC]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 996481, drugName: 'codeine phosphate 2 MG/ML / guaifenesin 20 MG/ML Oral Solution [Mytussin AC]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 996484, drugName: 'codeine phosphate 2 MG/ML / guaifenesin 20 MG/ML Oral Solution [Robafen AC]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 996512, drugName: 'codeine phosphate 2 MG/ML / guaifenesin 60 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 996580, drugName: 'codeine phosphate 2 MG/ML / phenylephrine hydrochloride 1 MG/ML / pyrilamine maleate 1 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 996584, drugName: 'codeine phosphate 2 MG/ML / phenylephrine hydrochloride 1 MG/ML / pyrilamine maleate 1 MG/ML Oral Solution [Zotex C]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 996655, drugName: 'codeine phosphate 2 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 996706, drugName: 'codeine phosphate 20 MG / guaifenesin 400 MG / phenylephrine hydrochloride 10 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 996708, drugName: 'codeine phosphate 20 MG / guaifenesin 400 MG / phenylephrine hydrochloride 10 MG Oral Tablet [Maxiphen CDX]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 996710, drugName: 'codeine phosphate 20 MG / guaifenesin 400 MG / pseudoephedrine hydrochloride 20 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 996712, drugName: 'codeine phosphate 20 MG / guaifenesin 400 MG / pseudoephedrine hydrochloride 20 MG Oral Tablet [Ambifed-G CD]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 996714, drugName: 'codeine phosphate 20 MG / guaifenesin 400 MG / pseudoephedrine hydrochloride 30 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 996716, drugName: 'codeine phosphate 20 MG / guaifenesin 400 MG / pseudoephedrine hydrochloride 30 MG Oral Tablet [Ambifed CD]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 996725, drugName: 'codeine phosphate 20 MG / guaifenesin 400 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 996727, drugName: 'codeine phosphate 20 MG / guaifenesin 400 MG Oral Tablet [Allfen CDX]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 996728, drugName: 'codeine phosphate 20 MG / pseudoephedrine hydrochloride 60 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 2670, ingredientName: 'Codeine', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 996730, drugName: 'codeine phosphate 20 MG / pseudoephedrine hydrochloride 60 MG Oral Capsule [Nucofed]', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 2670, ingredientName: 'Codeine', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 996734, drugName: 'codeine phosphate 5 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '5 MG/ML', strengthValue: 5.0, strengthUnit: 'MG/ML' },\n  { drugCode: 996736, drugName: 'codeine phosphate 9 MG / guaifenesin 200 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 2670, ingredientName: 'Codeine', strength: '9 MG', strengthValue: 9.0, strengthUnit: 'MG' },\n  { drugCode: 996738, drugName: 'codeine phosphate 9 MG / guaifenesin 200 MG Oral Capsule [M-Clear WC]', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 2670, ingredientName: 'Codeine', strength: '9 MG', strengthValue: 9.0, strengthUnit: 'MG' },\n  { drugCode: 996757, drugName: 'codeine phosphate 2 MG/ML / phenylephrine hydrochloride 1 MG/ML / promethazine hydrochloride 1.25 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 996976, drugName: 'acetaminophen 500 MG / codeine phosphate 12.8 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '12.8 MG', strengthValue: 12.8, strengthUnit: 'MG' },\n  { drugCode: 996978, drugName: 'acetaminophen 500 MG / codeine phosphate 13.5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '13.5 MG', strengthValue: 13.5, strengthUnit: 'MG' },\n  { drugCode: 996979, drugName: 'acetaminophen 500 MG / codeine phosphate 30 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 2670, ingredientName: 'Codeine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 996981, drugName: 'acetaminophen 500 MG / codeine phosphate 8 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 2670, ingredientName: 'Codeine', strength: '8 MG', strengthValue: 8.0, strengthUnit: 'MG' },\n  { drugCode: 996982, drugName: 'acetaminophen 500 MG / codeine phosphate 8 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '8 MG', strengthValue: 8.0, strengthUnit: 'MG' },\n  { drugCode: 996988, drugName: 'aspirin 300 MG / codeine phosphate 8 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '8 MG', strengthValue: 8.0, strengthUnit: 'MG' },\n  { drugCode: 996991, drugName: 'aspirin 325 MG / codeine phosphate 30 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 996994, drugName: 'aspirin 325 MG / codeine phosphate 60 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '60 MG', strengthValue: 60.0, strengthUnit: 'MG' },\n  { drugCode: 996998, drugName: 'brompheniramine maleate 0.266 MG/ML / codeine phosphate 1.27 MG/ML / phenylephrine hydrochloride 0.666 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.27 MG/ML', strengthValue: 1.27, strengthUnit: 'MG/ML' },\n  { drugCode: 997019, drugName: 'codeine phosphate 1 MG/ML / kaolin 300 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 997164, drugName: 'codeine phosphate 12.5 MG / ibuprofen 200 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '12.5 MG', strengthValue: 12.5, strengthUnit: 'MG' },\n  { drugCode: 997165, drugName: 'codeine phosphate 12.8 MG / ibuprofen 200 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '12.8 MG', strengthValue: 12.8, strengthUnit: 'MG' },\n  { drugCode: 997169, drugName: 'codeine phosphate 15 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '15 MG', strengthValue: 15.0, strengthUnit: 'MG' },\n  { drugCode: 997170, drugName: 'codeine sulfate 15 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '15 MG', strengthValue: 15.0, strengthUnit: 'MG' },\n  { drugCode: 997280, drugName: 'codeine phosphate 20 MG / ibuprofen 300 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 997284, drugName: 'codeine phosphate 3 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '3 MG/ML', strengthValue: 3.0, strengthUnit: 'MG/ML' },\n  { drugCode: 997285, drugName: 'codeine phosphate 30 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 997287, drugName: 'codeine sulfate 30 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 997296, drugName: 'codeine sulfate 60 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '60 MG', strengthValue: 60.0, strengthUnit: 'MG' },\n  { drugCode: 997301, drugName: 'codeine phosphate 60 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '60 MG', strengthValue: 60.0, strengthUnit: 'MG' },\n  { drugCode: 997303, drugName: 'codeine phosphate 60 MG/ML Injectable Solution', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '60 MG/ML', strengthValue: 60.0, strengthUnit: 'MG/ML' },\n  { drugCode: 998212, drugName: '1 ML morphine sulfate 2 MG/ML Prefilled Syringe', doseFormCode: 721656, doseFormName: 'Prefilled Syringe', ingredientCode: 7052, ingredientName: 'Morphine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 998213, drugName: '1 ML morphine sulfate 4 MG/ML Prefilled Syringe', doseFormCode: 721656, doseFormName: 'Prefilled Syringe', ingredientCode: 7052, ingredientName: 'Morphine', strength: '4 MG/ML', strengthValue: 4.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1010600, drugName: 'buprenorphine 2 MG / naloxone 0.5 MG Sublingual Film', doseFormCode: 2269578, doseFormName: 'Sublingual Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '2 MG', strengthValue: 2.0, strengthUnit: 'MG' },\n  { drugCode: 1010603, drugName: 'buprenorphine 2 MG / naloxone 0.5 MG Sublingual Film [Suboxone]', doseFormCode: 2269578, doseFormName: 'Sublingual Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '2 MG', strengthValue: 2.0, strengthUnit: 'MG' },\n  { drugCode: 1010604, drugName: 'buprenorphine 8 MG / naloxone 2 MG Sublingual Film', doseFormCode: 2269578, doseFormName: 'Sublingual Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '8 MG', strengthValue: 8.0, strengthUnit: 'MG' },\n  { drugCode: 1010606, drugName: 'buprenorphine 8 MG / naloxone 2 MG Sublingual Film [Suboxone]', doseFormCode: 2269578, doseFormName: 'Sublingual Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '8 MG', strengthValue: 8.0, strengthUnit: 'MG' },\n  { drugCode: 1014599, drugName: 'acetaminophen 300 MG / oxycodone hydrochloride 10 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1014615, drugName: 'acetaminophen 300 MG / oxycodone hydrochloride 5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 1014632, drugName: 'acetaminophen 300 MG / oxycodone hydrochloride 7.5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 1037259, drugName: 'acetaminophen 300 MG / oxycodone hydrochloride 2.5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '2.5 MG', strengthValue: 2.5, strengthUnit: 'MG' },\n  { drugCode: 1042693, drugName: 'chlorpheniramine maleate 0.4 MG/ML / codeine phosphate 2 MG/ML / phenylephrine hydrochloride 1 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1044427, drugName: 'acetaminophen 20 MG/ML / hydrocodone bitartrate 0.667 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.667 MG/ML', strengthValue: 0.667, strengthUnit: 'MG/ML' },\n  { drugCode: 1049214, drugName: 'acetaminophen 325 MG / oxycodone hydrochloride 10 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1049216, drugName: 'acetaminophen 325 MG / oxycodone hydrochloride 10 MG Oral Tablet [Endocet]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1049221, drugName: 'acetaminophen 325 MG / oxycodone hydrochloride 5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 1049223, drugName: 'acetaminophen 325 MG / oxycodone hydrochloride 5 MG Oral Tablet [Endocet]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 1049225, drugName: 'acetaminophen 325 MG / oxycodone hydrochloride 7.5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 1049227, drugName: 'acetaminophen 325 MG / oxycodone hydrochloride 7.5 MG Oral Tablet [Endocet]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 1049233, drugName: 'acetaminophen 500 MG / oxycodone hydrochloride 7.5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 1049251, drugName: 'acetaminophen 400 MG / oxycodone hydrochloride 10 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1049260, drugName: 'acetaminophen 400 MG / oxycodone hydrochloride 5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 1049267, drugName: 'acetaminophen 400 MG / oxycodone hydrochloride 7.5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 1049270, drugName: 'acetaminophen 650 MG / oxycodone hydrochloride 10 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1049502, drugName: '12 HR oxycodone hydrochloride 10 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1049504, drugName: 'Abuse-Deterrent 12 HR oxycodone hydrochloride 10 MG Extended Release Oral Tablet [Oxycontin]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1049543, drugName: '12 HR oxycodone hydrochloride 15 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '15 MG', strengthValue: 15.0, strengthUnit: 'MG' },\n  { drugCode: 1049545, drugName: 'Abuse-Deterrent 12 HR oxycodone hydrochloride 15 MG Extended Release Oral Tablet [Oxycontin]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '15 MG', strengthValue: 15.0, strengthUnit: 'MG' },\n  { drugCode: 1049563, drugName: '12 HR oxycodone hydrochloride 20 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 1049565, drugName: 'Abuse-Deterrent 12 HR oxycodone hydrochloride 20 MG Extended Release Oral Tablet [Oxycontin]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 1049574, drugName: '12 HR oxycodone hydrochloride 30 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 1049576, drugName: 'Abuse-Deterrent 12 HR oxycodone hydrochloride 30 MG Extended Release Oral Tablet [Oxycontin]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 1049580, drugName: 'acetaminophen 65 MG/ML / oxycodone hydrochloride 1 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1049584, drugName: '12 HR oxycodone hydrochloride 40 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '40 MG', strengthValue: 40.0, strengthUnit: 'MG' },\n  { drugCode: 1049586, drugName: 'Abuse-Deterrent 12 HR oxycodone hydrochloride 40 MG Extended Release Oral Tablet [Oxycontin]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '40 MG', strengthValue: 40.0, strengthUnit: 'MG' },\n  { drugCode: 1049589, drugName: 'ibuprofen 400 MG / oxycodone hydrochloride 5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 1049593, drugName: '12 HR oxycodone hydrochloride 60 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '60 MG', strengthValue: 60.0, strengthUnit: 'MG' },\n  { drugCode: 1049595, drugName: 'Abuse-Deterrent 12 HR oxycodone hydrochloride 60 MG Extended Release Oral Tablet [Oxycontin]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '60 MG', strengthValue: 60.0, strengthUnit: 'MG' },\n  { drugCode: 1049599, drugName: '12 HR oxycodone hydrochloride 80 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '80 MG', strengthValue: 80.0, strengthUnit: 'MG' },\n  { drugCode: 1049601, drugName: 'Abuse-Deterrent 12 HR oxycodone hydrochloride 80 MG Extended Release Oral Tablet [Oxycontin]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '80 MG', strengthValue: 80.0, strengthUnit: 'MG' },\n  { drugCode: 1049604, drugName: 'oxycodone hydrochloride 1 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1049611, drugName: 'oxycodone hydrochloride 15 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '15 MG', strengthValue: 15.0, strengthUnit: 'MG' },\n  { drugCode: 1049613, drugName: 'oxycodone hydrochloride 15 MG Oral Tablet [Roxicodone]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '15 MG', strengthValue: 15.0, strengthUnit: 'MG' },\n  { drugCode: 1049615, drugName: 'oxycodone hydrochloride 20 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '20 MG/ML', strengthValue: 20.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1049618, drugName: 'oxycodone hydrochloride 30 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 1049620, drugName: 'oxycodone hydrochloride 30 MG Oral Tablet [Roxicodone]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 1049621, drugName: 'oxycodone hydrochloride 5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 1049623, drugName: 'oxycodone hydrochloride 5 MG Oral Tablet [Roxicodone]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 1049625, drugName: 'acetaminophen 325 MG / oxycodone hydrochloride 10 MG Oral Tablet [Percocet]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1049635, drugName: 'acetaminophen 325 MG / oxycodone hydrochloride 2.5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '2.5 MG', strengthValue: 2.5, strengthUnit: 'MG' },\n  { drugCode: 1049637, drugName: 'acetaminophen 325 MG / oxycodone hydrochloride 2.5 MG Oral Tablet [Percocet]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '2.5 MG', strengthValue: 2.5, strengthUnit: 'MG' },\n  { drugCode: 1049640, drugName: 'acetaminophen 325 MG / oxycodone hydrochloride 5 MG Oral Tablet [Percocet]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 1049642, drugName: 'acetaminophen 325 MG / oxycodone hydrochloride 7.5 MG Oral Tablet [Percocet]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 1049651, drugName: 'acetaminophen 500 MG / oxycodone hydrochloride 10 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1049658, drugName: 'acetaminophen 500 MG / oxycodone hydrochloride 5 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 1049683, drugName: 'oxycodone hydrochloride 10 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1049686, drugName: 'oxycodone hydrochloride 20 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 1049696, drugName: 'oxycodone hydrochloride 5 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 1049717, drugName: 'oxycodone hydrochloride 10 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1049719, drugName: 'oxycodone hydrochloride 10 MG/ML Injectable Solution', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1049720, drugName: 'oxycodone hydrochloride 10 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1049721, drugName: 'oxycodone hydrochloride 20 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 1049727, drugName: 'oxycodone hydrochloride 5 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 1050409, drugName: 'oxycodone hydrochloride 20 MG/ML Oral Solution [Oxyfast]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '20 MG/ML', strengthValue: 20.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1053647, drugName: 'fentanyl 0.1 MG Sublingual Tablet', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.1 MG', strengthValue: 0.1, strengthUnit: 'MG' },\n  { drugCode: 1053651, drugName: 'fentanyl 0.1 MG Sublingual Tablet [Abstral]', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.1 MG', strengthValue: 0.1, strengthUnit: 'MG' },\n  { drugCode: 1053652, drugName: 'fentanyl 0.2 MG Sublingual Tablet', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.2 MG', strengthValue: 0.2, strengthUnit: 'MG' },\n  { drugCode: 1053654, drugName: 'fentanyl 0.2 MG Sublingual Tablet [Abstral]', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.2 MG', strengthValue: 0.2, strengthUnit: 'MG' },\n  { drugCode: 1053655, drugName: 'fentanyl 0.3 MG Sublingual Tablet', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.3 MG', strengthValue: 0.3, strengthUnit: 'MG' },\n  { drugCode: 1053657, drugName: 'fentanyl 0.3 MG Sublingual Tablet [Abstral]', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.3 MG', strengthValue: 0.3, strengthUnit: 'MG' },\n  { drugCode: 1053658, drugName: 'fentanyl 0.4 MG Sublingual Tablet', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.4 MG', strengthValue: 0.4, strengthUnit: 'MG' },\n  { drugCode: 1053660, drugName: 'fentanyl 0.4 MG Sublingual Tablet [Abstral]', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.4 MG', strengthValue: 0.4, strengthUnit: 'MG' },\n  { drugCode: 1053661, drugName: 'fentanyl 0.6 MG Sublingual Tablet', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.6 MG', strengthValue: 0.6, strengthUnit: 'MG' },\n  { drugCode: 1053663, drugName: 'fentanyl 0.6 MG Sublingual Tablet [Abstral]', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.6 MG', strengthValue: 0.6, strengthUnit: 'MG' },\n  { drugCode: 1053664, drugName: 'fentanyl 0.8 MG Sublingual Tablet', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.8 MG', strengthValue: 0.8, strengthUnit: 'MG' },\n  { drugCode: 1053666, drugName: 'fentanyl 0.8 MG Sublingual Tablet [Abstral]', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.8 MG', strengthValue: 0.8, strengthUnit: 'MG' },\n  { drugCode: 1086926, drugName: 'codeine phosphate 1.26 MG/ML / guaifenesin 20 MG/ML Oral Solution [Relcof C]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.26 MG/ML', strengthValue: 1.26, strengthUnit: 'MG/ML' },\n  { drugCode: 1087389, drugName: '12 HR chlorpheniramine polistirex 4 MG / hydrocodone polistirex 5 MG Extended Release Oral Capsule [TussiCaps]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 1087427, drugName: '12 HR chlorpheniramine polistirex 8 MG / hydrocodone polistirex 10 MG Extended Release Oral Capsule [TussiCaps]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1087459, drugName: '12 HR chlorpheniramine polistirex 1.6 MG/ML / hydrocodone polistirex 2 MG/ML Extended Release Suspension', doseFormCode: 316946, doseFormName: 'Extended Release Suspension', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1087463, drugName: '12 HR chlorpheniramine polistirex 1.6 MG/ML / hydrocodone polistirex 2 MG/ML Extended Release Suspension [Tussionex]', doseFormCode: 316946, doseFormName: 'Extended Release Suspension', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1088951, drugName: 'codeine phosphate 1 MG/ML / guaifenesin 20 MG/ML / pseudoephedrine hydrochloride 3 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1088953, drugName: 'codeine phosphate 1 MG/ML / guaifenesin 20 MG/ML / pseudoephedrine hydrochloride 3 MG/ML Oral Suspension [Zodryl DEC]', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1088963, drugName: 'codeine phosphate 1 MG/ML / guaifenesin 20 MG/ML / pseudoephedrine hydrochloride 3.33 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1088965, drugName: 'codeine phosphate 1 MG/ML / guaifenesin 20 MG/ML / pseudoephedrine hydrochloride 3.33 MG/ML Oral Suspension [Zodryl DEC]', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1088968, drugName: 'codeine phosphate 1 MG/ML / guaifenesin 20 MG/ML / pseudoephedrine hydrochloride 3.75 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1088970, drugName: 'codeine phosphate 1 MG/ML / guaifenesin 20 MG/ML / pseudoephedrine hydrochloride 3.75 MG/ML Oral Suspension [Zodryl DEC]', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1088975, drugName: 'codeine phosphate 1 MG/ML / guaifenesin 20 MG/ML / pseudoephedrine hydrochloride 4 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1088977, drugName: 'codeine phosphate 1 MG/ML / guaifenesin 20 MG/ML / pseudoephedrine hydrochloride 4 MG/ML Oral Suspension [Zodryl DEC]', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1089021, drugName: 'codeine phosphate 1 MG/ML / guaifenesin 20 MG/ML / pseudoephedrine hydrochloride 4.29 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1089023, drugName: 'codeine phosphate 1 MG/ML / guaifenesin 20 MG/ML / pseudoephedrine hydrochloride 4.29 MG/ML Oral Suspension [Zodryl DEC]', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1089025, drugName: 'codeine phosphate 1 MG/ML / guaifenesin 20 MG/ML / pseudoephedrine hydrochloride 5 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1089027, drugName: 'codeine phosphate 1 MG/ML / guaifenesin 20 MG/ML / pseudoephedrine hydrochloride 5 MG/ML Oral Suspension [Zodryl DEC]', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1089028, drugName: 'codeine phosphate 1 MG/ML / guaifenesin 20 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Suspension', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1089030, drugName: 'codeine phosphate 1 MG/ML / guaifenesin 20 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Suspension [Zodryl DEC]', doseFormCode: 316969, doseFormName: 'Oral Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1089055, drugName: 'codeine phosphate 10 MG / guaifenesin 400 MG / pseudoephedrine hydrochloride 20 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1089057, drugName: 'codeine phosphate 10 MG / guaifenesin 400 MG / pseudoephedrine hydrochloride 20 MG Oral Tablet [Ambifed-G CD]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1089058, drugName: 'codeine phosphate 10 MG / guaifenesin 400 MG / pseudoephedrine hydrochloride 30 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1089060, drugName: 'codeine phosphate 10 MG / guaifenesin 400 MG / pseudoephedrine hydrochloride 30 MG Oral Tablet [Ambifed CD]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1098906, drugName: 'brompheniramine maleate 0.4 MG/ML / guaifenesin 40 MG/ML / hydrocodone bitartrate 1 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1112220, drugName: 'chlorpheniramine maleate 0.8 MG/ML / hydrocodone bitartrate 1 MG/ML / pseudoephedrine hydrochloride 12 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1112224, drugName: 'chlorpheniramine maleate 0.8 MG/ML / hydrocodone bitartrate 1 MG/ML / pseudoephedrine hydrochloride 12 MG/ML Oral Solution [Zutripro]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1113314, drugName: 'oxycodone hydrochloride 7.5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 1113417, drugName: 'chlorpheniramine maleate 0.4 MG/ML / codeine phosphate 2 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1113998, drugName: 'chlorpheniramine maleate 0.4 MG/ML / codeine phosphate 1.6 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.6 MG/ML', strengthValue: 1.6, strengthUnit: 'MG/ML' },\n  { drugCode: 1114002, drugName: 'chlorpheniramine maleate 0.4 MG/ML / codeine phosphate 1.6 MG/ML Oral Solution [Codar AR]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.6 MG/ML', strengthValue: 1.6, strengthUnit: 'MG/ML' },\n  { drugCode: 1114003, drugName: 'chlorpheniramine maleate 0.4 MG/ML / codeine phosphate 1.6 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.6 MG/ML', strengthValue: 1.6, strengthUnit: 'MG/ML' },\n  { drugCode: 1114026, drugName: 'codeine phosphate 1.6 MG/ML / guaifenesin 40 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.6 MG/ML', strengthValue: 1.6, strengthUnit: 'MG/ML' },\n  { drugCode: 1114030, drugName: 'codeine phosphate 1.6 MG/ML / guaifenesin 40 MG/ML Oral Solution [Codar GF]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.6 MG/ML', strengthValue: 1.6, strengthUnit: 'MG/ML' },\n  { drugCode: 1114110, drugName: 'codeine phosphate 1.6 MG/ML / guaifenesin 40 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.6 MG/ML', strengthValue: 1.6, strengthUnit: 'MG/ML' },\n  { drugCode: 1114334, drugName: 'hydrocodone bitartrate 1 MG/ML / pseudoephedrine hydrochloride 12 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1114338, drugName: 'hydrocodone bitartrate 1 MG/ML / pseudoephedrine hydrochloride 12 MG/ML Oral Solution [Rezira]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1114878, drugName: 'codeine phosphate 1.6 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.6 MG/ML', strengthValue: 1.6, strengthUnit: 'MG/ML' },\n  { drugCode: 1115573, drugName: 'fentanyl 0.1 MG/ACTUAT Metered Dose Nasal Spray', doseFormCode: 1797831, doseFormName: 'Metered Dose Nasal Spray', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.1 MG/ACTUAT', strengthValue: 0.1, strengthUnit: 'MG/ACTUAT' },\n  { drugCode: 1115575, drugName: 'fentanyl 0.1 MG/ACTUAT Metered Dose Nasal Spray [Lazanda]', doseFormCode: 1797831, doseFormName: 'Metered Dose Nasal Spray', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.1 MG/ACTUAT', strengthValue: 0.1, strengthUnit: 'MG/ACTUAT' },\n  { drugCode: 1115577, drugName: 'fentanyl 0.4 MG/ACTUAT Metered Dose Nasal Spray', doseFormCode: 1797831, doseFormName: 'Metered Dose Nasal Spray', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.4 MG/ACTUAT', strengthValue: 0.4, strengthUnit: 'MG/ACTUAT' },\n  { drugCode: 1115579, drugName: 'fentanyl 0.4 MG/ACTUAT Metered Dose Nasal Spray [Lazanda]', doseFormCode: 1797831, doseFormName: 'Metered Dose Nasal Spray', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.4 MG/ACTUAT', strengthValue: 0.4, strengthUnit: 'MG/ACTUAT' },\n  { drugCode: 1145972, drugName: 'codeine phosphate 1.6 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Solution [Codar D]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.6 MG/ML', strengthValue: 1.6, strengthUnit: 'MG/ML' },\n  { drugCode: 1148478, drugName: '24 HR tramadol hydrochloride 100 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 1148482, drugName: '24 HR tramadol hydrochloride 100 MG Extended Release Oral Capsule [ConZip]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 1148485, drugName: '24 HR tramadol hydrochloride 200 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '200 MG', strengthValue: 200.0, strengthUnit: 'MG' },\n  { drugCode: 1148487, drugName: '24 HR tramadol hydrochloride 200 MG Extended Release Oral Capsule [ConZip]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '200 MG', strengthValue: 200.0, strengthUnit: 'MG' },\n  { drugCode: 1148489, drugName: '24 HR tramadol hydrochloride 300 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '300 MG', strengthValue: 300.0, strengthUnit: 'MG' },\n  { drugCode: 1148491, drugName: '24 HR tramadol hydrochloride 300 MG Extended Release Oral Capsule [ConZip]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '300 MG', strengthValue: 300.0, strengthUnit: 'MG' },\n  { drugCode: 1148797, drugName: '12 HR tapentadol 100 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 787390, ingredientName: 'tapentadol', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 1148800, drugName: '12 HR tapentadol 150 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 787390, ingredientName: 'tapentadol', strength: '150 MG', strengthValue: 150.0, strengthUnit: 'MG' },\n  { drugCode: 1148803, drugName: '12 HR tapentadol 200 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 787390, ingredientName: 'tapentadol', strength: '200 MG', strengthValue: 200.0, strengthUnit: 'MG' },\n  { drugCode: 1148807, drugName: '12 HR tapentadol 250 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 787390, ingredientName: 'tapentadol', strength: '250 MG', strengthValue: 250.0, strengthUnit: 'MG' },\n  { drugCode: 1148809, drugName: '12 HR tapentadol 50 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 787390, ingredientName: 'tapentadol', strength: '50 MG', strengthValue: 50.0, strengthUnit: 'MG' },\n  { drugCode: 1149367, drugName: '12 HR tapentadol 100 MG Extended Release Oral Tablet [Nucynta]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 787390, ingredientName: 'tapentadol', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 1149370, drugName: '12 HR tapentadol 150 MG Extended Release Oral Tablet [Nucynta]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 787390, ingredientName: 'tapentadol', strength: '150 MG', strengthValue: 150.0, strengthUnit: 'MG' },\n  { drugCode: 1149373, drugName: '12 HR tapentadol 200 MG Extended Release Oral Tablet [Nucynta]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 787390, ingredientName: 'tapentadol', strength: '200 MG', strengthValue: 200.0, strengthUnit: 'MG' },\n  { drugCode: 1149376, drugName: '12 HR tapentadol 250 MG Extended Release Oral Tablet [Nucynta]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 787390, ingredientName: 'tapentadol', strength: '250 MG', strengthValue: 250.0, strengthUnit: 'MG' },\n  { drugCode: 1149378, drugName: '12 HR tapentadol 50 MG Extended Release Oral Tablet [Nucynta]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 787390, ingredientName: 'tapentadol', strength: '50 MG', strengthValue: 50.0, strengthUnit: 'MG' },\n  { drugCode: 1190201, drugName: 'acetaminophen 320.5 MG / caffeine 30 MG / dihydrocodeine bitartrate 16 MG Oral Capsule [Trezix]', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 23088, ingredientName: 'dihydrocodeine', strength: '16 MG', strengthValue: 16.0, strengthUnit: 'MG' },\n  { drugCode: 1190580, drugName: 'codeine phosphate 1.2 MG/ML / dexbrompheniramine maleate 0.133 MG/ML / pseudoephedrine hydrochloride 4 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.2 MG/ML', strengthValue: 1.2, strengthUnit: 'MG/ML' },\n  { drugCode: 1190587, drugName: 'codeine phosphate 1.2 MG/ML / dexbrompheniramine maleate 0.133 MG/ML / pseudoephedrine hydrochloride 4 MG/ML Oral Solution [M-End Max D]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.2 MG/ML', strengthValue: 1.2, strengthUnit: 'MG/ML' },\n  { drugCode: 1232113, drugName: '1 ML morphine sulfate 15 MG/ML Prefilled Syringe', doseFormCode: 721656, doseFormName: 'Prefilled Syringe', ingredientCode: 7052, ingredientName: 'Morphine', strength: '15 MG/ML', strengthValue: 15.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1233687, drugName: 'fentanyl 0.004 MG/ML / ropivacaine hydrochloride 2 MG/ML Injectable Solution', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.004 MG/ML', strengthValue: 0.004, strengthUnit: 'MG/ML' },\n  { drugCode: 1234871, drugName: 'acetaminophen 356.4 MG / caffeine 30 MG / dihydrocodeine bitartrate 16 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 23088, ingredientName: 'dihydrocodeine', strength: '16 MG', strengthValue: 16.0, strengthUnit: 'MG' },\n  { drugCode: 1234872, drugName: 'aspirin 356.4 MG / caffeine 30 MG / dihydrocodeine bitartrate 16 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 23088, ingredientName: 'dihydrocodeine', strength: '16 MG', strengthValue: 16.0, strengthUnit: 'MG' },\n  { drugCode: 1234941, drugName: 'chlorpheniramine maleate 0.4 MG/ML / dihydrocodeine bitartrate 0.6 MG/ML / phenylephrine hydrochloride 1.5 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 23088, ingredientName: 'dihydrocodeine', strength: '0.6 MG/ML', strengthValue: 0.6, strengthUnit: 'MG/ML' },\n  { drugCode: 1234957, drugName: 'chlorpheniramine maleate 0.4 MG/ML / dihydrocodeine bitartrate 0.6 MG/ML / phenylephrine hydrochloride 1.5 MG/ML Oral Solution [ColdCough PD]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 23088, ingredientName: 'dihydrocodeine', strength: '0.6 MG/ML', strengthValue: 0.6, strengthUnit: 'MG/ML' },\n  { drugCode: 1234976, drugName: 'aspirin 356.4 MG / caffeine 30 MG / dihydrocodeine bitartrate 16 MG Oral Capsule [Synalgos-DC]', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 23088, ingredientName: 'dihydrocodeine', strength: '16 MG', strengthValue: 16.0, strengthUnit: 'MG' },\n  { drugCode: 1234978, drugName: 'acetaminophen 712.8 MG / caffeine 60 MG / dihydrocodeine bitartrate 32 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 23088, ingredientName: 'dihydrocodeine', strength: '32 MG', strengthValue: 32.0, strengthUnit: 'MG' },\n  { drugCode: 1234999, drugName: 'acetaminophen 500 MG / dihydrocodeine bitartrate 10 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 23088, ingredientName: 'dihydrocodeine', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1235009, drugName: 'acetaminophen 500 MG / dihydrocodeine bitartrate 20 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 23088, ingredientName: 'dihydrocodeine', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 1235011, drugName: 'acetaminophen 500 MG / dihydrocodeine bitartrate 30 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 23088, ingredientName: 'dihydrocodeine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 1235862, drugName: 'chlorcyclizine hydrochloride 2.5 MG/ML / codeine phosphate 1.8 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.8 MG/ML', strengthValue: 1.8, strengthUnit: 'MG/ML' },\n  { drugCode: 1236179, drugName: 'dihydrocodeine bitartrate 120 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 23088, ingredientName: 'dihydrocodeine', strength: '120 MG', strengthValue: 120.0, strengthUnit: 'MG' },\n  { drugCode: 1236182, drugName: 'dihydrocodeine bitartrate 30 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 23088, ingredientName: 'dihydrocodeine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 1236184, drugName: 'dihydrocodeine bitartrate 40 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 23088, ingredientName: 'dihydrocodeine', strength: '40 MG', strengthValue: 40.0, strengthUnit: 'MG' },\n  { drugCode: 1236188, drugName: 'dihydrocodeine bitartrate 60 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 23088, ingredientName: 'dihydrocodeine', strength: '60 MG', strengthValue: 60.0, strengthUnit: 'MG' },\n  { drugCode: 1236190, drugName: 'dihydrocodeine bitartrate 90 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 23088, ingredientName: 'dihydrocodeine', strength: '90 MG', strengthValue: 90.0, strengthUnit: 'MG' },\n  { drugCode: 1237050, drugName: 'fentanyl 0.1 MG/ACTUAT Mucosal Spray', doseFormCode: 346163, doseFormName: 'Mucosal Spray', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.1 MG/ACTUAT', strengthValue: 0.1, strengthUnit: 'MG/ACTUAT' },\n  { drugCode: 1237055, drugName: 'fentanyl 0.1 MG/ACTUAT Mucosal Spray [Subsys]', doseFormCode: 346163, doseFormName: 'Mucosal Spray', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.1 MG/ACTUAT', strengthValue: 0.1, strengthUnit: 'MG/ACTUAT' },\n  { drugCode: 1237057, drugName: 'fentanyl 0.2 MG/ACTUAT Mucosal Spray', doseFormCode: 346163, doseFormName: 'Mucosal Spray', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.2 MG/ACTUAT', strengthValue: 0.2, strengthUnit: 'MG/ACTUAT' },\n  { drugCode: 1237059, drugName: 'fentanyl 0.2 MG/ACTUAT Mucosal Spray [Subsys]', doseFormCode: 346163, doseFormName: 'Mucosal Spray', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.2 MG/ACTUAT', strengthValue: 0.2, strengthUnit: 'MG/ACTUAT' },\n  { drugCode: 1237060, drugName: 'fentanyl 0.4 MG/ACTUAT Mucosal Spray', doseFormCode: 346163, doseFormName: 'Mucosal Spray', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.4 MG/ACTUAT', strengthValue: 0.4, strengthUnit: 'MG/ACTUAT' },\n  { drugCode: 1237062, drugName: 'fentanyl 0.4 MG/ACTUAT Mucosal Spray [Subsys]', doseFormCode: 346163, doseFormName: 'Mucosal Spray', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.4 MG/ACTUAT', strengthValue: 0.4, strengthUnit: 'MG/ACTUAT' },\n  { drugCode: 1237064, drugName: 'fentanyl 0.6 MG/ACTUAT Mucosal Spray', doseFormCode: 346163, doseFormName: 'Mucosal Spray', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.6 MG/ACTUAT', strengthValue: 0.6, strengthUnit: 'MG/ACTUAT' },\n  { drugCode: 1237066, drugName: 'fentanyl 0.6 MG/ACTUAT Mucosal Spray [Subsys]', doseFormCode: 346163, doseFormName: 'Mucosal Spray', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.6 MG/ACTUAT', strengthValue: 0.6, strengthUnit: 'MG/ACTUAT' },\n  { drugCode: 1237068, drugName: 'fentanyl 0.8 MG/ACTUAT Mucosal Spray', doseFormCode: 346163, doseFormName: 'Mucosal Spray', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.8 MG/ACTUAT', strengthValue: 0.8, strengthUnit: 'MG/ACTUAT' },\n  { drugCode: 1237070, drugName: 'fentanyl 0.8 MG/ACTUAT Mucosal Spray [Subsys]', doseFormCode: 346163, doseFormName: 'Mucosal Spray', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.8 MG/ACTUAT', strengthValue: 0.8, strengthUnit: 'MG/ACTUAT' },\n  { drugCode: 1242106, drugName: '1 ML meperidine hydrochloride 100 MG/ML Cartridge [Demerol]', doseFormCode: 1649572, doseFormName: 'Cartridge', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '100 MG/ML', strengthValue: 100.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1242503, drugName: '1 ML meperidine hydrochloride 25 MG/ML Cartridge [Demerol]', doseFormCode: 1649572, doseFormName: 'Cartridge', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '25 MG/ML', strengthValue: 25.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1242558, drugName: 'chlorcyclizine hydrochloride 2.5 MG/ML / codeine phosphate 1.8 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Solution [Statuss Green Reformulated Jan 2012]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.8 MG/ML', strengthValue: 1.8, strengthUnit: 'MG/ML' },\n  { drugCode: 1244754, drugName: 'guaifenesin 20 MG/ML / hydrocodone bitartrate 0.5 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 1244921, drugName: 'brompheniramine maleate 0.266 MG/ML / codeine phosphate 1.27 MG/ML / phenylephrine hydrochloride 0.666 MG/ML Oral Solution [M-End PE]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.27 MG/ML', strengthValue: 1.27, strengthUnit: 'MG/ML' },\n  { drugCode: 1248115, drugName: '24 HR tramadol hydrochloride 150 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '150 MG', strengthValue: 150.0, strengthUnit: 'MG' },\n  { drugCode: 1294356, drugName: 'bromodiphenhydramine hydrochloride 2.5 MG/ML / codeine phosphate 2 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1302739, drugName: 'butorphanol 10 MG/ML Injectable Solution', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 1841, ingredientName: 'Butorphanol', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1302741, drugName: 'butorphanol 10 MG/ML Injectable Solution [Dolorex Solution]', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 1841, ingredientName: 'Butorphanol', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1303736, drugName: 'morphine sulfate 40 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '40 MG', strengthValue: 40.0, strengthUnit: 'MG' },\n  { drugCode: 1303738, drugName: 'morphine sulfate 40 MG Extended Release Oral Capsule [Kadian]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7052, ingredientName: 'Morphine', strength: '40 MG', strengthValue: 40.0, strengthUnit: 'MG' },\n  { drugCode: 1306898, drugName: '24 HR hydromorphone hydrochloride 32 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '32 MG', strengthValue: 32.0, strengthUnit: 'MG' },\n  { drugCode: 1306900, drugName: '24 HR hydromorphone hydrochloride 32 MG Extended Release Oral Tablet [Exalgo]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '32 MG', strengthValue: 32.0, strengthUnit: 'MG' },\n  { drugCode: 1307056, drugName: 'buprenorphine 4 MG / naloxone 1 MG Sublingual Film', doseFormCode: 2269578, doseFormName: 'Sublingual Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '4 MG', strengthValue: 4.0, strengthUnit: 'MG' },\n  { drugCode: 1307058, drugName: 'buprenorphine 4 MG / naloxone 1 MG Sublingual Film [Suboxone]', doseFormCode: 2269578, doseFormName: 'Sublingual Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '4 MG', strengthValue: 4.0, strengthUnit: 'MG' },\n  { drugCode: 1307061, drugName: 'buprenorphine 12 MG / naloxone 3 MG Sublingual Film', doseFormCode: 2269578, doseFormName: 'Sublingual Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '12 MG', strengthValue: 12.0, strengthUnit: 'MG' },\n  { drugCode: 1307063, drugName: 'buprenorphine 12 MG / naloxone 3 MG Sublingual Film [Suboxone]', doseFormCode: 2269578, doseFormName: 'Sublingual Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '12 MG', strengthValue: 12.0, strengthUnit: 'MG' },\n  { drugCode: 1308438, drugName: 'brompheniramine maleate 0.4 MG/ML / codeine phosphate 2 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1308440, drugName: 'brompheniramine maleate 0.4 MG/ML / codeine phosphate 2 MG/ML Oral Solution [Nalex AC]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1310202, drugName: 'acetaminophen 300 MG / hydrocodone bitartrate 5 MG Oral Tablet [Vicodin]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 1310212, drugName: 'acetaminophen 300 MG / hydrocodone bitartrate 7.5 MG Oral Tablet [Vicodin]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 1310270, drugName: 'acetaminophen 300 MG / hydrocodone bitartrate 10 MG Oral Tablet [Vicodin]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1310927, drugName: 'butorphanol 10 MG/ML Injectable Solution [Butorphic]', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 1841, ingredientName: 'Butorphanol', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1313294, drugName: 'guaifenesin 10 MG/ML / hydrocodone bitartrate 0.5 MG/ML / phenylephrine hydrochloride 1.5 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 1356797, drugName: 'brompheniramine maleate 4 MG / codeine phosphate 10 MG / phenylephrine hydrochloride 10 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1356799, drugName: 'brompheniramine maleate 4 MG / codeine phosphate 10 MG / phenylephrine hydrochloride 10 MG Oral Tablet [Brovex PBC]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1356800, drugName: 'brompheniramine maleate 4 MG / codeine phosphate 10 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1356802, drugName: 'brompheniramine maleate 4 MG / codeine phosphate 10 MG Oral Tablet [BroveX CB]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1356804, drugName: 'brompheniramine maleate 4 MG / codeine phosphate 20 MG / phenylephrine hydrochloride 10 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 1356806, drugName: 'brompheniramine maleate 4 MG / codeine phosphate 20 MG / phenylephrine hydrochloride 10 MG Oral Tablet [Brovex PBC]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 1356807, drugName: 'brompheniramine maleate 4 MG / codeine phosphate 20 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 1356809, drugName: 'brompheniramine maleate 4 MG / codeine phosphate 20 MG Oral Tablet [BroveX CB]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 1356835, drugName: 'brompheniramine maleate 0.6 MG/ML / hydrocodone bitartrate 0.5 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 1357402, drugName: 'brompheniramine maleate 0.4 MG/ML / codeine phosphate 2 MG/ML / phenylpropanolamine hydrochloride 2.5 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1357940, drugName: 'dexchlorpheniramine maleate 0.4 MG/ML / hydrocodone bitartrate 0.8 MG/ML / phenylephrine hydrochloride 1 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.8 MG/ML', strengthValue: 0.8, strengthUnit: 'MG/ML' },\n  { drugCode: 1366873, drugName: 'hydrocodone bitartrate 5 MG / pseudoephedrine hydrochloride 60 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 1366875, drugName: 'hydrocodone bitartrate 5 MG / pseudoephedrine hydrochloride 60 MG Oral Tablet [P-V-Tussin]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 1372265, drugName: 'chlorpheniramine maleate 0.8 MG/ML / hydrocodone bitartrate 1 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1372873, drugName: 'chlorpheniramine maleate 0.8 MG/ML / hydrocodone bitartrate 1 MG/ML Oral Solution [Vituz]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1431076, drugName: 'buprenorphine 1.4 MG / naloxone 0.36 MG Sublingual Tablet', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '1.4 MG', strengthValue: 1.4, strengthUnit: 'MG' },\n  { drugCode: 1431083, drugName: 'buprenorphine 1.4 MG / naloxone 0.36 MG Sublingual Tablet [Zubsolv]', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '1.4 MG', strengthValue: 1.4, strengthUnit: 'MG' },\n  { drugCode: 1431102, drugName: 'buprenorphine 5.7 MG / naloxone 1.4 MG Sublingual Tablet', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '5.7 MG', strengthValue: 5.7, strengthUnit: 'MG' },\n  { drugCode: 1431104, drugName: 'buprenorphine 5.7 MG / naloxone 1.4 MG Sublingual Tablet [Zubsolv]', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '5.7 MG', strengthValue: 5.7, strengthUnit: 'MG' },\n  { drugCode: 1431286, drugName: 'acetaminophen 300 MG / butalbital 50 MG / caffeine 40 MG / codeine phosphate 30 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 2670, ingredientName: 'Codeine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 1432969, drugName: '168 HR buprenorphine 0.015 MG/HR Transdermal System', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.015 MG/HR', strengthValue: 0.015, strengthUnit: 'MG/HR' },\n  { drugCode: 1432971, drugName: '168 HR buprenorphine 0.015 MG/HR Transdermal System [BuTrans]', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.015 MG/HR', strengthValue: 0.015, strengthUnit: 'MG/HR' },\n  { drugCode: 1433251, drugName: '0.5 ML hydromorphone hydrochloride 1 MG/ML Prefilled Syringe', doseFormCode: 721656, doseFormName: 'Prefilled Syringe', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1433802, drugName: 'acetaminophen 300 MG / butalbital 50 MG / caffeine 40 MG / codeine phosphate 30 MG Oral Capsule [Fioricet with Codeine]', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 2670, ingredientName: 'Codeine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 1440003, drugName: 'codeine phosphate 1.8 MG/ML / dexchlorpheniramine maleate 0.2 MG/ML / phenylephrine hydrochloride 1 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.8 MG/ML', strengthValue: 1.8, strengthUnit: 'MG/ML' },\n  { drugCode: 1442445, drugName: 'acetaminophen 20 MG/ML / hydrocodone bitartrate 0.667 MG/ML Oral Solution [Lortab]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.667 MG/ML', strengthValue: 0.667, strengthUnit: 'MG/ML' },\n  { drugCode: 1442790, drugName: '1 ML morphine sulfate 5 MG/ML Prefilled Syringe', doseFormCode: 721656, doseFormName: 'Prefilled Syringe', ingredientCode: 7052, ingredientName: 'Morphine', strength: '5 MG/ML', strengthValue: 5.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1487288, drugName: 'acetaminophen 325 MG / oxycodone hydrochloride 2.5 MG Oral Tablet [Endocet]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '2.5 MG', strengthValue: 2.5, strengthUnit: 'MG' },\n  { drugCode: 1489991, drugName: 'butorphanol 10 MG/ML Injectable Solution [Torbugesic]', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 1841, ingredientName: 'Butorphanol', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1492671, drugName: 'acetaminophen 325 MG / hydrocodone bitartrate 10 MG Oral Tablet [Lorcet]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1492673, drugName: 'acetaminophen 325 MG / hydrocodone bitartrate 5 MG Oral Tablet [Lorcet]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 1492675, drugName: 'acetaminophen 325 MG / hydrocodone bitartrate 7.5 MG Oral Tablet [Lorcet]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 1495472, drugName: 'acetaminophen 325 MG / hydrocodone bitartrate 10 MG Oral Tablet [Lortab]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1495474, drugName: 'acetaminophen 325 MG / hydrocodone bitartrate 5 MG Oral Tablet [Lortab]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 1495476, drugName: 'acetaminophen 325 MG / hydrocodone bitartrate 7.5 MG Oral Tablet [Lortab]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 1535979, drugName: 'chlorpheniramine maleate 0.5 MG/ML / hydrocodone bitartrate 0.65 MG/ML / phenylephrine hydrochloride 1.6 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.65 MG/ML', strengthValue: 0.65, strengthUnit: 'MG/ML' },\n  { drugCode: 1536457, drugName: 'acetaminophen 500 MG / codeine phosphate 8 MG Effervescent Oral Tablet', doseFormCode: 1535727, doseFormName: 'Effervescent Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '8 MG', strengthValue: 8.0, strengthUnit: 'MG' },\n  { drugCode: 1536459, drugName: 'acetaminophen 500 MG / codeine phosphate 30 MG Effervescent Oral Tablet', doseFormCode: 1535727, doseFormName: 'Effervescent Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 1537116, drugName: 'acetaminophen 300 MG / oxycodone hydrochloride 5 MG Oral Tablet [Primlev]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 1537120, drugName: 'acetaminophen 300 MG / oxycodone hydrochloride 10 MG Oral Tablet [Primlev]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1537122, drugName: 'acetaminophen 300 MG / oxycodone hydrochloride 7.5 MG Oral Tablet [Primlev]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 1541630, drugName: 'brompheniramine maleate 0.8 MG/ML / codeine phosphate 2 MG/ML / phenylephrine hydrochloride 2 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1542390, drugName: 'buprenorphine 2.1 MG / naloxone 0.3 MG Buccal Film', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '2.1 MG', strengthValue: 2.1, strengthUnit: 'MG' },\n  { drugCode: 1542396, drugName: 'buprenorphine 2.1 MG / naloxone 0.3 MG Buccal Film [Bunavail]', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '2.1 MG', strengthValue: 2.1, strengthUnit: 'MG' },\n  { drugCode: 1542981, drugName: 'acetaminophen 325 MG / hydrocodone bitartrate 2.5 MG Oral Tablet [Verdrocet]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '2.5 MG', strengthValue: 2.5, strengthUnit: 'MG' },\n  { drugCode: 1542988, drugName: 'hydrocodone bitartrate 10 MG / ibuprofen 200 MG Oral Tablet [Xylon]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1542997, drugName: '168 HR buprenorphine 0.0075 MG/HR Transdermal System', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.0075 MG/HR', strengthValue: 0.0075, strengthUnit: 'MG/HR' },\n  { drugCode: 1542999, drugName: '168 HR buprenorphine 0.0075 MG/HR Transdermal System [BuTrans]', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.0075 MG/HR', strengthValue: 0.0075, strengthUnit: 'MG/HR' },\n  { drugCode: 1544851, drugName: 'buprenorphine 4.2 MG / naloxone 0.7 MG Buccal Film', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '4.2 MG', strengthValue: 4.2, strengthUnit: 'MG' },\n  { drugCode: 1544853, drugName: 'buprenorphine 4.2 MG / naloxone 0.7 MG Buccal Film [Bunavail]', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '4.2 MG', strengthValue: 4.2, strengthUnit: 'MG' },\n  { drugCode: 1544854, drugName: 'buprenorphine 6.3 MG / naloxone 1 MG Buccal Film', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '6.3 MG', strengthValue: 6.3, strengthUnit: 'MG' },\n  { drugCode: 1544856, drugName: 'buprenorphine 6.3 MG / naloxone 1 MG Buccal Film [Bunavail]', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '6.3 MG', strengthValue: 6.3, strengthUnit: 'MG' },\n  { drugCode: 1547607, drugName: 'codeine phosphate 2 MG/ML / guaifenesin 20 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Solution [Lortuss EX]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1594650, drugName: 'buprenorphine 1.8 MG/ML Injectable Solution', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '1.8 MG/ML', strengthValue: 1.8, strengthUnit: 'MG/ML' },\n  { drugCode: 1594655, drugName: 'buprenorphine 1.8 MG/ML Injectable Solution [Simbadol]', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '1.8 MG/ML', strengthValue: 1.8, strengthUnit: 'MG/ML' },\n  { drugCode: 1595214, drugName: 'codeine phosphate 1.6 MG/ML / guaifenesin 40 MG/ML Oral Solution [Ninjacof XG]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '1.6 MG/ML', strengthValue: 1.6, strengthUnit: 'MG/ML' },\n  { drugCode: 1595730, drugName: 'Abuse-Deterrent 24 HR hydrocodone bitartrate 20 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 1595736, drugName: 'Abuse-Deterrent 24 HR hydrocodone bitartrate 20 MG Extended Release Oral Tablet [Hysingla]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 1595740, drugName: 'Abuse-Deterrent 24 HR hydrocodone bitartrate 30 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 1595742, drugName: 'Abuse-Deterrent 24 HR hydrocodone bitartrate 30 MG Extended Release Oral Tablet [Hysingla]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 1595746, drugName: 'Abuse-Deterrent 24 HR hydrocodone bitartrate 40 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '40 MG', strengthValue: 40.0, strengthUnit: 'MG' },\n  { drugCode: 1595748, drugName: 'Abuse-Deterrent 24 HR hydrocodone bitartrate 40 MG Extended Release Oral Tablet [Hysingla]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '40 MG', strengthValue: 40.0, strengthUnit: 'MG' },\n  { drugCode: 1595752, drugName: 'Abuse-Deterrent 24 HR hydrocodone bitartrate 60 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '60 MG', strengthValue: 60.0, strengthUnit: 'MG' },\n  { drugCode: 1595754, drugName: 'Abuse-Deterrent 24 HR hydrocodone bitartrate 60 MG Extended Release Oral Tablet [Hysingla]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '60 MG', strengthValue: 60.0, strengthUnit: 'MG' },\n  { drugCode: 1595758, drugName: 'Abuse-Deterrent 24 HR hydrocodone bitartrate 80 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '80 MG', strengthValue: 80.0, strengthUnit: 'MG' },\n  { drugCode: 1595760, drugName: 'Abuse-Deterrent 24 HR hydrocodone bitartrate 80 MG Extended Release Oral Tablet [Hysingla]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '80 MG', strengthValue: 80.0, strengthUnit: 'MG' },\n  { drugCode: 1595764, drugName: 'Abuse-Deterrent 24 HR hydrocodone bitartrate 100 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 1595766, drugName: 'Abuse-Deterrent 24 HR hydrocodone bitartrate 100 MG Extended Release Oral Tablet [Hysingla]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 1595770, drugName: 'Abuse-Deterrent 24 HR hydrocodone bitartrate 120 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '120 MG', strengthValue: 120.0, strengthUnit: 'MG' },\n  { drugCode: 1595772, drugName: 'Abuse-Deterrent 24 HR hydrocodone bitartrate 120 MG Extended Release Oral Tablet [Hysingla]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '120 MG', strengthValue: 120.0, strengthUnit: 'MG' },\n  { drugCode: 1596108, drugName: 'acetaminophen 320.5 MG / caffeine 30 MG / dihydrocodeine bitartrate 16 MG Oral Capsule', doseFormCode: 316965, doseFormName: 'Oral Capsule', ingredientCode: 23088, ingredientName: 'dihydrocodeine', strength: '16 MG', strengthValue: 16.0, strengthUnit: 'MG' },\n  { drugCode: 1597568, drugName: 'buprenorphine 11.4 MG / naloxone 2.9 MG Sublingual Tablet', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '11.4 MG', strengthValue: 11.4, strengthUnit: 'MG' },\n  { drugCode: 1597570, drugName: 'buprenorphine 11.4 MG / naloxone 2.9 MG Sublingual Tablet [Zubsolv]', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '11.4 MG', strengthValue: 11.4, strengthUnit: 'MG' },\n  { drugCode: 1597573, drugName: 'buprenorphine 8.6 MG / naloxone 2.1 MG Sublingual Tablet', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '8.6 MG', strengthValue: 8.6, strengthUnit: 'MG' },\n  { drugCode: 1597575, drugName: 'buprenorphine 8.6 MG / naloxone 2.1 MG Sublingual Tablet [Zubsolv]', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '8.6 MG', strengthValue: 8.6, strengthUnit: 'MG' },\n  { drugCode: 1598284, drugName: 'guaifenesin 40 MG/ML / hydrocodone bitartrate 0.5 MG/ML Oral Solution [Obredon]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 1603495, drugName: '72 HR fentanyl 0.0375 MG/HR Transdermal System', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.0375 MG/HR', strengthValue: 0.0375, strengthUnit: 'MG/HR' },\n  { drugCode: 1603498, drugName: '72 HR fentanyl 0.0625 MG/HR Transdermal System', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.0625 MG/HR', strengthValue: 0.0625, strengthUnit: 'MG/HR' },\n  { drugCode: 1603501, drugName: '72 HR fentanyl 0.0875 MG/HR Transdermal System', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.0875 MG/HR', strengthValue: 0.0875, strengthUnit: 'MG/HR' },\n  { drugCode: 1650982, drugName: 'guaifenesin 40 MG/ML / hydrocodone bitartrate 0.5 MG/ML Oral Solution [Flowtuss]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 1651558, drugName: 'guaifenesin 40 MG/ML / hydrocodone bitartrate 0.5 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 1651564, drugName: 'guaifenesin 40 MG/ML / hydrocodone bitartrate 0.5 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Solution [Hycofenix]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 1652087, drugName: '12 HR chlorpheniramine polistirex 0.8 MG/ML / codeine polistirex 4 MG/ML Extended Release Suspension', doseFormCode: 316946, doseFormName: 'Extended Release Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '4 MG/ML', strengthValue: 4.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1652093, drugName: '12 HR chlorpheniramine polistirex 0.8 MG/ML / codeine polistirex 4 MG/ML Extended Release Suspension [Tuzistra]', doseFormCode: 316946, doseFormName: 'Extended Release Suspension', ingredientCode: 2670, ingredientName: 'Codeine', strength: '4 MG/ML', strengthValue: 4.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1655032, drugName: '1 ML buprenorphine 0.3 MG/ML Cartridge', doseFormCode: 1649572, doseFormName: 'Cartridge', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.3 MG/ML', strengthValue: 0.3, strengthUnit: 'MG/ML' },\n  { drugCode: 1655058, drugName: 'meperidine hydrochloride 150 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '150 MG', strengthValue: 150.0, strengthUnit: 'MG' },\n  { drugCode: 1655060, drugName: 'meperidine hydrochloride 75 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '75 MG', strengthValue: 75.0, strengthUnit: 'MG' },\n  { drugCode: 1661319, drugName: 'codeine phosphate 2 MG/ML / phenylephrine hydrochloride 2 MG/ML / triprolidine hydrochloride 0.5 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1664448, drugName: 'oxycodone hydrochloride 5 MG Oral Tablet [Oxaydo]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 1664543, drugName: '12 HR chlorpheniramine maleate 8 MG / codeine phosphate 54.3 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '54.3 MG', strengthValue: 54.3, strengthUnit: 'MG' },\n  { drugCode: 1664634, drugName: 'oxycodone hydrochloride 7.5 MG Oral Tablet [Oxaydo]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 1665685, drugName: '1 ML meperidine hydrochloride 100 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '100 MG/ML', strengthValue: 100.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1665687, drugName: '1 ML meperidine hydrochloride 100 MG/ML Injection [Demerol]', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '100 MG/ML', strengthValue: 100.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1665690, drugName: '1.5 ML meperidine hydrochloride 50 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '50 MG/ML', strengthValue: 50.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1665691, drugName: '1.5 ML meperidine hydrochloride 50 MG/ML Injection [Demerol]', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '50 MG/ML', strengthValue: 50.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1665697, drugName: '1 ML meperidine hydrochloride 50 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '50 MG/ML', strengthValue: 50.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1665698, drugName: '1 ML meperidine hydrochloride 50 MG/ML Injection [Demerol]', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '50 MG/ML', strengthValue: 50.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1665699, drugName: '0.5 ML meperidine hydrochloride 50 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '50 MG/ML', strengthValue: 50.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1665700, drugName: '0.5 ML meperidine hydrochloride 50 MG/ML Injection [Demerol]', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '50 MG/ML', strengthValue: 50.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1665701, drugName: '2 ML meperidine hydrochloride 50 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '50 MG/ML', strengthValue: 50.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1665702, drugName: '2 ML meperidine hydrochloride 50 MG/ML Injection [Demerol]', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 6754, ingredientName: 'Meperidine', strength: '50 MG/ML', strengthValue: 50.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1666338, drugName: 'buprenorphine 2.9 MG / naloxone 0.71 MG Sublingual Tablet', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '2.9 MG', strengthValue: 2.9, strengthUnit: 'MG' },\n  { drugCode: 1666385, drugName: 'buprenorphine 2.9 MG / naloxone 0.71 MG Sublingual Tablet [Zubsolv]', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '2.9 MG', strengthValue: 2.9, strengthUnit: 'MG' },\n  { drugCode: 1666831, drugName: '80 ACTUAT fentanyl 0.04 MG/ACTUAT Transdermal System', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.04 MG/ACTUAT', strengthValue: 0.04, strengthUnit: 'MG/ACTUAT' },\n  { drugCode: 1666837, drugName: '80 ACTUAT fentanyl 0.04 MG/ACTUAT Transdermal System [Ionsys]', doseFormCode: 316987, doseFormName: 'Transdermal System', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.04 MG/ACTUAT', strengthValue: 0.04, strengthUnit: 'MG/ACTUAT' },\n  { drugCode: 1716057, drugName: 'buprenorphine 0.15 MG Buccal Film', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.15 MG', strengthValue: 0.15, strengthUnit: 'MG' },\n  { drugCode: 1716063, drugName: 'buprenorphine 0.15 MG Buccal Film [Belbuca]', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.15 MG', strengthValue: 0.15, strengthUnit: 'MG' },\n  { drugCode: 1716065, drugName: 'buprenorphine 0.3 MG Buccal Film', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.3 MG', strengthValue: 0.3, strengthUnit: 'MG' },\n  { drugCode: 1716067, drugName: 'buprenorphine 0.3 MG Buccal Film [Belbuca]', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.3 MG', strengthValue: 0.3, strengthUnit: 'MG' },\n  { drugCode: 1716069, drugName: 'buprenorphine 0.45 MG Buccal Film', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.45 MG', strengthValue: 0.45, strengthUnit: 'MG' },\n  { drugCode: 1716071, drugName: 'buprenorphine 0.45 MG Buccal Film [Belbuca]', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.45 MG', strengthValue: 0.45, strengthUnit: 'MG' },\n  { drugCode: 1716073, drugName: 'buprenorphine 0.6 MG Buccal Film', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.6 MG', strengthValue: 0.6, strengthUnit: 'MG' },\n  { drugCode: 1716075, drugName: 'buprenorphine 0.6 MG Buccal Film [Belbuca]', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.6 MG', strengthValue: 0.6, strengthUnit: 'MG' },\n  { drugCode: 1716077, drugName: 'buprenorphine 0.075 MG Buccal Film', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.075 MG', strengthValue: 0.075, strengthUnit: 'MG' },\n  { drugCode: 1716079, drugName: 'buprenorphine 0.075 MG Buccal Film [Belbuca]', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.075 MG', strengthValue: 0.075, strengthUnit: 'MG' },\n  { drugCode: 1716081, drugName: 'buprenorphine 0.75 MG Buccal Film', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.75 MG', strengthValue: 0.75, strengthUnit: 'MG' },\n  { drugCode: 1716083, drugName: 'buprenorphine 0.75 MG Buccal Film [Belbuca]', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.75 MG', strengthValue: 0.75, strengthUnit: 'MG' },\n  { drugCode: 1716086, drugName: 'buprenorphine 0.9 MG Buccal Film', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.9 MG', strengthValue: 0.9, strengthUnit: 'MG' },\n  { drugCode: 1716090, drugName: 'buprenorphine 0.9 MG Buccal Film [Belbuca]', doseFormCode: 858080, doseFormName: 'Buccal Film', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.9 MG', strengthValue: 0.9, strengthUnit: 'MG' },\n  { drugCode: 1724276, drugName: '1 ML hydromorphone hydrochloride 2 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1724338, drugName: '1 ML hydromorphone hydrochloride 10 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1724340, drugName: '5 ML hydromorphone hydrochloride 10 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1724341, drugName: '50 ML hydromorphone hydrochloride 10 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1724383, drugName: '1 ML hydromorphone hydrochloride 1 MG/ML Cartridge', doseFormCode: 1649572, doseFormName: 'Cartridge', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1724644, drugName: '1 ML hydromorphone hydrochloride 2 MG/ML Cartridge', doseFormCode: 1649572, doseFormName: 'Cartridge', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1728351, drugName: '1 ML butorphanol tartrate 2 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 1841, ingredientName: 'Butorphanol', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1728355, drugName: '2 ML butorphanol tartrate 2 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 1841, ingredientName: 'Butorphanol', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1728783, drugName: '10 ML morphine sulfate 0.5 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 1728784, drugName: '10 ML morphine sulfate 0.5 MG/ML Injection [Astramorph]', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 1728791, drugName: '2 ML morphine sulfate 0.5 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 1728792, drugName: '2 ML morphine sulfate 0.5 MG/ML Injection [Astramorph]', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 1728800, drugName: '10 ML morphine sulfate 1 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1728801, drugName: '10 ML morphine sulfate 1 MG/ML Injection [Astramorph]', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1728805, drugName: '2 ML morphine sulfate 1 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1728806, drugName: '2 ML morphine sulfate 1 MG/ML Injection [Astramorph]', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1728999, drugName: '30 ML morphine sulfate 1 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1729197, drugName: '1 ML morphine sulfate 2 MG/ML Cartridge', doseFormCode: 1649572, doseFormName: 'Cartridge', ingredientCode: 7052, ingredientName: 'Morphine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1729320, drugName: 'fentanyl 0.3 MG/ACTUAT Metered Dose Nasal Spray', doseFormCode: 1797831, doseFormName: 'Metered Dose Nasal Spray', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.3 MG/ACTUAT', strengthValue: 0.3, strengthUnit: 'MG/ACTUAT' },\n  { drugCode: 1729322, drugName: 'fentanyl 0.3 MG/ACTUAT Metered Dose Nasal Spray [Lazanda]', doseFormCode: 1797831, doseFormName: 'Metered Dose Nasal Spray', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.3 MG/ACTUAT', strengthValue: 0.3, strengthUnit: 'MG/ACTUAT' },\n  { drugCode: 1731517, drugName: '10 ML morphine sulfate 25 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '25 MG/ML', strengthValue: 25.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1731520, drugName: '4 ML morphine sulfate 25 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '25 MG/ML', strengthValue: 25.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1731522, drugName: '20 ML morphine sulfate 25 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '25 MG/ML', strengthValue: 25.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1731530, drugName: '1 ML morphine sulfate 15 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '15 MG/ML', strengthValue: 15.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1731537, drugName: '20 ML morphine sulfate 50 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '50 MG/ML', strengthValue: 50.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1731545, drugName: '50 ML morphine sulfate 50 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '50 MG/ML', strengthValue: 50.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1731990, drugName: '1.5 ML morphine sulfate liposomal 10 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1731993, drugName: '1 ML morphine sulfate 10 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1731995, drugName: '1 ML morphine sulfate 10 MG/ML Cartridge', doseFormCode: 1649572, doseFormName: 'Cartridge', ingredientCode: 7052, ingredientName: 'Morphine', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1731998, drugName: '20 ML morphine sulfate 10 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1731999, drugName: '20 ML morphine sulfate 10 MG/ML Injection [Infumorph]', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1732003, drugName: '1 ML morphine sulfate 8 MG/ML Cartridge', doseFormCode: 1649572, doseFormName: 'Cartridge', ingredientCode: 7052, ingredientName: 'Morphine', strength: '8 MG/ML', strengthValue: 8.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1732006, drugName: '1 ML morphine sulfate 4 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '4 MG/ML', strengthValue: 4.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1732011, drugName: '1 ML morphine sulfate 8 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '8 MG/ML', strengthValue: 8.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1732014, drugName: '1 ML morphine sulfate 4 MG/ML Cartridge', doseFormCode: 1649572, doseFormName: 'Cartridge', ingredientCode: 7052, ingredientName: 'Morphine', strength: '4 MG/ML', strengthValue: 4.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1732136, drugName: '1 ML morphine sulfate 5 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '5 MG/ML', strengthValue: 5.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1732138, drugName: '30 ML morphine sulfate 5 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '5 MG/ML', strengthValue: 5.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1733080, drugName: '1 ML morphine sulfate 15 MG/ML Cartridge', doseFormCode: 1649572, doseFormName: 'Cartridge', ingredientCode: 7052, ingredientName: 'Morphine', strength: '15 MG/ML', strengthValue: 15.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1735003, drugName: '2 ML fentanyl 0.05 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.05 MG/ML', strengthValue: 0.05, strengthUnit: 'MG/ML' },\n  { drugCode: 1735006, drugName: '10 ML fentanyl 0.05 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.05 MG/ML', strengthValue: 0.05, strengthUnit: 'MG/ML' },\n  { drugCode: 1735007, drugName: '5 ML fentanyl 0.05 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.05 MG/ML', strengthValue: 0.05, strengthUnit: 'MG/ML' },\n  { drugCode: 1735008, drugName: '20 ML fentanyl 0.05 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.05 MG/ML', strengthValue: 0.05, strengthUnit: 'MG/ML' },\n  { drugCode: 1735013, drugName: '50 ML fentanyl 0.05 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.05 MG/ML', strengthValue: 0.05, strengthUnit: 'MG/ML' },\n  { drugCode: 1740007, drugName: '{2 (fentanyl 0.6 MG/ACTUAT Mucosal Spray) } Pack', doseFormCode: 746839, doseFormName: 'Pack', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.6 MG/ACTUAT', strengthValue: 0.6, strengthUnit: 'MG/ACTUAT' },\n  { drugCode: 1740008, drugName: '{2 (fentanyl 0.6 MG/ACTUAT Mucosal Spray [Subsys]) } Pack [Subsys 1200 MCG]', doseFormCode: 746839, doseFormName: 'Pack', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.6 MG/ACTUAT', strengthValue: 0.6, strengthUnit: 'MG/ACTUAT' },\n  { drugCode: 1740009, drugName: '{2 (fentanyl 0.8 MG/ACTUAT Mucosal Spray) } Pack', doseFormCode: 746839, doseFormName: 'Pack', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.8 MG/ACTUAT', strengthValue: 0.8, strengthUnit: 'MG/ACTUAT' },\n  { drugCode: 1740010, drugName: '{2 (fentanyl 0.8 MG/ACTUAT Mucosal Spray [Subsys]) } Pack [Subsys 1600 MCG]', doseFormCode: 746839, doseFormName: 'Pack', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.8 MG/ACTUAT', strengthValue: 0.8, strengthUnit: 'MG/ACTUAT' },\n  { drugCode: 1745881, drugName: 'Abuse-Deterrent 12 HR morphine sulfate 15 MG Extended Release Oral Tablet [Morphabond]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '15 MG', strengthValue: 15.0, strengthUnit: 'MG' },\n  { drugCode: 1745886, drugName: 'Abuse-Deterrent 12 HR morphine sulfate 100 MG Extended Release Oral Tablet [Morphabond]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 1745889, drugName: 'Abuse-Deterrent 12 HR morphine sulfate 30 MG Extended Release Oral Tablet [Morphabond]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 1745892, drugName: 'Abuse-Deterrent 12 HR morphine sulfate 60 MG Extended Release Oral Tablet [Morphabond]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '60 MG', strengthValue: 60.0, strengthUnit: 'MG' },\n  { drugCode: 1790527, drugName: 'Abuse-Deterrent 12 HR oxycodone 9 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '9 MG', strengthValue: 9.0, strengthUnit: 'MG' },\n  { drugCode: 1790533, drugName: 'Abuse-Deterrent 12 HR oxycodone 9 MG Extended Release Oral Capsule [Xtampza]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '9 MG', strengthValue: 9.0, strengthUnit: 'MG' },\n  { drugCode: 1791558, drugName: 'Abuse-Deterrent 12 HR oxycodone 13.5 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '13.5 MG', strengthValue: 13.5, strengthUnit: 'MG' },\n  { drugCode: 1791560, drugName: 'Abuse-Deterrent 12 HR oxycodone 13.5 MG Extended Release Oral Capsule [Xtampza]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '13.5 MG', strengthValue: 13.5, strengthUnit: 'MG' },\n  { drugCode: 1791567, drugName: 'Abuse-Deterrent 12 HR oxycodone 18 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '18 MG', strengthValue: 18.0, strengthUnit: 'MG' },\n  { drugCode: 1791569, drugName: 'Abuse-Deterrent 12 HR oxycodone 18 MG Extended Release Oral Capsule [Xtampza]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '18 MG', strengthValue: 18.0, strengthUnit: 'MG' },\n  { drugCode: 1791574, drugName: 'Abuse-Deterrent 12 HR oxycodone 27 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '27 MG', strengthValue: 27.0, strengthUnit: 'MG' },\n  { drugCode: 1791576, drugName: 'Abuse-Deterrent 12 HR oxycodone 27 MG Extended Release Oral Capsule [Xtampza]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '27 MG', strengthValue: 27.0, strengthUnit: 'MG' },\n  { drugCode: 1791580, drugName: 'Abuse-Deterrent 12 HR oxycodone 36 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '36 MG', strengthValue: 36.0, strengthUnit: 'MG' },\n  { drugCode: 1791582, drugName: 'Abuse-Deterrent 12 HR oxycodone 36 MG Extended Release Oral Capsule [Xtampza]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '36 MG', strengthValue: 36.0, strengthUnit: 'MG' },\n  { drugCode: 1792707, drugName: 'codeine phosphate 2 MG/ML / guaifenesin 40 MG/ML / pseudoephedrine hydrochloride 6 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1797650, drugName: 'buprenorphine 74.2 MG Drug Implant', doseFormCode: 657710, doseFormName: 'Drug Implant', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '74.2 MG', strengthValue: 74.2, strengthUnit: 'MG' },\n  { drugCode: 1797655, drugName: 'buprenorphine 74.2 MG Drug Implant [Probuphine]', doseFormCode: 657710, doseFormName: 'Drug Implant', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '74.2 MG', strengthValue: 74.2, strengthUnit: 'MG' },\n  { drugCode: 1806701, drugName: '12 HR naltrexone hydrochloride 1.2 MG / oxycodone hydrochloride 10 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1806707, drugName: '12 HR naltrexone hydrochloride 1.2 MG / oxycodone hydrochloride 10 MG Extended Release Oral Capsule [Troxyca]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1809204, drugName: 'butorphanol tartrate 2 MG/ML Injectable Solution [Torbugesic]', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 1841, ingredientName: 'Butorphanol', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1811473, drugName: '1 ML pentazocine 30 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 8001, ingredientName: 'Pentazocine', strength: '30 MG/ML', strengthValue: 30.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1812164, drugName: 'acetaminophen 325 MG / caffeine 30 MG / dihydrocodeine bitartrate 16 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 23088, ingredientName: 'dihydrocodeine', strength: '16 MG', strengthValue: 16.0, strengthUnit: 'MG' },\n  { drugCode: 1860127, drugName: 'Abuse-Deterrent 12 HR oxycodone hydrochloride 60 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '60 MG', strengthValue: 60.0, strengthUnit: 'MG' },\n  { drugCode: 1860129, drugName: 'Abuse-Deterrent 12 HR oxycodone hydrochloride 20 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 1860137, drugName: 'Abuse-Deterrent 12 HR oxycodone hydrochloride 40 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '40 MG', strengthValue: 40.0, strengthUnit: 'MG' },\n  { drugCode: 1860148, drugName: 'Abuse-Deterrent 12 HR oxycodone hydrochloride 80 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '80 MG', strengthValue: 80.0, strengthUnit: 'MG' },\n  { drugCode: 1860151, drugName: 'Abuse-Deterrent 12 HR oxycodone hydrochloride 30 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 1860154, drugName: 'Abuse-Deterrent 12 HR oxycodone hydrochloride 15 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '15 MG', strengthValue: 15.0, strengthUnit: 'MG' },\n  { drugCode: 1860157, drugName: 'Abuse-Deterrent 12 HR oxycodone hydrochloride 10 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1860491, drugName: '12 HR hydrocodone bitartrate 10 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1860492, drugName: '12 HR hydrocodone bitartrate 10 MG Extended Release Oral Capsule [Zohydro]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 1860493, drugName: '12 HR hydrocodone bitartrate 15 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '15 MG', strengthValue: 15.0, strengthUnit: 'MG' },\n  { drugCode: 1860494, drugName: '12 HR hydrocodone bitartrate 15 MG Extended Release Oral Capsule [Zohydro]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '15 MG', strengthValue: 15.0, strengthUnit: 'MG' },\n  { drugCode: 1860495, drugName: '12 HR hydrocodone bitartrate 20 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 1860496, drugName: '12 HR hydrocodone bitartrate 20 MG Extended Release Oral Capsule [Zohydro]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '20 MG', strengthValue: 20.0, strengthUnit: 'MG' },\n  { drugCode: 1860497, drugName: '12 HR hydrocodone bitartrate 30 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 1860498, drugName: '12 HR hydrocodone bitartrate 30 MG Extended Release Oral Capsule [Zohydro]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 1860499, drugName: '12 HR hydrocodone bitartrate 40 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '40 MG', strengthValue: 40.0, strengthUnit: 'MG' },\n  { drugCode: 1860500, drugName: '12 HR hydrocodone bitartrate 40 MG Extended Release Oral Capsule [Zohydro]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '40 MG', strengthValue: 40.0, strengthUnit: 'MG' },\n  { drugCode: 1860501, drugName: '12 HR hydrocodone bitartrate 50 MG Extended Release Oral Capsule', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '50 MG', strengthValue: 50.0, strengthUnit: 'MG' },\n  { drugCode: 1860502, drugName: '12 HR hydrocodone bitartrate 50 MG Extended Release Oral Capsule [Zohydro]', doseFormCode: 316943, doseFormName: 'Extended Release Oral Capsule', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '50 MG', strengthValue: 50.0, strengthUnit: 'MG' },\n  { drugCode: 1864412, drugName: 'buprenorphine 0.7 MG / naloxone 0.18 MG Sublingual Tablet', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.7 MG', strengthValue: 0.7, strengthUnit: 'MG' },\n  { drugCode: 1864414, drugName: 'buprenorphine 0.7 MG / naloxone 0.18 MG Sublingual Tablet [Zubsolv]', doseFormCode: 317007, doseFormName: 'Sublingual Tablet', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '0.7 MG', strengthValue: 0.7, strengthUnit: 'MG' },\n  { drugCode: 1866543, drugName: '1 ML nalbuphine hydrochloride 10 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7238, ingredientName: 'Nalbuphine', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1866551, drugName: '1 ML nalbuphine hydrochloride 20 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7238, ingredientName: 'Nalbuphine', strength: '20 MG/ML', strengthValue: 20.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1871434, drugName: 'Abuse-Deterrent 12 HR morphine sulfate 15 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '15 MG', strengthValue: 15.0, strengthUnit: 'MG' },\n  { drugCode: 1871440, drugName: 'Abuse-Deterrent 12 HR morphine sulfate 15 MG Extended Release Oral Tablet [Arymo]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '15 MG', strengthValue: 15.0, strengthUnit: 'MG' },\n  { drugCode: 1871441, drugName: 'Abuse-Deterrent 12 HR morphine sulfate 30 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 1871443, drugName: 'Abuse-Deterrent 12 HR morphine sulfate 30 MG Extended Release Oral Tablet [Arymo]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 1871444, drugName: 'Abuse-Deterrent 12 HR morphine sulfate 60 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '60 MG', strengthValue: 60.0, strengthUnit: 'MG' },\n  { drugCode: 1871446, drugName: 'Abuse-Deterrent 12 HR morphine sulfate 60 MG Extended Release Oral Tablet [Arymo]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '60 MG', strengthValue: 60.0, strengthUnit: 'MG' },\n  { drugCode: 1872234, drugName: 'Abuse-Deterrent 12 HR morphine sulfate 100 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 7052, ingredientName: 'Morphine', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 1872265, drugName: '1 ML hydromorphone hydrochloride 1 MG/ML Prefilled Syringe [Dilaudid]', doseFormCode: 721656, doseFormName: 'Prefilled Syringe', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1872269, drugName: '1 ML hydromorphone hydrochloride 2 MG/ML Prefilled Syringe [Dilaudid]', doseFormCode: 721656, doseFormName: 'Prefilled Syringe', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1872271, drugName: '1 ML hydromorphone hydrochloride 4 MG/ML Prefilled Syringe', doseFormCode: 721656, doseFormName: 'Prefilled Syringe', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '4 MG/ML', strengthValue: 4.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1872272, drugName: '1 ML hydromorphone hydrochloride 4 MG/ML Prefilled Syringe [Dilaudid]', doseFormCode: 721656, doseFormName: 'Prefilled Syringe', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '4 MG/ML', strengthValue: 4.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1872752, drugName: '0.5 ML hydromorphone hydrochloride 1 MG/ML Prefilled Syringe [Dilaudid]', doseFormCode: 721656, doseFormName: 'Prefilled Syringe', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '1 MG/ML', strengthValue: 1.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1944529, drugName: 'Abuse-Deterrent oxycodone hydrochloride 15 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '15 MG', strengthValue: 15.0, strengthUnit: 'MG' },\n  { drugCode: 1944535, drugName: 'Abuse-Deterrent oxycodone hydrochloride 15 MG Oral Tablet [Roxybond]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '15 MG', strengthValue: 15.0, strengthUnit: 'MG' },\n  { drugCode: 1944538, drugName: 'Abuse-Deterrent oxycodone hydrochloride 30 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 1944540, drugName: 'Abuse-Deterrent oxycodone hydrochloride 30 MG Oral Tablet [Roxybond]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '30 MG', strengthValue: 30.0, strengthUnit: 'MG' },\n  { drugCode: 1944541, drugName: 'Abuse-Deterrent oxycodone hydrochloride 5 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 1944543, drugName: 'Abuse-Deterrent oxycodone hydrochloride 5 MG Oral Tablet [Roxybond]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 1946525, drugName: 'Matrix Delivery 24 HR tramadol hydrochloride 300 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '300 MG', strengthValue: 300.0, strengthUnit: 'MG' },\n  { drugCode: 1946527, drugName: 'Matrix Delivery 24 HR tramadol hydrochloride 200 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '200 MG', strengthValue: 200.0, strengthUnit: 'MG' },\n  { drugCode: 1946529, drugName: 'Matrix Delivery 24 HR tramadol hydrochloride 100 MG Extended Release Oral Tablet', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 1947138, drugName: 'butorphanol 10 MG/ML Injectable Solution [Torphaject]', doseFormCode: 316949, doseFormName: 'Injectable Solution', ingredientCode: 1841, ingredientName: 'Butorphanol', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1990745, drugName: 'methadone hydrochloride 40 MG Tablet for Oral Suspension [Diskets]', doseFormCode: 1861409, doseFormName: 'Tablet for Oral Suspension', ingredientCode: 6813, ingredientName: 'Methadone', strength: '40 MG', strengthValue: 40.0, strengthUnit: 'MG' },\n  { drugCode: 1995536, drugName: 'acetaminophen 325 MG / caffeine 30 MG / dihydrocodeine bitartrate 16 MG Oral Tablet [Panlor Reformulated Jan 2018]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 23088, ingredientName: 'dihydrocodeine', strength: '16 MG', strengthValue: 16.0, strengthUnit: 'MG' },\n  { drugCode: 1996184, drugName: '0.5 ML buprenorphine 200 MG/ML Prefilled Syringe', doseFormCode: 721656, doseFormName: 'Prefilled Syringe', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '200 MG/ML', strengthValue: 200.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1996189, drugName: '0.5 ML buprenorphine 200 MG/ML Prefilled Syringe [Sublocade]', doseFormCode: 721656, doseFormName: 'Prefilled Syringe', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '200 MG/ML', strengthValue: 200.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1996192, drugName: '1.5 ML buprenorphine 200 MG/ML Prefilled Syringe', doseFormCode: 721656, doseFormName: 'Prefilled Syringe', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '200 MG/ML', strengthValue: 200.0, strengthUnit: 'MG/ML' },\n  { drugCode: 1996193, drugName: '1.5 ML buprenorphine 200 MG/ML Prefilled Syringe [Sublocade]', doseFormCode: 721656, doseFormName: 'Prefilled Syringe', ingredientCode: 1819, ingredientName: 'Buprenorphine', strength: '200 MG/ML', strengthValue: 200.0, strengthUnit: 'MG/ML' },\n  { drugCode: 2003714, drugName: '1 ML morphine sulfate 2 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 2045500, drugName: 'acetaminophen 300 MG / oxycodone hydrochloride 2.5 MG Oral Tablet [Nalocet]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '2.5 MG', strengthValue: 2.5, strengthUnit: 'MG' },\n  { drugCode: 2055307, drugName: '20 ML morphine sulfate 10 MG/ML Injection [Mitigo]', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '10 MG/ML', strengthValue: 10.0, strengthUnit: 'MG/ML' },\n  { drugCode: 2055311, drugName: '20 ML morphine sulfate 25 MG/ML Injection [Mitigo]', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 7052, ingredientName: 'Morphine', strength: '25 MG/ML', strengthValue: 25.0, strengthUnit: 'MG/ML' },\n  { drugCode: 2056893, drugName: 'chlorpheniramine maleate 0.8 MG/ML / codeine phosphate 2 MG/ML / phenylephrine hydrochloride 2 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 2670, ingredientName: 'Codeine', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 2058845, drugName: 'levorphanol tartrate 3 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 6378, ingredientName: 'Levorphanol', strength: '3 MG', strengthValue: 3.0, strengthUnit: 'MG' },\n  { drugCode: 2099286, drugName: '12 HR chlorpheniramine maleate 8 MG / codeine phosphate 54.3 MG Extended Release Oral Tablet [Tuxarin]', doseFormCode: 316945, doseFormName: 'Extended Release Oral Tablet', ingredientCode: 2670, ingredientName: 'Codeine', strength: '54.3 MG', strengthValue: 54.3, strengthUnit: 'MG' },\n  { drugCode: 2105822, drugName: 'acetaminophen 60 MG/ML / oxycodone hydrochloride 2 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 2105929, drugName: 'acetaminophen 325 MG / caffeine 30 MG / dihydrocodeine bitartrate 16 MG Oral Tablet [Dvorah]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 23088, ingredientName: 'dihydrocodeine', strength: '16 MG', strengthValue: 16.0, strengthUnit: 'MG' },\n  { drugCode: 2168270, drugName: '1 ML fentanyl 0.05 MG/ML Injection', doseFormCode: 1649574, doseFormName: 'Injection', ingredientCode: 4337, ingredientName: 'Fentanyl', strength: '0.05 MG/ML', strengthValue: 0.05, strengthUnit: 'MG/ML' },\n  { drugCode: 2179635, drugName: 'tramadol hydrochloride 100 MG Oral Tablet', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '100 MG', strengthValue: 100.0, strengthUnit: 'MG' },\n  { drugCode: 2182349, drugName: 'chlorpheniramine maleate 0.4 MG/ML / hydrocodone bitartrate 0.5 MG/ML / phenylephrine hydrochloride 2 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 2182353, drugName: 'chlorpheniramine maleate 0.4 MG/ML / hydrocodone bitartrate 0.5 MG/ML / phenylephrine hydrochloride 2 MG/ML Oral Solution [De-Chlor HC]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.5 MG/ML', strengthValue: 0.5, strengthUnit: 'MG/ML' },\n  { drugCode: 2182355, drugName: 'chlorpheniramine maleate 0.5 MG/ML / hydrocodone bitartrate 0.65 MG/ML / phenylephrine hydrochloride 1.6 MG/ML Oral Solution [Relasin HC]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 5489, ingredientName: 'Hydrocodone', strength: '0.65 MG/ML', strengthValue: 0.65, strengthUnit: 'MG/ML' },\n  { drugCode: 2277368, drugName: '1 ML hydromorphone hydrochloride 0.2 MG/ML Prefilled Syringe', doseFormCode: 721656, doseFormName: 'Prefilled Syringe', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '0.2 MG/ML', strengthValue: 0.2, strengthUnit: 'MG/ML' },\n  { drugCode: 2277370, drugName: '1 ML hydromorphone hydrochloride 0.2 MG/ML Prefilled Syringe [Dilaudid]', doseFormCode: 721656, doseFormName: 'Prefilled Syringe', ingredientCode: 3423, ingredientName: 'Hydromorphone', strength: '0.2 MG/ML', strengthValue: 0.2, strengthUnit: 'MG/ML' },\n  { drugCode: 2279510, drugName: 'acetaminophen 300 MG / oxycodone hydrochloride 10 MG Oral Tablet [Prolate]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '10 MG', strengthValue: 10.0, strengthUnit: 'MG' },\n  { drugCode: 2279512, drugName: 'acetaminophen 300 MG / oxycodone hydrochloride 5 MG Oral Tablet [Prolate]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '5 MG', strengthValue: 5.0, strengthUnit: 'MG' },\n  { drugCode: 2279514, drugName: 'acetaminophen 300 MG / oxycodone hydrochloride 7.5 MG Oral Tablet [Prolate]', doseFormCode: 317541, doseFormName: 'Oral Tablet', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '7.5 MG', strengthValue: 7.5, strengthUnit: 'MG' },\n  { drugCode: 2281851, drugName: 'acetaminophen 60 MG/ML / oxycodone hydrochloride 2 MG/ML Oral Solution [Prolate]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 7804, ingredientName: 'Oxycodone', strength: '2 MG/ML', strengthValue: 2.0, strengthUnit: 'MG/ML' },\n  { drugCode: 2395808, drugName: 'tramadol hydrochloride 5 MG/ML Oral Solution', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '5 MG/ML', strengthValue: 5.0, strengthUnit: 'MG/ML' },\n  { drugCode: 2395814, drugName: 'tramadol hydrochloride 5 MG/ML Oral Solution [Qdolo]', doseFormCode: 316968, doseFormName: 'Oral Solution', ingredientCode: 10689, ingredientName: 'Tramadol', strength: '5 MG/ML', strengthValue: 5.0, strengthUnit: 'MG/ML' }\n}"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 21
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "CDCMMEClinicalConversionFactors"
    },
    {
      "url" : "name",
      "valueString" : "CDCMMEClinicalConversionFactorsCodeSystem"
    },
    {
      "url" : "statement",
      "valueString" : "define CDCMMEClinicalConversionFactorsCodeSystem:\n    CodeSystem {\n        name: string { value: 'CDCMMEClinicalConversionFactors' },\n        supplements: canonical { value: 'http://www.nlm.nih.gov/research/umls/rxnorm' },\n        concept: List<FHIR.CodeSystem.Concept> {\n            FHIR.CodeSystem.Concept {\n                code: code { value: '2670' },\n                display: string { value: 'Codeine' },\n                property: List<FHIR.CodeSystem.\"Concept\".\"Property\"> {\n                    FHIR.CodeSystem.\"Concept\".\"Property\" {\n                            code: code { value: 'conversion-factor' },\n                            value: decimal { value: 0.15 }\n                    }\n                }\n            },\n            FHIR.CodeSystem.Concept {\n                code: code { value: '4337' },\n                display: string { value: 'Fentanyl' },\n                property: List<FHIR.CodeSystem.\"Concept\".\"Property\"> {\n                    FHIR.CodeSystem.\"Concept\".\"Property\" {\n                            code: code { value: 'dose-form-conversion-factor' },\n                            value: string { value: '316987:7200@0.33333333' }\n                    }\n                }\n            },\n            FHIR.CodeSystem.Concept {\n                code: code { value: '3423' },\n                display: string { value: 'Hydromorphone' },\n                property: List<FHIR.CodeSystem.\"Concept\".\"Property\"> {\n                    FHIR.CodeSystem.\"Concept\".\"Property\" {\n                            code: code { value: 'conversion-factor' },\n                            value: decimal { value: 4 }\n                    }\n                }\n            },\n            FHIR.CodeSystem.Concept {\n                code: code { value: '5489' },\n                display: string { value: 'Hydrocodone' },\n                property: List<FHIR.CodeSystem.\"Concept\".\"Property\"> {\n                    FHIR.CodeSystem.\"Concept\".\"Property\" {\n                            code: code { value: 'conversion-factor' },\n                            value: decimal { value: 1 }\n                    }\n                }\n            },\n            FHIR.CodeSystem.Concept {\n                code: code { value: '6813' },\n                display: string { value: 'Methadone' },\n                property: List<FHIR.CodeSystem.\"Concept\".\"Property\"> {\n                    FHIR.CodeSystem.\"Concept\".\"Property\" {\n                            code: code { value: 'dose-range-conversion-factor' },\n                            value: string { value: '1-20:4' }\n                    },\n                    FHIR.CodeSystem.\"Concept\".\"Property\" {\n                            code: code { value: 'dose-range-conversion-factor' },\n                            value: string { value: '21-40:8' }\n                    },\n                    FHIR.CodeSystem.\"Concept\".\"Property\" {\n                            code: code { value: 'dose-range-conversion-factor' },\n                            value: string { value: '41-60:10' }\n                    },\n                    FHIR.CodeSystem.\"Concept\".\"Property\" {\n                            code: code { value: 'dose-range-conversion-factor' },\n                            value: string { value: '61-*:12' }\n                    }\n                }\n            },\n            FHIR.CodeSystem.Concept {\n                code: code { value: '7052' },\n                display: string { value: 'Morphine' },\n                property: List<FHIR.CodeSystem.\"Concept\".\"Property\"> {\n                    FHIR.CodeSystem.\"Concept\".\"Property\" {\n                            code: code { value: 'conversion-factor' },\n                            value: decimal { value: 1 }\n                    }\n                }\n            },\n            FHIR.CodeSystem.Concept {\n                code: code { value: '7804' },\n                display: string { value: 'Oxycodone' },\n                property: List<FHIR.CodeSystem.\"Concept\".\"Property\"> {\n                    FHIR.CodeSystem.\"Concept\".\"Property\" {\n                            code: code { value: 'conversion-factor' },\n                            value: decimal { value: 1.5 }\n                    }\n                }\n            },\n            FHIR.CodeSystem.Concept {\n                code: code { value: '7814' },\n                display: string { value: 'Oxymorphone' },\n                property: List<FHIR.CodeSystem.\"Concept\".\"Property\"> {\n                    FHIR.CodeSystem.\"Concept\".\"Property\" {\n                            code: code { value: 'conversion-factor' },\n                            value: decimal { value: 3 }\n                    }\n                }\n            }\n        }\n    }"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 22
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "ConversionFactors"
    },
    {
      "url" : "name",
      "valueString" : "ConversionFactorSupplement"
    },
    {
      "url" : "statement",
      "valueString" : "/*\nThe use of the CDCMMEClinicalConversionFactors is a workaround for the fact that we can't retrieve the formally \ndefined CodeSystem resource (https://fhir.org/guides/cdc/opioid-mme-r4/CodeSystem-CDCMMEClinicalConversionFactors.html) \nfrom the FHIR server\n*/\ndefine ConversionFactorSupplement:\n  CDCMMEClinicalConversionFactors.\"CDCMMEClinicalConversionFactorsCodeSystem\" C\n    where C.supplements.value = 'http://www.nlm.nih.gov/research/umls/rxnorm'\n    and (\n      C.name.value = ConversionFactorSupplementName\n        or exists (\n          C.useContext UC\n            where UC.code ~ \"Task Usage Context\"\n              and UC.value ~ \"MME Calculation\"\n        )\n    )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 23
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "Can the implementing EHR support queries for past medications by date range?"
    },
    {
      "url" : "statement",
      "valueString" : "// Subroutine 2 - Past Medications\ndefine \"Can the implementing EHR support queries for past medications by date range?\":\n  true"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 24
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "Active Ambulatory Opioid Rx"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Active Ambulatory Opioid Rx\":\n    if Config.\"Can the implementing EHR support queries for past medications by date range?\" then\n      (\n        \"Get MedicationRequest Medication as Code\"(\"Get Active Ambulatory Medication Requests\"([MedicationRequest]))\n      ) Rx\n        where date from Rx.authoredOn 2 years or less on or before Today()\n          and Rx.medication in \"Opioid analgesics with ambulatory misuse potential\"\n    else\n        List<FHIR.MedicationRequest>{}"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 25
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC04And05"
    },
    {
      "url" : "name",
      "valueString" : "Total MME"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Total MME\":\n  MMECalculator.TotalMME(\n    (\n      \"Chronic Pain Opioid Analgesic with Ambulatory Misuse Potential Prescriptions\"\n        union Common.\"Active Ambulatory Opioid Rx\"\n    ) AmbulatoryOpioidPrescription\n      where Routines.\"Is Subacute or Chronic Pain Prescription?\"( AmbulatoryOpioidPrescription )\n  )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 26
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC04And05"
    },
    {
      "url" : "name",
      "valueString" : "Inclusion Criteria"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Inclusion Criteria\":\n  \"Patient Is Being Prescribed Opioid Analgesic with Ambulatory Misuse Potential\"\n    and Routines.\"CDC 2022 Guideline General Inclusion Criteria\"\n    and \"Total MME\" >= 50 '{MME}/d'"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 27
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "Conditions Indicating End of Life or With Limited Life Expectancy"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Conditions Indicating End of Life or With Limited Life Expectancy\":\n  (\n    \"US Core-Categorized Conditions\" C\n      where C.code in \"Conditions likely terminal for opioid prescribing\"\n        and C.clinicalStatus in \"Active Condition\"\n  )\n  union\n  (\n    \"US Core-Categorized Conditions\" C\n      where C.code in \"Limited life expectancy conditions\"\n        and C.clinicalStatus in \"Active Condition\"\n  )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 28
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommonConfig"
    },
    {
      "url" : "name",
      "valueString" : "Hospice Findings Exclusion Enabled"
    },
    {
      "url" : "statement",
      "valueString" : "// OpioidCDSCommon\ndefine \"Hospice Findings Exclusion Enabled\":\n  false"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 29
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "Admitted/Referred/Discharged to Hospice Care"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Admitted/Referred/Discharged to Hospice Care\":\n  (\n    if (Config.\"Hospice Findings Exclusion Enabled\") then\n      [Observation: code in \"Hospice Finding Codes\"] O\n        where not (O.status.value in { 'unknown', 'entered-in-error', 'cancelled' })\n    else\n      {}\n  )\n  union\n  (\n    [Encounter] E\n      where date from E.period.start 1 year or less on or before Today()\n        and (\n          if E.hospitalization.dischargeDisposition.coding is null\n              or not exists (E.hospitalization.dischargeDisposition.coding)\n            then false\n          else E.hospitalization.dischargeDisposition in \"Hospice Disposition\"\n        )\n        and E.status.value in { 'planned', 'arrived', 'in-progress', 'finished', 'onleave' }\n  )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 30
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "End of Life Assessment"
    },
    {
      "url" : "statement",
      "valueString" : "define \"End of Life Assessment\":\n    // 1. Conditions indicating end of life or with limited life expectancy\n    exists (\n      \"Conditions Indicating End of Life or With Limited Life Expectancy\"\n    )\n    // 2. Admitted/referred/discharged to hospice care\n    or exists (\n      \"Admitted/Referred/Discharged to Hospice Care\"\n    )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 31
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC04And05"
    },
    {
      "url" : "name",
      "valueString" : "Exclusion Criteria"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Exclusion Criteria\":\n  Common.\"End of Life Assessment\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 32
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSREC04And05"
    },
    {
      "url" : "name",
      "valueString" : "Is Recommendation Applicable?"
    },
    {
      "url" : "statement",
      "valueString" : "define \"Is Recommendation Applicable?\":\n  \"Inclusion Criteria\"\n    and not \"Exclusion Criteria\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 33
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "Is Opioid Analgesic with Ambulatory Misuse Potential?"
    },
    {
      "url" : "statement",
      "valueString" : "define function \"Is Opioid Analgesic with Ambulatory Misuse Potential?\"(value List<MedicationRequest>):\n  (\"Get MedicationRequest Medication as Code\"(value)) Rx\n    where Rx.medication in \"Opioid analgesics with ambulatory misuse potential\" \n      and Rx.category in \"Community\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 34
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "Get MedicationRequest Medication as Code"
    },
    {
      "url" : "statement",
      "valueString" : "define function \"Get MedicationRequest Medication as Code\"(value List<MedicationRequest>):\n  value Rx\n    let Med: \n      if Rx.medication is Reference then singleton from (\n        [Medication] M\n          where M.id = (Last(Split((Rx.medication as FHIR.Reference).reference, '/')))\n      ) else null\n    return \n      MedicationRequest {\n        id: Rx.id,\n        status: Rx.status,\n        intent: Rx.intent,\n        category: Rx.category,\n        medication: if Rx.medication is Reference then Med.code else Rx.medication as CodeableConcept,\n        subject: Rx.subject,\n        authoredOn: Rx.authoredOn,\n        recorder: Rx.recorder,\n        dosageInstruction: Rx.dosageInstruction,\n        dispenseRequest: Rx.dispenseRequest\n      }"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 35
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "FHIRHelpers"
    },
    {
      "url" : "name",
      "valueString" : "ToString"
    },
    {
      "url" : "statement",
      "valueString" : "define function ToString(value string): value.value"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 36
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "FHIRHelpers"
    },
    {
      "url" : "name",
      "valueString" : "ToConcept"
    },
    {
      "url" : "statement",
      "valueString" : "define function ToConcept(concept FHIR.CodeableConcept):\n    if concept is null then\n        null\n    else\n        System.Concept {\n            codes: concept.coding C return ToCode(C),\n            display: concept.text.value\n        }"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 37
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "FHIRHelpers"
    },
    {
      "url" : "name",
      "valueString" : "ToCode"
    },
    {
      "url" : "statement",
      "valueString" : "define function ToCode(coding FHIR.Coding):\n    if coding is null then\n        null\n    else\n        System.Code {\n          code: coding.code.value,\n          system: coding.system.value,\n          version: coding.version.value,\n          display: coding.display.value\n        }"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 38
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Is Subacute or Chronic Pain Prescription?"
    },
    {
      "url" : "statement",
      "valueString" : "// End of Active Cancer Treatment Routine\n\n/*\n**  Routine #4\n**  For Subacute or Chronic Pain Routine\n**\n**  Definition                  | Answer to Proceed   | Details                                        | Data (Terminology) Requirement\n**  -----------------------------------------------------------------------------------------------------------------------------------\n**  Order for opioid analgesic  | Yes                 | Order for opioid analgesics with ambulatory    | Opioid analgesics with\n**  with expected supply        |                     | misuse potential with a supply duration of >=  | ambulatory misuse potential\n**  duration >= 28 days         |                     | 28 days                                        |\n**                              |                     |                                                |\n**                              |                     | - Subacute definition = order for opioid       |\n**                              |                     |   analgesics with ambulatory misuse            |\n**                              |                     |   potential with a supply duration of one to   |\n**                              |                     |   two months.                                  |\n**                              |                     | - Chronic pain definition = order for opioid   |\n**                              |                     |   analgesics with ambulatory misuse            |\n**                              |                     |   potential with a supply duration of >= two   |\n**                              |                     |   months.                                      |\n**  -----------------------------------------------------------------------------------------------------------------------------------\n**\n*/\n\ndefine function \"Is Subacute or Chronic Pain Prescription?\"(prescription FHIR.MedicationRequest):\n  \"Is Subacute or Chronic Pain Using Expected Supply Duration\"(prescription)\n    or \"Is Subacute or Chronic Pain Using Validity Period\"(prescription)"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 39
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Is Subacute or Chronic Pain Using Expected Supply Duration"
    },
    {
      "url" : "statement",
      "valueString" : "define function \"Is Subacute or Chronic Pain Using Expected Supply Duration\"(prescription FHIR.MedicationRequest):\n  (\n    prescription.dispenseRequest is not null\n      and prescription.dispenseRequest.expectedSupplyDuration is not null\n      and (\n        Common.GetDurationInDays(prescription.dispenseRequest.expectedSupplyDuration) >= 28 days \n      )\n  )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 40
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "GetDurationInDays"
    },
    {
      "url" : "statement",
      "valueString" : "define function GetDurationInDays(value FHIR.Duration):\n  if value is null then null\n  else\n    case\n      when value.code.value ~ 'a' then System.Quantity{ value: value.value.value * 365.0, unit: 'days' }\n      when value.code.value ~ 'mo' then System.Quantity{ value: value.value.value * 30.0, unit: 'days' }\n      when value.code.value ~ 'wk' then System.Quantity{ value: value.value.value * 7.0, unit: 'days' }\n      when value.code.value ~ 'd' then System.Quantity{ value: value.value.value, unit: 'days' }\n      when value.code.value ~ 'h' then System.Quantity{ value: value.value.value / 24.0, unit: 'days' }\n      when value.code.value ~ 'min' then System.Quantity{ value: value.value.value / 60.0 / 24.0, unit: 'days' }\n      when value.code.value ~ 's' then System.Quantity{ value: value.value.value / 60.0 / 60.0 / 24.0, unit: 'days' }\n      when value.code.value ~ 'ms' then System.Quantity{ value: value.value.value / 60.0 / 60.0 / 24.0 / 1000.0, unit: 'days' }\n      when value.code.value is null then Message(1000, true, 'Undefined', 'Error', 'Duration unit code is null')\n      else Message(1000, true, 'Undefined', 'Error', 'Unsupported duration unit code: ' + value.code.value)\nend"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 41
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSRoutines"
    },
    {
      "url" : "name",
      "valueString" : "Is Subacute or Chronic Pain Using Validity Period"
    },
    {
      "url" : "statement",
      "valueString" : "define function \"Is Subacute or Chronic Pain Using Validity Period\"(prescription FHIR.MedicationRequest):\n  (\n    prescription.dispenseRequest is not null\n      and prescription.dispenseRequest.validityPeriod is not null\n      and (\n        days between prescription.dispenseRequest.validityPeriod.start and prescription.dispenseRequest.validityPeriod.end >= 28 \n      )\n  )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 42
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "FHIRHelpers"
    },
    {
      "url" : "name",
      "valueString" : "ToDateTime"
    },
    {
      "url" : "statement",
      "valueString" : "define function ToDateTime(value dateTime): value.value"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 43
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "MMECalculator"
    },
    {
      "url" : "name",
      "valueString" : "TotalMME"
    },
    {
      "url" : "statement",
      "valueString" : "/*\nCalculates total Morphine Milligram Equivalent (MME) for the given list of medications.\nThe calculation assumes the most aggressive dosing, and is performed for all\nmedications in the given list (i.e. no additional filtering for status is performed).\n*/\ndefine function TotalMME(prescriptions List<MedicationRequest>):\n  OMTKLogic.Quantity(\n    Sum((MME(prescriptions)) M return M.mme.value),\n    '{MME}/d'\n  )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 44
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OMTKLogic"
    },
    {
      "url" : "name",
      "valueString" : "Quantity"
    },
    {
      "url" : "statement",
      "valueString" : "define function Quantity(value Decimal, unit String):\n  if value is not null then\n    Quantity { value: value, unit: unit }\n  else\n    null"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 45
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "MMECalculator"
    },
    {
      "url" : "name",
      "valueString" : "MME"
    },
    {
      "url" : "statement",
      "valueString" : "/*\nCalculates Morphine Milligram Equivalent (MME) for each medication in the given\nlist. The calculation assumes the most aggresive dosing, and is performed for all\nmedications in the given list (i.e. no additional filtering for status is performed).\n*/\ndefine function MME(prescriptions List<MedicationRequest>):\n  (Prescriptions(prescriptions)) P\n    let mmePerIngredient: OMTKLogic.CalculateMMEs({ { rxNormCode: P.rxNormCode, doseQuantity: P.dose, dosesPerDay: P.dosesPerDay } })\n    return {\n      rxNormCode: P.rxNormCode,\n      isDraft: P.isDraft,\n      isPRN: P.isPRN,\n      prescription: P.prescription,\n      dailyDose: Combine(mmePerIngredient X return X.dailyDoseDescription, '\\r\\n'),\n      mme: Sum(mmePerIngredient X return X.mme)\n    }"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 46
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "MMECalculator"
    },
    {
      "url" : "name",
      "valueString" : "Prescriptions"
    },
    {
      "url" : "statement",
      "valueString" : "/*\nExtracts the relevant information for prescription calculation from a list of\nFHIR MedicationRequest resources. This assumes a MedicationRequest that conforms\nto the MMEMedicationRequest profile, specifically:\n* 1 and only 1 dosageInstruction\n* 1 and only 1 doseAndRate\n* 1 timing with 1 repeat\n* frequency, frequencyMax, defaulting to 1\n* period, periodUnit, defaulting to 1 'd'\n* doseQuantity or doseRange\n* timeOfDay\n\nNote that if timeOfDay is specified in addition to frequency and period, it is ignored (i.e. assumed to be consistent with the specified frequency and period).\nTimeOfDay is only used to determine timesPerDay if frequency and period are not specified.\n*/\ndefine function Prescriptions(Orders List<MedicationRequest>):\n  Orders O\n    let\n      rxNormCode: OMTKLogic.GetMedicationCode(O.medication),\n      medicationName: OMTKLogic.GetMedicationName(rxNormCode),\n      // NOTE: Assuming a single dosage instruction element\n      dosageInstruction: singleton from O.dosageInstruction,\n      //  NOTE: Some systems return multiple doseAndRate entries, with system-specific codes for the types. In those cases,\n      //  this logic should select the most appropriate dose and rate, but standardization on doseAndRate type codes is\n      //  needed to make this logic shareable\n      doseAndRate: singleton from (dosageInstruction.doseAndRate DR where DR.type is null or DR.type.text = 'ordered'),\n      repeat: dosageInstruction.timing.repeat,\n      frequency: Coalesce(repeat.frequencyMax.value, repeat.frequency.value),\n      period: OMTKLogic.Quantity(repeat.period.value, repeat.periodUnit.value),\n      doseRange: ToFHIRRange(doseAndRate.dose),\n      doseQuantity: ToFHIRQuantity(doseAndRate.dose),\n      doseHigh: ToQuantity(doseRange.high as FHIR.SimpleQuantity),\n      timesPerDay: Count(repeat.timeOfDay),\n      doseDescription:\n        Coalesce(\n          ToString(ToQuantity(doseQuantity)),\n          ToString(doseRange.low.value.value) + '-' + ToString(doseRange.high.value.value) + ' ' + doseRange.high.unit.value\n        ),\n      frequencyDescription:\n        ToString(dosageInstruction.timing.repeat.frequency.value) +\n          Coalesce(\n            '-' + ToString(dosageInstruction.timing.repeat.frequencyMax.value),\n            ''\n          )\n    return {\n      rxNormCode: rxNormCode,\n      isDraft: O.status.value = 'draft',\n      // NOTE: Assuming asNeeded is expressed as a boolean\n      isPRN: dosageInstruction.asNeeded,\n      prescription:\n        if dosageInstruction.text is not null then\n          medicationName + ' ' + dosageInstruction.text.value\n        else\n          // TODO: Shouldn't need the .value here on asNeededBoolean\n          medicationName + ' ' + doseDescription + ' q' + frequencyDescription + (if dosageInstruction.asNeeded then ' PRN' else ''),\n     dose:\n        if doseAndRate.dose is not null then\n            ToQuantity(doseQuantity)\n        else\n            doseHigh,\n      dosesPerDay: Coalesce(OMTKLogic.ToDaily(frequency, period), timesPerDay, 1.0)\n    }"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 47
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OMTKLogic"
    },
    {
      "url" : "name",
      "valueString" : "GetMedicationCode"
    },
    {
      "url" : "statement",
      "valueString" : "/*\nReturns the first RxNorm code in the given concept that matches a drug code\nspecified in OMTKData.\n*/\ndefine function GetMedicationCode(concept Concept):\n  First(\n    ((concept.codes) C\n      where C.system = 'http://www.nlm.nih.gov/research/umls/rxnorm'\n        return singleton from (\n          OMTKData.DrugIngredients DI\n            where DI.drugCode = ToInteger(C.code)\n            return Code {\n              code: ToString(DI.drugCode),\n              system: 'http://www.nlm.nih.gov/research/umls/rxnorm',\n              display: DI.drugName\n            }\n        )\n    ) X\n      where X is not null\n  )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 48
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OMTKLogic"
    },
    {
      "url" : "name",
      "valueString" : "GetMedicationName"
    },
    {
      "url" : "statement",
      "valueString" : "/*\nReturns the display of the given code, if present, otherwise looks it up from the OMTK data\n*/\ndefine function GetMedicationName(rxNormCode Code):\n  if rxNormCode.display is null then\n    singleton from (\n      OMTKData.DrugIngredients DI\n        where DI.drugCode = ToInteger(rxNormCode.code)\n        return DI.drugName\n    )\n    else rxNormCode.display"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 49
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "MMECalculator"
    },
    {
      "url" : "name",
      "valueString" : "ToFHIRRange"
    },
    {
      "url" : "statement",
      "valueString" : "/*\nHelper function to force the choice of the FHIR.Range value.\nThis avoids the need for the _is_ and _as_ operators on choices,\nwhich is not implemented in the JavaScript CQL engine.\n*/\ndefine function ToFHIRRange(range FHIR.Range):\n  range"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 50
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "MMECalculator"
    },
    {
      "url" : "name",
      "valueString" : "ToFHIRQuantity"
    },
    {
      "url" : "statement",
      "valueString" : "/*\nHelper function to force the choice of the FHIR.SimpleQuantity value.\nThis avoids the need for the _is_ and _as_ operators on choices,\nwhich is not implemented in the JavaScript CQL engine.\n*/\ndefine function ToFHIRQuantity(quantity FHIR.SimpleQuantity):\n  quantity"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 51
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "MMECalculator"
    },
    {
      "url" : "name",
      "valueString" : "ToQuantity"
    },
    {
      "url" : "statement",
      "valueString" : "/*\nFHIRHelpers ToQuantity logic incorrectly uses the unit element of the FHIR Quantity,\nwhen it should be using the code element as the actual coded unit.\nhttps://github.com/cqframework/clinical_quality_language/issues/557\n\nUntil the above issue is addressed, this function provides ToQuantity functionality for this library\n*/\ndefine function ToQuantity(quantity FHIR.SimpleQuantity):\n  case\n    when quantity is null then null\n    when quantity.value is null then null\n    when quantity.system is null or quantity.system = 'http://unitsofmeasure.org' then\n      System.Quantity {\n        value: quantity.value.value,\n        unit: quantity.code.value\n      }\n   when quantity.system.value = 'http://terminology.hl7.org/CodeSystem/v3-orderableDrugForm' then\n    System.Quantity { value: quantity.value.value, unit: Coalesce(quantity.code.value, quantity.unit.value)}\n   else\n      Message(null, true, 'MMECalculator.ToQuantity.InvalidFHIRQuantity', ErrorLevel, 'Invalid FHIR Quantity code: ' & quantity.code.value)\nend"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 52
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "FHIRHelpers"
    },
    {
      "url" : "name",
      "valueString" : "ToString"
    },
    {
      "url" : "statement",
      "valueString" : "define function ToString(value uri): value.value"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 53
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "FHIRHelpers"
    },
    {
      "url" : "name",
      "valueString" : "ToBoolean"
    },
    {
      "url" : "statement",
      "valueString" : "define function ToBoolean(value boolean): value.value"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 54
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OMTKLogic"
    },
    {
      "url" : "name",
      "valueString" : "ToDaily"
    },
    {
      "url" : "statement",
      "valueString" : "/*\n  Calculates daily frequency given frequency within a period\n*/\ndefine function ToDaily(frequency Integer, period Quantity):\n  case period.unit\n    when 'h' then frequency * (24.0 / period.value)\n    when 'min' then frequency * (24.0 / period.value) * 60\n    when 's' then frequency * (24.0 / period.value) * 60 * 60\n    when 'd' then frequency * (24.0 / period.value) / 24\n    when 'wk' then frequency * (24.0 / period.value) / (24 * 7)\n    when 'mo' then frequency * (24.0 / period.value) / (24 * 30) /* assuming 30 days in month */\n    when 'a' then frequency * (24.0 / period.value) / (24 * 365) /* assuming 365 days in year */\n    when 'hour' then frequency * (24.0 / period.value)\n    when 'minute' then frequency * (24.0 / period.value) * 60\n    when 'second' then frequency * (24.0 / period.value) * 60 * 60\n    when 'day' then frequency * (24.0 / period.value) / 24\n    when 'week' then frequency * (24.0 / period.value) / (24 * 7)\n    when 'month' then frequency * (24.0 / period.value) / (24 * 30) /* assuming 30 days in month */\n    when 'year' then frequency * (24.0 / period.value) / (24 * 365) /* assuming 365 days in year */\n    when 'hours' then frequency * (24.0 / period.value)\n    when 'minutes' then frequency * (24.0 / period.value) * 60\n    when 'seconds' then frequency * (24.0 / period.value) * 60 * 60\n    when 'days' then frequency * (24.0 / period.value) / 24\n    when 'weeks' then frequency * (24.0 / period.value) / (24 * 7)\n    when 'months' then frequency * (24.0 / period.value) / (24 * 30) /* assuming 30 days in month */\n    when 'years' then frequency * (24.0 / period.value) / (24 * 365) /* assuming 365 days in year */\n    else Message(null, true, 'OMTKLogic.ToDaily.UnknownUnit', ErrorLevel, 'Unknown unit ' & period.unit)\nend"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 55
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OMTKLogic"
    },
    {
      "url" : "name",
      "valueString" : "CalculateMMEs"
    },
    {
      "url" : "statement",
      "valueString" : "/*\n  Calculates MMEs for the given input prescription information and returns it\n  as a list of tuples:\n\n  List<Tuple {\n    rxNormCode Code,\n    doseFormCode Code,\n    doseQuantity Quantity,\n    dosesPerDay Decimal,\n    ingredientCode Code,\n    strength Quantity,\n    dailyDose Quantity,\n    dailyDoseDescription String,\n    conversionFactor Decimal,\n    mme Quantity\n  }>\n*/\ndefine function CalculateMMEs(medications List<Tuple { rxNormCode Code, doseQuantity Quantity, dosesPerDay Decimal }>):\n  Flatten(\n    medications M\n      let Ingredients: GetIngredients(M.rxNormCode)\n      return\n        Ingredients I\n          let\n            adjustedDoseQuantity: M.doseQuantity,\n            dailyDose: GetDailyDose(I.ingredientCode, I.strength, I.doseFormCode, adjustedDoseQuantity, M.dosesPerDay),\n            factor: ConversionFactors.GetConversionFactor(I.ingredientCode, dailyDose.result, I.doseFormCode, M.dosesPerDay)\n          return {\n            rxNormCode: M.rxNormCode,\n            doseFormCode: I.doseFormCode,\n            doseQuantity: adjustedDoseQuantity,\n            dosesPerDay: M.dosesPerDay,\n            ingredientCode: I.ingredientCode,\n            strength: I.strength,\n            dailyDose: dailyDose.result,\n            dailyDoseDescription: dailyDose.description & (' * factor: ' + Coalesce(ToString(factor), 'No conversion factor available')),\n            conversionFactor: factor,\n            mme: Quantity(\n              Round(dailyDose.result.value * factor, 1),\n              '{MME}/d'\n            )\n          }\n  )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 56
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OMTKLogic"
    },
    {
      "url" : "name",
      "valueString" : "GetIngredients"
    },
    {
      "url" : "statement",
      "valueString" : "/*\nReturns the opioid ingredients and their strengths that\nmake up the drug identified by the given rxNormCode as a list of tuples:\n\nList<Tuple {\n  rxNormCode Code,\n  doseFormCode Code,\n  doseFormName String,\n  ingredientCode Code,\n  ingredientName String,\n  strength Quantity\n}>\n*/\n\n/*\nGetIngredients:\n  List<{\n    rxNormCode Code,\n    doseFormCode Code,\n    ingredientCode code,\n    strength Quantity\n  }>\n*/\ndefine function GetIngredients(rxNormCode Code):\n  OMTKData.DrugIngredients DI\n    where DI.drugCode = ToInteger(rxNormCode.code)\n    return {\n      rxNormCode: Code { code: ToString(DI.drugCode), system: 'http://www.nlm.nih.gov/research/umls/rxnorm', display: DI.drugName },\n      doseFormCode: Code { code: ToString(DI.doseFormCode), system: 'http://www.nlm.nih.gov/research/umls/rxnorm', display: DI.doseFormName },\n      ingredientCode: Code { code: ToString(DI.ingredientCode), system: 'http://www.nlm.nih.gov/research/umls/rxnorm', display: DI.ingredientName },\n      strength: Quantity {\n        value: DI.strengthValue,\n        unit: ToUCUM(DI.strengthUnit)\n      }\n    }"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 57
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OMTKLogic"
    },
    {
      "url" : "name",
      "valueString" : "ToUCUM"
    },
    {
      "url" : "statement",
      "valueString" : "/*\nNormalizes the input units to UCUM units\n\nThe values listed here are the only ones currently present in the OMTK data\n\nBased on the HL7 UCUM subset here:\nhttp://download.hl7.de/documents/ucum/ucumdata.html\n*/\ndefine function ToUCUM(unit String):\n  case unit\n    when 'MG' then 'mg'\n    when 'MG/ACTUAT' then 'mg/{actuat}'\n    when 'MG/HR' then 'mg/h'\n    when 'MG/ML' then 'mg/mL'\n    else Message(null, true, 'OMTKLogic.ToUCUM.UnknownUnit', ErrorLevel, 'Unknown unit ' & unit)\nend"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 58
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OMTKLogic"
    },
    {
      "url" : "name",
      "valueString" : "GetDailyDose"
    },
    {
      "url" : "statement",
      "valueString" : "/*\ndefine function StripPer(unit String):\n  if LastPositionOf('/', unit) >= 0\n    then Substring(unit, 0, LastPositionOf('/', unit))\n    else unit\n*/\n\n/*\n  Calculates daily dose for a specific ingredient based on the ingredient strength,\n  dose form, dose quantity, and daily frequency.\n  In addition, returns a textual description of the daily dose.\n  Tuple { result: Quantity, description: String }\n*/\ndefine function GetDailyDose(ingredientCode Code, strength Quantity, doseFormCode Code, doseQuantity Quantity, dosesPerDay Decimal):\n  case\n    when dosesPerDay is null or doseQuantity is null or strength is null or strength.value is null or strength.unit is null then\n      {\n        result: null as Quantity,\n        description: 'Missing doses per day, dose quantity, and/or strength'\n      }\n\t  /* if patch --> daily dose = dose value (e.g, number patches with doseQuantity unit = \"patch\") * per-hour strength */\n    when ToInteger(doseFormCode.code) = 316987 then\n      /* buprenorphine or fentanyl patch */\n      if ToInteger(ingredientCode.code) in { 1819, 4337 } then\n        (Quantity { value: dosesPerDay * doseQuantity.value * strength.value, unit: strength.unit }) dailyDose\n          return {\n            result: dailyDose,\n            description: GetIngredientName(ingredientCode) & ' patch: ' & ToString(doseQuantity.value) & ' * ' & ToString(dosesPerDay) & '/d * ' & ToString(strength) & ' = ' + ToString(dailyDose)\n          }\n      else\n        {\n          result: null as Quantity,\n          description: 'Unknown patch ingredient: ' & ingredientCode.code & ':' & ingredientCode.display\n        }\n\n    /* if dose unit in actual mass units (mg or ug -- when it's a single med) --> daily dose = numTimesPerDay * dose */\n    when doseQuantity.unit in { 'mg', 'ug' } then\n      (Quantity { value: dosesPerDay * doseQuantity.value, unit: doseQuantity.unit }) dailyDose\n        return {\n          result: dailyDose,\n          description: GetIngredientName(ingredientCode) + ' ' + GetDoseFormName(doseFormCode) + ': ' + ToString(dosesPerDay) + '/d * ' + ToString(doseQuantity) + ' = ' + ToString(dailyDose)\n        }\n\n    /* if doseQuantity is in actual volume units (mL) --> daily dose = numTimesPerDay * dose * strength */\n    when doseQuantity.unit = 'mL' and (PositionOf('/mL', strength.unit) = Length(strength.unit) - 3) then\n      (Quantity { value: dosesPerDay * doseQuantity.value * strength.value, unit: StripPer(strength.unit) }) dailyDose\n        return {\n          result: dailyDose,\n          description: GetIngredientName(ingredientCode) + ' ' + GetDoseFormName(doseFormCode) + ': ' + ToString(dosesPerDay) + '/d * ' + ToString(doseQuantity) + ' * ' & ToString(strength) & ' = ' + ToString(dailyDose)\n        }\n\n\t\t/* if doseQuantity is not in actual units (e.g., 1 tab, 1 spray -- when it's a combo med with a unit of tablet, or it's mg/actuat) -->  daily dose = numTimesPerDay * dose value * strength value */\n    else\n      (Quantity { value: dosesPerDay * doseQuantity.value * strength.value, unit: StripPer(strength.unit) }) dailyDose\n        return {\n          result: dailyDose,\n          description: GetIngredientName(ingredientCode) + ' ' + GetDoseFormName(doseFormCode) + ': ' + ToString(dosesPerDay) + '/d * ' + ToString(doseQuantity) + ' * ' + ToString(strength) + ' = ' + ToString(dailyDose)\n        }\nend"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 59
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OMTKLogic"
    },
    {
      "url" : "name",
      "valueString" : "GetIngredientName"
    },
    {
      "url" : "statement",
      "valueString" : "/*\nReturns the display of the given ingredient, if present, otherwise looks it up from the OMTK data\n*/\ndefine function GetIngredientName(ingredientCode Code):\n  if ingredientCode.display is null then\n    singleton from (\n      OMTKData.DrugIngredients DI\n        where DI.ingredientCode = ToInteger(ingredientCode.code)\n        return DI.ingredientName\n    )\n    else ingredientCode.display"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 60
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OMTKLogic"
    },
    {
      "url" : "name",
      "valueString" : "GetDoseFormName"
    },
    {
      "url" : "statement",
      "valueString" : "/*\nReturns the display of the given dose form, if present, otherwise looks it up from the OMTK data\n*/\ndefine function GetDoseFormName(doseFormCode Code):\n  if doseFormCode.display is null then\n    singleton from (\n      OMTKData.DrugIngredients DI\n        where DI.doseFormCode = ToInteger(doseFormCode.code)\n        return DI.doseFormName\n    )\n    else doseFormCode.display"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 61
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OMTKLogic"
    },
    {
      "url" : "name",
      "valueString" : "StripPer"
    },
    {
      "url" : "statement",
      "valueString" : "/*\n  Removes the last per argument from a unit\n  NOTE: Rewrote to not use LastPositionOf, since that function is not implemented in the JS engine\n  https://github.com/cqframework/cql-execution/issues/147\n*/\ndefine function StripPer(unit String):\n  unit X\n    let split: Split(unit, '/'),\n      splitCount: Count(split)\n    return\n      if splitCount > 1 then\n        Substring(unit, 0, Length(unit) - Length(split[splitCount - 1]) - 1)\n      else\n        unit"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 62
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "ConversionFactors"
    },
    {
      "url" : "name",
      "valueString" : "GetConversionFactor"
    },
    {
      "url" : "statement",
      "valueString" : "/*\nReturns the conversion factor for the given ingredient\n\nCDC Guidance:\nhttps://www.cdc.gov/drugoverdose/pdf/calculating_total_daily_dose-a.pdf\n\n|Opioid (strength in mg except where noted)     |MME Conversion Factor*|\n|-----------------------------------------------|----------------------|\n|Codeine                                        |                 0.15 |\n|Fentanyl, transdermal patch (MCG/HR)           |                 2.4  |\n|Hydrocodone                                    |                 1    |\n|Hydromorphone                                  |                 4    |\n|Methadone                                      |                      |\n|  1-20 mg/d                                    |                 4    |\n|  21-40 mg/d                                   |                 8    |\n|  41-60 mg/d                                   |                10    |\n|  61-80+ mg/d                                  |                12    |\n| Morphine                                      |                 1    |\n| Oxycodone                                     |                 1.5  |\n| Oxymorphone                                   |                 3    |\n\n*/\ndefine function GetConversionFactor(ingredientCode System.Code, dailyDose System.Quantity, doseFormCode System.Code, dosesPerDay System.Decimal):\n  Coalesce(\n    LookupConversionFactor(ingredientCode, dailyDose, doseFormCode, dosesPerDay),\n    case ToInteger(ingredientCode.code)\n      when 2670 then 0.15 /*\tCodeine */\n      when 4337 then ( /*\tFentanyl */\n        case\n          when ToInteger(doseFormCode.code) = 316987 then (0.33333333 / dosesPerDay) * 7200 /* Transdermal system */\n          else Message(null, true, 'OMTKLogic.GetConversionFactor.UnknownDoseForm', ErrorLevel, 'Unknown dose form code ' & doseFormCode.code)\n        end\n      )\n      when 5489 then 1 /*\tHydrocodone */\n      when 3423 then 4 /*\tHydromorphone */\n      when 6813 then ( /*\tMethadone */\n        case\n          when dailyDose.value between 1 and 20 then 4\n          when dailyDose.value between 21 and 40 then 8\n          when dailyDose.value between 41 and 60 then 10\n          when dailyDose.value >= 61 then 12\n          when dailyDose is null or dailyDose.value is null then\n            Message(null, true, 'OMTKLogic.GetConversionFactor.DailyDoseNull', ErrorLevel, 'Daily dose is required to determine methadone conversion factor')\n          else Message(null, dailyDose.value < 1, 'OMTKLogic.GetConversionFactor.DailyDoseLessThanOne', ErrorLevel, 'Daily dose less than 1')\n        end\n      )\n      when 7052 then 1 /*\tMorphine */\n      when 7804 then 1.5 /*\tOxycodone */\n      when 7814 then 3 /*\tOxymorphone */\n      else Message(null, true, 'OMTKLogic.GetConversionFactor.UnknownIngredientCode', ErrorLevel, 'Unknown ingredient code: ' & ingredientCode.code)\n    end\n  )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 63
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "ConversionFactors"
    },
    {
      "url" : "name",
      "valueString" : "LookupConversionFactor"
    },
    {
      "url" : "statement",
      "valueString" : "/*\nLooks up the conversion factor for the given ingredient, daily dose, and dose form from the\nconfigured conversion factor supplement, if available.\n\nIf no conversion factor supplement is configured, returns null\n*/\ndefine function LookupConversionFactor(ingredientCode System.Code, dailyDose System.Quantity, doseFormCode System.Code, dosesPerDay System.Decimal):\n  ConversionFactorSupplement CFS\n    let\n      ingredientConcept: singleton from (CFS.\"concept\" C where C.code.value = ingredientCode.code),\n      conversionFactor: singleton from (ingredientConcept.property P where P.code.value = 'conversion-factor'),\n      doseFormConversionFactors: (ingredientConcept.property P where P.code.value = 'dose-form-conversion-factor'),\n      doseRangeConversionFactors: (ingredientConcept.property P where P.code.value = 'dose-range-conversion-factor')\n    return\n      Coalesce\n      (\n        case\n          when exists (doseRangeConversionFactors) then\n            singleton from (\n              doseRangeConversionFactors DRCF\n                where dailyDose.value in ToDoseRange(DRCF.value)\n                return ToDoseRangeConversionFactor(DRCF.value)\n            )\n          when exists (doseFormConversionFactors) then\n            singleton from (\n              doseFormConversionFactors DFCF\n                where doseFormCode.code = ToDoseForm(DFCF.value)\n                return ToDoseFormConversionFactor(DFCF.value, dosesPerDay)\n            )\n          else null\n        end,\n        ToConversionFactor(conversionFactor.value)\n      )"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 64
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "ConversionFactors"
    },
    {
      "url" : "name",
      "valueString" : "ToDoseRange"
    },
    {
      "url" : "statement",
      "valueString" : "/*\nConverts the property value of a dose-range-conversion-factor property to the dose range\n<low-value>-<high-value>:<conversion-factor>\nNote that low-value and/or high-value may be wildcards '*'\n*/\ndefine function ToDoseRange(propertyValue FHIR.string):\n  ({ : }) X\n    let rangeValues: Split(Split(propertyValue.value, ':')[0], '-')\n    return Interval[ToRangeValue(rangeValues[0]), ToRangeValue(rangeValues[1])]"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 65
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "ConversionFactors"
    },
    {
      "url" : "name",
      "valueString" : "ToRangeValue"
    },
    {
      "url" : "statement",
      "valueString" : "/*\nConverts a range value boundary to a Decimal (or null for a wildcard)\n*/\ndefine function ToRangeValue(value System.String):\n  if value = '*' then null else ToDecimal(value)"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 66
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "ConversionFactors"
    },
    {
      "url" : "name",
      "valueString" : "ToDoseRangeConversionFactor"
    },
    {
      "url" : "statement",
      "valueString" : "/*\nConverts the property value of a dose-range-conversion-factor property to the conversion factor\n<low-value>-<high-value>:<conversion-factor>\n*/\ndefine function ToDoseRangeConversionFactor(propertyValue FHIR.string):\n  ToDecimal(Split(propertyValue.value, ':')[1])"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 67
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "ConversionFactors"
    },
    {
      "url" : "name",
      "valueString" : "ToDoseForm"
    },
    {
      "url" : "statement",
      "valueString" : "/*\nConverts the property value of a dose-form-conversion-factor property to the dose form\n<dose-form-code>:<conversion-factor>\n*/\ndefine function ToDoseForm(propertyValue FHIR.string):\n  Split(propertyValue.value, ':')[0]"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 68
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "ConversionFactors"
    },
    {
      "url" : "name",
      "valueString" : "ToDoseFormConversionFactor"
    },
    {
      "url" : "statement",
      "valueString" : "/*\nConverts the property value of a dose-form-conversion-factor property to the conversion factor\n<dose-form-code>:<conversion-factor>[@doses-per-day]\n*/\ndefine function ToDoseFormConversionFactor(propertyValue FHIR.string, dosesPerDay System.Decimal):\n  if PositionOf('@', propertyValue.value) > 0 then\n    ToDoseFormDosesPerDayConversionFactor(propertyValue, dosesPerDay)\n  else\n    ToDecimal(Split(propertyValue.value, ':')[1])"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 69
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "ConversionFactors"
    },
    {
      "url" : "name",
      "valueString" : "ToDoseFormDosesPerDayConversionFactor"
    },
    {
      "url" : "statement",
      "valueString" : "/*\nConverts the property value of a dose-form-conversion-factor property to the conversion factor\nif the property includes a doses-per-day value\n*/\ndefine function ToDoseFormDosesPerDayConversionFactor(propertyValue FHIR.string, dosesPerDay System.Decimal):\n  propertyValue P\n    let components: Split(P.value, '@')\n    return (ToDecimal(components[1]) / dosesPerDay) * ToDecimal(Split(components[0], ':')[1])"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 70
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "ConversionFactors"
    },
    {
      "url" : "name",
      "valueString" : "ToConversionFactor"
    },
    {
      "url" : "statement",
      "valueString" : "/*\nReturns the conversion factor for a conversion-factor property\nNOTE: These functions are used to avoid use of _is_ and _as_\n*/\ndefine function ToConversionFactor(propertyValue FHIR.decimal):\n  propertyValue.value"
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 71
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "extension" : [{
      "url" : "libraryName",
      "valueString" : "OpioidCDSCommon"
    },
    {
      "url" : "name",
      "valueString" : "Get Active Ambulatory Medication Requests"
    },
    {
      "url" : "statement",
      "valueString" : "define function \"Get Active Ambulatory Medication Requests\" (value List<MedicationRequest>) returns List<MedicationRequest>:\n  value Rx\n    where Rx.status.value = 'active'\n      and Rx.category in \"Community\""
    },
    {
      "url" : "displaySequence",
      "valueInteger" : 72
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-logicDefinition"
  },
  {
    "id" : "effective-data-requirements",
    "url" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-effectiveDataRequirements",
    "valueCanonical" : "#effective-data-requirements"
  },
  {
    "url" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-softwaresystem",
    "valueReference" : {
      "reference" : "Device/cqf-tooling"
    }
  }],
  "url" : "http://fhir.org/guides/cdc/opioid-cds/PlanDefinition/opioidcds-04-05",
  "identifier" : [{
    "use" : "official",
    "value" : "cdc-opioid-guidance"
  }],
  "version" : "2022.1.0",
  "name" : "PlanDefinition_Recommendation_04_05_Order_Sign",
  "title" : "Recommendations #4 and #5 - Lowest Effective Dose",
  "type" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/plan-definition-type",
      "code" : "eca-rule",
      "display" : "ECA Rule"
    }]
  },
  "status" : "active",
  "experimental" : false,
  "date" : "2025-08-06",
  "publisher" : "CDC / Security Risk Solutions, Inc. (SRS)",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.securityrisksolutions.com"
    }]
  }],
  "description" : "Recommendation 4: When opioids are initiated for opioid-naïve patients with acute, subacute, or chronic pain, clinicians should prescribe the lowest effective dosage. If opioids are continued for subacute or chronic pain, clinicians should use caution when prescribing opioids at any dosage, should carefully evaluate individual benefits and risks when considering increasing dosage, and should avoid increasing dosage above levels likely to yield diminishing returns in benefits relative to risks to patients. Recommendation 5: For patients already receiving opioid therapy, clinicians should carefully weigh benefits and risks and exercise care when changing opioid dosage. If benefits outweigh risks of continued opioid therapy, clinicians should work closely with patients to optimize nonopioid therapies while continuing opioid therapy. If benefits do not outweigh risks of continued opioid therapy, clinicians should optimize other therapies and work closely with patients to gradually taper to lower dosages or, if warranted based on the individual circumstances of the patient, appropriately taper and discontinue opioids. Unless there are indications of a life-threatening issue such as warning signs of impending overdose (e.g., confusion, sedation, or slurred speech), opioid therapy should not be discontinued abruptly, and clinicians should not rapidly reduce opioid dosages from higher dosages.",
  "useContext" : [{
    "code" : {
      "system" : "http://terminology.hl7.org/CodeSystem/usage-context-type",
      "code" : "focus",
      "display" : "Clinical Focus"
    },
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "182888003",
        "display" : "Medication requested (situation)"
      }]
    }
  },
  {
    "code" : {
      "system" : "http://terminology.hl7.org/CodeSystem/usage-context-type",
      "code" : "focus",
      "display" : "Clinical Focus"
    },
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "82423001",
        "display" : "Chronic pain (finding)"
      }]
    }
  },
  {
    "code" : {
      "system" : "http://terminology.hl7.org/CodeSystem/usage-context-type",
      "code" : "focus",
      "display" : "Clinical Focus"
    },
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "274663001",
        "display" : "Acute pain (finding)"
      }]
    }
  },
  {
    "code" : {
      "system" : "http://terminology.hl7.org/CodeSystem/usage-context-type",
      "code" : "focus",
      "display" : "Clinical Focus"
    },
    "valueCodeableConcept" : {
      "text" : "Subacute pain"
    }
  }],
  "purpose" : "The 2022 CDC Clinical Practice Guideline for Prescribing Opioids for Pain is intended to improve communication between clinicians and patients about the benefits and risks of pain treatments, including opioid therapy; improve the effectiveness and safety of pain treatment; mitigate pain; improve function and quality of life for patients with pain; and reduce risks associated with opioid pain therapy, including opioid use disorder, overdose, and death. The recommendations do not apply to pain related to sickle cell disease or cancer or to patients receiving palliative or end-of-life care.",
  "usage" : "The recommendations related to opioid dosages are not intended to be used as an inflexible, rigid standard of care; rather, they are intended to be guideposts to help inform clinician-patient decision-making. Risks of opioid use, including risk for overdose and overdose death, increase continuously with dosage, and there is no single dosage threshold below which risks are eliminated. Therefore, the recommendation language emphasizes that clinicians should avoid increasing dosage above levels likely to yield diminishing returns in benefits relative to risks to patients rather than emphasizing a single specific numeric threshold. Further, these recommendations apply specifically to starting opioids or to increasing opioid dosages, and a different set of benefits and risks applies to reducing opioid dosages.",
  "copyright" : "© CDC 2016+.",
  "topic" : [{
    "text" : "Opioid Prescribing"
  }],
  "author" : [{
    "name" : "Kensaku Kawamoto, MD, PhD, MHS"
  },
  {
    "name" : "Bryn Rhodes"
  },
  {
    "name" : "Floyd Eisenberg, MD, MPH"
  },
  {
    "name" : "Robert McClure, MD, MPH"
  }],
  "relatedArtifact" : [{
    "type" : "documentation",
    "display" : "2022 CDC Clinical Practice Guideline for Prescribing Opioids for Pain",
    "url" : "https://www.cdc.gov/mmwr/volumes/71/rr/rr7103a1.htm",
    "document" : {
      "url" : "https://www.cdc.gov/mmwr/volumes/71/rr/rr7103a1.htm"
    }
  }],
  "library" : ["http://fhir.org/guides/cdc/opioid-cds/Library/OpioidCDSREC04And05"],
  "action" : [{
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-strengthOfRecommendation",
      "valueCodeableConcept" : {
        "coding" : [{
          "id" : "recommendation-4-strength-of-recommendation",
          "system" : "http://terminology.hl7.org/CodeSystem/recommendation-strength",
          "code" : "strong",
          "display" : "Strong"
        },
        {
          "id" : "recommendation-5-strength-of-recommendation",
          "system" : "http://terminology.hl7.org/CodeSystem/recommendation-strength",
          "code" : "weak",
          "display" : "Weak"
        }]
      }
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/cqf-qualityOfEvidence",
      "valueCodeableConcept" : {
        "coding" : [{
          "id" : "recommendation-4-evidence-quality",
          "system" : "http://terminology.hl7.org/CodeSystem/evidence-quality",
          "code" : "low",
          "display" : "Low quality"
        },
        {
          "id" : "recommendation-5-evidence-quality",
          "system" : "http://terminology.hl7.org/CodeSystem/evidence-quality",
          "code" : "very-low",
          "display" : "Very low quality"
        }]
      }
    }],
    "title" : "Calibrate to Lowest Opioid Dose Needed for Expected Results and Exercise Care When Changing Opioid Dosages",
    "description" : "When opioid therapy is considered appropriate, calibrate opioid dosages to lowest dose needed to achieve expected effects. For patients already receiving opioid therapy, clinicians should carefully weigh benefits and risks and exercise care when changing opioid dosage.\r\n\r\n[For guidance in determining the lowest effective opioid dosage, see Recommendation 4 of the 2022 CDC Clinical Practice Guideline](https://www.cdc.gov/mmwr/volumes/71/rr/rr7103a1.htm#Recommendation4)\r\n\r\n[For patients who have received opioid therapy for longer durations of time, if tapering, consider working closely with the patient to gradually taper dosages (no more than 10% per month)](https://www.cdc.gov/mmwr/volumes/71/rr/rr7103a1.htm#:~:text=When%20patients%20have%20been%20taking%20opioids%20for%20longer%20durations%20(e.g.%2C%20for%20%E2%89%A51%20year)%2C%20tapers%20of%2010%25%20per%20month%20or%20slower%20are%20likely%20to%20be%20better%20tolerated%20than%20more%20rapid%20tapers.)\r\n\r\nFor a tapering calculator, go to [https://agencymeddirectors.wa.gov/Calculator/TaperDoseCalculator.html](https://www.agencymeddirectors.wa.gov/Calculator/TaperDoseCalculator.html)\r\n\r\n[For more guidance regarding tapering, please see Recommendation 5 of the 2022 CDC Clinical Practice Guideline for Prescribing Opioids for Pain](https://www.cdc.gov/mmwr/volumes/71/rr/rr7103a1.htm#Recommendation5).)\r\n\r\n**MME Calculator Cautions**\r\n1) All doses are in mg/day except for fentanyl, which is mcg/hr. \r\n2) Equianalgesic dose conversions are only estimates and cannot account for individual variability in genetics and pharmacokinetics. \r\n3) Do not use the calculated dose in MMEs to determine the doses to use when converting one opioid to another; when converting opioids, the new opioid is typically dosed at a substantially lower dose than the calculated MME dose to avoid overdose because of incomplete cross-tolerance and individual variability in opioid pharmacokinetics. Consult the FDA approved product labeling for specific guidance on medications. \r\n4) Use particular caution with methadone dose conversions because methadone has a long and variable half-life, and peak respiratory depressant effect occurs later and lasts longer than peak analgesic effect. \r\n5) Use particular caution with transdermal fentanyl because it is dosed in mcg/hr instead of mg/day, and its absorption is affected by heat and other factors. \r\n6) Buprenorphine products approved for the treatment of pain are not included in the table because of their partial µ-receptor agonist activity and resultant ceiling effects compared with full µ-receptor agonists. \r\n7) These conversion factors should not be applied to dosage decisions related to the management of opioid use disorder.\r\n- Tapentadol is a µ-receptor agonist and norepinephrine reuptake inhibitor. MMEs are based on degree of µ-receptor agonist activity; however, it is unknown whether tapentadol is associated with overdose in the same dose-dependent manner as observed with medications that are solely µ-receptor agonists.\r\n- Tramadol is a µ-receptor agonist and norepinephrine and serotonin reuptake inhibitor. MMEs are based on degree of µ-receptor agonist activity; however, it is unknown whether tramadol is associated with overdose in the same dose-dependent manner as observed with medications that are solely µ-receptor agonists.",
    "priority" : "urgent",
    "trigger" : [{
      "type" : "named-event",
      "name" : "order-sign"
    }],
    "condition" : [{
      "kind" : "applicability",
      "expression" : {
        "description" : "Check whether the current order is for an opioid with ambulatory misuse potential, the calculated MME result for the order and other active opioid medications for the patient is greater than or equal to 50 and if the 2022 CDC guideline general inclusion criteria is met",
        "language" : "text/cql.identifier",
        "expression" : "Is Recommendation Applicable?"
      }
    }],
    "groupingBehavior" : "visual-group",
    "selectionBehavior" : "any",
    "action" : [{
      "description" : "Document - Will prescribe a lower dose"
    },
    {
      "description" : "Document - Will calibrate a gradual change in dosage"
    },
    {
      "description" : "Snooze* - Benefits outweigh risks, snooze 3 months"
    },
    {
      "description" : "Snooze* - Short term benefits outweigh risks, snooze 1 month"
    },
    {
      "description" : "Snooze* - N/A add comment, snooze 3 months"
    }]
  }]
}

```
