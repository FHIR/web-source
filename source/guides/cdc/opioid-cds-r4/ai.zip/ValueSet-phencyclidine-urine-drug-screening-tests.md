# Phencyclidine urine drug screening tests - 2022 CDC Clinical Practice Guideline for Prescribing Opioids Implementation Guide v2022.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Phencyclidine urine drug screening tests**

## ValueSet: Phencyclidine urine drug screening tests 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.org/guides/cdc/opioid-cds/ValueSet/phencyclidine-urine-drug-screening-tests | *Version*:2022.1.0 |
| Active as of 2023-05-25 | *Computable Name*:PHENCYCLIDINE_URINE_DRUG_SCREENING_TESTS |
| **Copyright/Legal**: © CDC 2016+. | |

 
Urine tests for phencyclidine 

 
Identification of urine drug tests where results can be used when considering pain management therapy 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

No formal definition provided for this value set

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "phencyclidine-urine-drug-screening-tests",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-computablevalueset",
    "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-executablevalueset"]
  },
  "extension" : [{
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-clinical-focus",
    "valueString" : "Urine tests for phencyclidine"
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-dataelement-scope",
    "valueString" : "Urine test"
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-inclusion-criteria",
    "valueString" : "Codes"
  },
  {
    "url" : "http://fhir.org/guides/cdc/opioid-cds/StructureDefinition/cdc-valueset-exclusion-criteria",
    "valueString" : "None"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-author",
    "valueContactDetail" : {
      "name" : "MD Partners, Inc.",
      "telecom" : [{
        "system" : "email",
        "value" : "info@mdpartners.com"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "computable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "executable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-usageWarning",
    "valueString" : "This value set contains a point-in-time expansion enumerating the codes that meet the value set intent. As new versions of the code systems used by the value set are released, the contents of this expansion will need to be updated to incorporate newly defined codes that meet the value set intent. Before, and periodically during production use, the value set expansion contents SHOULD be updated. The value set expansion specifies the timestamp when the expansion was produced, SHOULD contain the parameters used for the expansion, and SHALL contain the codes that are obtained by evaluating the value set definition. If this is ONLY an executable value set, a distributable definition of the value set must be obtained to compute the updated expansion."
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-rules-text",
    "valueMarkdown" : "Use the following LOINC query: Phencyclidine (=system:Urine) AND NOT status:DEPRECATED"
  }],
  "url" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/phencyclidine-urine-drug-screening-tests",
  "version" : "2022.1.0",
  "name" : "PHENCYCLIDINE_URINE_DRUG_SCREENING_TESTS",
  "title" : "Phencyclidine urine drug screening tests",
  "status" : "active",
  "experimental" : false,
  "date" : "2023-05-25T18:08:12-06:00",
  "publisher" : "CDC / Security Risk Solutions, Inc. (SRS)",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.securityrisksolutions.com"
    }]
  }],
  "description" : "Urine tests for phencyclidine",
  "purpose" : "Identification of urine drug tests where results can be used when considering pain management therapy",
  "copyright" : "© CDC 2016+.",
  "expansion" : {
    "timestamp" : "2023-05-25T18:08:12-06:00",
    "total" : 14,
    "contains" : [{
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "3937-0",
      "display" : "Phencyclidine [Mass/volume] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "16254-5",
      "display" : "Phencyclidine [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "72825-3",
      "display" : "Phencyclidine [Mass/volume] in Urine by Screen method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "3936-2",
      "display" : "Phencyclidine [Presence] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "18392-1",
      "display" : "Phencyclidine [Presence] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "14311-5",
      "display" : "Phencyclidine [Presence] in Urine by Confirm method >20 ng/mL"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "8237-0",
      "display" : "Phencyclidine [Presence] in Urine by SAMHSA confirm method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "8238-8",
      "display" : "Phencyclidine [Presence] in Urine by SAMHSA screen method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "19659-2",
      "display" : "Phencyclidine [Presence] in Urine by Screen method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "14310-7",
      "display" : "Phencyclidine [Presence] in Urine by Screen method >25 ng/mL"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "52951-1",
      "display" : "Phencyclidine [Moles/volume] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "19661-8",
      "display" : "Phencyclidine cutoff [Mass/volume] in Urine for Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "19660-0",
      "display" : "Phencyclidine cutoff [Mass/volume] in Urine for Screen method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.74",
      "code" : "58397-1",
      "display" : "Phencyclidine/Creatinine [Mass Ratio] in Urine"
    }]
  }
}

```
