# Fentanyl-type medications - 2022 CDC Clinical Practice Guideline for Prescribing Opioids Implementation Guide v2022.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Fentanyl-type medications**

## ValueSet: Fentanyl-type medications 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.org/guides/cdc/opioid-cds/ValueSet/fentanyl-type-medications | *Version*:2022.1.0 |
| Active as of 2025-02-24 | *Computable Name*:FENTANYL_TYPE_MEDICATIONS |
| **Copyright/Legal**: © CDC 2016+. | |

 
Fentanyl and similar medications (sufentanil, alfentanil, remifentanil) 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

No formal definition provided for this value set

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "fentanyl-type-medications",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-computablevalueset",
    "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-executablevalueset"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-author",
    "valueContactDetail" : {
      "name" : "MD Partners, Inc.",
      "telecom" : [{
        "system" : "email",
        "value" : "info@mdpartners.com"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "computable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "executable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-usageWarning",
    "valueString" : "This value set contains a point-in-time expansion enumerating the codes that meet the value set intent. As new versions of the code systems used by the value set are released, the contents of this expansion will need to be updated to incorporate newly defined codes that meet the value set intent. Before, and periodically during production use, the value set expansion contents SHOULD be updated. The value set expansion specifies the timestamp when the expansion was produced, SHOULD contain the parameters used for the expansion, and SHALL contain the codes that are obtained by evaluating the value set definition. If this is ONLY an executable value set, a distributable definition of the value set must be obtained to compute the updated expansion."
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-rules-text",
    "valueMarkdown" : "https://mor.nlm.nih.gov/RxMix/ Script: \r\nStep 1 Upload to RxMix a workflow config file  named GetRelatedByType.config containing the following workflow text: <WFE><filteredOutputs>RXCUI|name|term_type</filteredOutputs><input>NOINPUT</input><FS><service>NOINPUT</service><function>getRelatedByType</function><level>0</level><paramSize>2</paramSize><param order ='0'>?</param><param order ='1'>BPCK,GPCK,SBD,SCD</param></FS></WFE> \r\n\r\nStep 2 Create Batch text input file (Ingredients.txt) with following RxNorm Fentanyl-type ingredient codes representing fentanyl, sufentanil, alfentanil, remifentanil as an input within the file:\r\n4337\r\n56795\r\n480\r\n73032\r\n\r\nStep 3 Upload the batch text input file Ingredients.txt created in step 2. \r\n\r\nStep 4 Submit the batch which will run the workflow using the input codes to generate a combined set of all the concepts needed..\r\n"
  }],
  "url" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/fentanyl-type-medications",
  "version" : "2022.1.0",
  "name" : "FENTANYL_TYPE_MEDICATIONS",
  "title" : "Fentanyl-type medications",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-02-24T13:06:38-07:00",
  "publisher" : "CDC / Security Risk Solutions, Inc. (SRS)",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.securityrisksolutions.com"
    }]
  }],
  "description" : "Fentanyl and similar medications (sufentanil, alfentanil, remifentanil)",
  "copyright" : "© CDC 2016+.",
  "expansion" : {
    "timestamp" : "2025-02-24T13:06:38-07:00",
    "total" : 98,
    "contains" : [{
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1740008",
      "display" : "{2 (fentanyl 0.6 MG/ACTUAT Mucosal Spray [Subsys]) } Pack [Subsys 1200 MCG]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1740010",
      "display" : "{2 (fentanyl 0.8 MG/ACTUAT Mucosal Spray [Subsys]) } Pack [Subsys 1600 MCG]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1740007",
      "display" : "{2 (fentanyl 0.6 MG/ACTUAT Mucosal Spray) } Pack"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1740009",
      "display" : "{2 (fentanyl 0.8 MG/ACTUAT Mucosal Spray) } Pack"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1053651",
      "display" : "fentanyl 0.1 MG Sublingual Tablet [Abstral]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1053654",
      "display" : "fentanyl 0.2 MG Sublingual Tablet [Abstral]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1053657",
      "display" : "fentanyl 0.3 MG Sublingual Tablet [Abstral]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1053660",
      "display" : "fentanyl 0.4 MG Sublingual Tablet [Abstral]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1053663",
      "display" : "fentanyl 0.6 MG Sublingual Tablet [Abstral]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1053666",
      "display" : "fentanyl 0.8 MG Sublingual Tablet [Abstral]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1115575",
      "display" : "fentanyl 0.1 MG/ACTUAT Metered Dose Nasal Spray [Lazanda]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1115579",
      "display" : "fentanyl 0.4 MG/ACTUAT Metered Dose Nasal Spray [Lazanda]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1237055",
      "display" : "fentanyl 0.1 MG/ACTUAT Mucosal Spray [Subsys]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1237059",
      "display" : "fentanyl 0.2 MG/ACTUAT Mucosal Spray [Subsys]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1237062",
      "display" : "fentanyl 0.4 MG/ACTUAT Mucosal Spray [Subsys]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1237066",
      "display" : "fentanyl 0.6 MG/ACTUAT Mucosal Spray [Subsys]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1237070",
      "display" : "fentanyl 0.8 MG/ACTUAT Mucosal Spray [Subsys]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1666837",
      "display" : "80 ACTUAT fentanyl 0.04 MG/ACTUAT Transdermal System [Ionsys]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1729322",
      "display" : "fentanyl 0.3 MG/ACTUAT Metered Dose Nasal Spray [Lazanda]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "261106",
      "display" : "fentanyl 0.2 MG Oral Lozenge [Actiq]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "261107",
      "display" : "fentanyl 0.6 MG Oral Lozenge [Actiq]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "261108",
      "display" : "fentanyl 0.8 MG Oral Lozenge [Actiq]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "261109",
      "display" : "fentanyl 1.2 MG Oral Lozenge [Actiq]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "261110",
      "display" : "fentanyl 1.6 MG Oral Lozenge [Actiq]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "262219",
      "display" : "fentanyl 0.4 MG Oral Lozenge [Actiq]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "668622",
      "display" : "fentanyl 0.1 MG Buccal Tablet [Fentora]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "668624",
      "display" : "fentanyl 0.2 MG Buccal Tablet [Fentora]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "668626",
      "display" : "fentanyl 0.4 MG Buccal Tablet [Fentora]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "668628",
      "display" : "fentanyl 0.6 MG Buccal Tablet [Fentora]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "668630",
      "display" : "fentanyl 0.8 MG Buccal Tablet [Fentora]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1053647",
      "display" : "fentanyl 0.1 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1053652",
      "display" : "fentanyl 0.2 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1053655",
      "display" : "fentanyl 0.3 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1053658",
      "display" : "fentanyl 0.4 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1053661",
      "display" : "fentanyl 0.6 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1053664",
      "display" : "fentanyl 0.8 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1115573",
      "display" : "fentanyl 0.1 MG/ACTUAT Metered Dose Nasal Spray"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1115577",
      "display" : "fentanyl 0.4 MG/ACTUAT Metered Dose Nasal Spray"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1237050",
      "display" : "fentanyl 0.1 MG/ACTUAT Mucosal Spray"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1237057",
      "display" : "fentanyl 0.2 MG/ACTUAT Mucosal Spray"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1237060",
      "display" : "fentanyl 0.4 MG/ACTUAT Mucosal Spray"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1237064",
      "display" : "fentanyl 0.6 MG/ACTUAT Mucosal Spray"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1237068",
      "display" : "fentanyl 0.8 MG/ACTUAT Mucosal Spray"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1603495",
      "display" : "72 HR fentanyl 0.0375 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1603498",
      "display" : "72 HR fentanyl 0.0625 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1603501",
      "display" : "72 HR fentanyl 0.0875 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1666831",
      "display" : "80 ACTUAT fentanyl 0.04 MG/ACTUAT Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1729320",
      "display" : "fentanyl 0.3 MG/ACTUAT Metered Dose Nasal Spray"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1735003",
      "display" : "2 ML fentanyl 0.05 MG/ML Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1735006",
      "display" : "10 ML fentanyl 0.05 MG/ML Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1735007",
      "display" : "5 ML fentanyl 0.05 MG/ML Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1735008",
      "display" : "20 ML fentanyl 0.05 MG/ML Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1735013",
      "display" : "50 ML fentanyl 0.05 MG/ML Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "197696",
      "display" : "72 HR fentanyl 0.075 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2168270",
      "display" : "1 ML fentanyl 0.05 MG/ML Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "245134",
      "display" : "72 HR fentanyl 0.025 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "245135",
      "display" : "72 HR fentanyl 0.05 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "245136",
      "display" : "72 HR fentanyl 0.1 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2474267",
      "display" : "2 ML fentanyl 0.05 MG/ML Prefilled Syringe"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2474269",
      "display" : "1 ML fentanyl 0.05 MG/ML Prefilled Syringe"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2629337",
      "display" : "0.5 ML fentanyl 0.05 MG/ML Prefilled Syringe"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2635081",
      "display" : "100 ML fentanyl 0.05 MG/ML Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "310293",
      "display" : "fentanyl 1.2 MG Oral Lozenge"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "310294",
      "display" : "fentanyl 1.6 MG Oral Lozenge"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "310295",
      "display" : "fentanyl 0.2 MG Oral Lozenge"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "310296",
      "display" : "fentanyl 0.3 MG Oral Lozenge"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "310297",
      "display" : "fentanyl 0.4 MG Oral Lozenge"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "313992",
      "display" : "fentanyl 0.6 MG Oral Lozenge"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "313993",
      "display" : "fentanyl 0.8 MG Oral Lozenge"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "577057",
      "display" : "72 HR fentanyl 0.012 MG/HR Transdermal System"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "668363",
      "display" : "fentanyl 0.1 MG Buccal Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "668364",
      "display" : "fentanyl 0.2 MG Buccal Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "668365",
      "display" : "fentanyl 0.4 MG Buccal Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "668366",
      "display" : "fentanyl 0.6 MG Buccal Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "668367",
      "display" : "fentanyl 0.8 MG Buccal Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "706898",
      "display" : "fentanyl 0.3 MG Buccal Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "727759",
      "display" : "2 ML fentanyl 0.05 MG/ML Cartridge"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "858087",
      "display" : "fentanyl 1.2 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "858092",
      "display" : "fentanyl 0.2 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "858095",
      "display" : "fentanyl 0.4 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "858098",
      "display" : "fentanyl 0.6 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "858101",
      "display" : "fentanyl 0.8 MG Buccal Film"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2103199",
      "display" : "sufentanil 0.03 MG Sublingual Tablet [Dsuvia]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1809097",
      "display" : "1 ML sufentanil 0.05 MG/ML Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1809102",
      "display" : "2 ML sufentanil 0.05 MG/ML Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1809104",
      "display" : "5 ML sufentanil 0.05 MG/ML Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "2103192",
      "display" : "sufentanil 0.03 MG Sublingual Tablet"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "106500",
      "display" : "alfentanil 5 MG/ML Injectable Solution"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1723206",
      "display" : "2 ML alfentanil 0.5 MG/ML Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1723208",
      "display" : "10 ML alfentanil 0.5 MG/ML Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1723209",
      "display" : "20 ML alfentanil 0.5 MG/ML Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1723210",
      "display" : "5 ML alfentanil 0.5 MG/ML Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1729581",
      "display" : "remifentanil 1 MG Injection [Ultiva]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1729586",
      "display" : "remifentanil 2 MG Injection [Ultiva]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1729712",
      "display" : "remifentanil 5 MG Injection [Ultiva]"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1729578",
      "display" : "remifentanil 1 MG Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1729584",
      "display" : "remifentanil 2 MG Injection"
    },
    {
      "system" : "http://www.nlm.nih.gov/research/umls/rxnorm",
      "code" : "1729710",
      "display" : "remifentanil 5 MG Injection"
    }]
  }
}

```
