# Fentanyl-type urine drug screening tests - 2022 CDC Clinical Practice Guideline for Prescribing Opioids Implementation Guide v2022.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Fentanyl-type urine drug screening tests**

## ValueSet: Fentanyl-type urine drug screening tests 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.org/guides/cdc/opioid-cds/ValueSet/fentanyl-type-urine-drug-screening-tests | *Version*:2022.1.0 |
| Active as of 2023-05-25 | *Computable Name*:FENTANYL_TYPE_URINE_DRUG_SCREENING_TESTS |
| **Copyright/Legal**: © CDC 2016+. | |

 
Urine tests for fentanyl-type drugs and metabolites 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

No formal definition provided for this value set

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "fentanyl-type-urine-drug-screening-tests",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-computablevalueset",
    "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-executablevalueset"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-author",
    "valueContactDetail" : {
      "name" : "MD Partners, Inc.",
      "telecom" : [{
        "system" : "email",
        "value" : "info@mdpartners.com"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "computable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "executable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-usageWarning",
    "valueString" : "This value set contains a point-in-time expansion enumerating the codes that meet the value set intent. As new versions of the code systems used by the value set are released, the contents of this expansion will need to be updated to incorporate newly defined codes that meet the value set intent. Before, and periodically during production use, the value set expansion contents SHOULD be updated. The value set expansion specifies the timestamp when the expansion was produced, SHOULD contain the parameters used for the expansion, and SHALL contain the codes that are obtained by evaluating the value set definition. If this is ONLY an executable value set, a distributable definition of the value set must be obtained to compute the updated expansion."
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/valueset-rules-text",
    "valueMarkdown" : "Use the following LOINC query: (*ntanyl* OR *ntanil*) (=system:Urine) AND NOT status:DEPRECATED"
  }],
  "url" : "http://fhir.org/guides/cdc/opioid-cds/ValueSet/fentanyl-type-urine-drug-screening-tests",
  "version" : "2022.1.0",
  "name" : "FENTANYL_TYPE_URINE_DRUG_SCREENING_TESTS",
  "title" : "Fentanyl-type urine drug screening tests",
  "status" : "active",
  "experimental" : false,
  "date" : "2023-05-25T18:08:12-06:00",
  "publisher" : "CDC / Security Risk Solutions, Inc. (SRS)",
  "contact" : [{
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.securityrisksolutions.com"
    }]
  }],
  "description" : "Urine tests for fentanyl-type drugs and metabolites",
  "copyright" : "© CDC 2016+.",
  "expansion" : {
    "timestamp" : "2023-05-25T18:08:12-06:00",
    "total" : 53,
    "contains" : [{
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "16334-5",
      "display" : "Alfentanil [Mass/volume] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "18383-0",
      "display" : "Alfentanil [Presence] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "86604-6",
      "display" : "Alfentanil/Creatinine [Mass Ratio] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "74372-4",
      "display" : "Acetyl fentanyl [Mass/volume] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "74810-3",
      "display" : "Acetyl fentanyl [Presence] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "66129-8",
      "display" : "fentaNYL+Norfentanyl [Presence] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "58379-9",
      "display" : "fentaNYL+Norfentanyl [Presence] in Urine by Screen method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "93471-1",
      "display" : "Acetyl norfentanyl [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "11075-9",
      "display" : "Norfentanyl [Mass/volume] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "58383-1",
      "display" : "Norfentanyl [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "43199-9",
      "display" : "Norfentanyl [Presence] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "43200-5",
      "display" : "Norfentanyl [Presence] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "95797-7",
      "display" : "Norfentanyl [Presence] in Urine by Screen method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "77775-5",
      "display" : "Norfentanyl cutoff [Mass/volume] in Urine for Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "58382-3",
      "display" : "Norfentanyl/Creatinine [Mass Ratio] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "11073-4",
      "display" : "Despropionylfentanyl [Mass/volume] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "26867-2",
      "display" : "fentaNYL [Units/volume] in 24 hour Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "3637-6",
      "display" : "fentaNYL [Mass/volume] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "58381-5",
      "display" : "fentaNYL [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "11235-9",
      "display" : "fentaNYL [Presence] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "40839-3",
      "display" : "fentaNYL [Presence] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "59673-4",
      "display" : "fentaNYL [Presence] in Urine by Screen method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "78828-1",
      "display" : "fentaNYL [Z-score] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "79259-8",
      "display" : "fentaNYL cutoff [Mass/volume] in Urine for Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "79260-6",
      "display" : "fentaNYL cutoff [Mass/volume] in Urine for Screen method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "58380-7",
      "display" : "fentaNYL/Creatinine [Mass Ratio] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "78766-3",
      "display" : "fentaNYL [Mass/volume] in Urine -- adjusted for lean body mass+urine creatinine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "100437-3",
      "display" : "Norsufentanil [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "9396-3",
      "display" : "SUFentanil [Mass/volume] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "18435-8",
      "display" : "SUFentanil [Presence] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "86610-3",
      "display" : "SUFentanil/Creatinine [Mass Ratio] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "93473-7",
      "display" : "Beta hydroxythiofentanyl [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "93465-3",
      "display" : "3-Methylfentanyl [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "93469-5",
      "display" : "4-Fluorobutyrylfentanyl [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "93464-6",
      "display" : "p-Fluorofentanyl [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "101162-6",
      "display" : "p-Fluorofentanyl [Presence] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "101161-8",
      "display" : "p-Fluorofentanyl/Creatinine [Mass Ratio] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "93461-2",
      "display" : "4-Methoxybutyrylfentanyl [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "93468-7",
      "display" : "Acrylfentanyl [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "99079-6",
      "display" : "Acrylfentanyl [Presence] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "93467-9",
      "display" : "Butyrylfentanyl [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "93470-3",
      "display" : "Furanylfentanyl [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "99081-2",
      "display" : "Furanylfentanyl [Presence] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "93466-1",
      "display" : "Valerylfentanyl [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "93472-9",
      "display" : "4-Methylphenethylacetylfentanyl [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "93462-0",
      "display" : "Norcarfentanil [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "93463-8",
      "display" : "Ocfentanil [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "65808-8",
      "display" : "Nortapentadol [Mass/volume] in Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "81754-4",
      "display" : "Nortapentadol [Mass/volume] in Urine by Confirmatory method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "89306-5",
      "display" : "Nortapentadol [Presence] in Urine by Screen method"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "67822-7",
      "display" : "fentaNYL and Norfentanyl panel - Urine"
    },
    {
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "101401-8",
      "display" : "Tapentadol and Nortapentadol panel - Urine"
    }]
  }
}

```
