package http://fhir.org/guides/argonaut/clinicalnotes/ImplementationGuide/fhir.argonaut.clinicalnotes-1.0.0;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class ArgonautImagingReports {

}
