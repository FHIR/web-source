package http://fhir.org/guides/argonaut-scheduling/ImplementationGuide/ig;

import org.hl7.fhir.r4.model.ProfilingWrapper;

public class Argonaut_Slot_Bundle_Profile {

}
